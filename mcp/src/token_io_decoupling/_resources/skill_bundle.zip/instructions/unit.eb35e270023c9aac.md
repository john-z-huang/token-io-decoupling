# unit.eb35e270023c9aac

[English](unit.eb35e270023c9aac.md) | [简体中文](unit.eb35e270023c9aac_zh_cn.md)

Apply the current instruction and its included policy sections below. The current actions, guards, evidence and failure boundary are given directly. Before applying a named independent policy, obtain its exact instruction continuation; reuse any already held unit from this build and retain the affected action's return position. Do not retrieve author files or infer omitted policy. Check current facts and authorization before effects; an instruction is not a pass.

## Hard constraints

- Record hard user, runtime environment, repository, permission, safety, and Session constraints before acting.
- A task-level prohibition, such as “do not create subagents” or “do not use a browser,” remains active for the whole task.
- Computer Use is categorically forbidden: never control a computer, browser, or desktop app through its graphical interface — no screenshots to locate controls, mouse or keyboard simulation, clicking, accessibility APIs, window automation, remote-desktop control, or GUI scripting — and do not route such interaction through an API, CLI, MCP server, helper, or another Agent. Treat this as a blacklist rather than a list of allowed channels: every other tool, command, or capability actually exposed to and authorized for the current Session remains permitted. If a required step needs a forbidden operation, stop and report the blocker instead of attempting, delegating, or skipping it.
- Before route selection or any delegation/Session-topology work, the Mode checkpoint must compose and validate the delegation references; those references own conversation-level mode selection with a default Multi-Agent route and one-child budget, child counts, conditional creation, allocation, reuse, replacement, exceptions, and limits at their respective atomic boundaries. A reserved budget never initializes or authorizes a child by itself.
- Never invent authorization, capability, evidence, product support, or an executable route for an unmaintained scenario.
- Keep Core rules independent of product details; read Runtime and Model Provider Support (instruction continuation: [unit.081374cfbaa37b57](../instructions/unit.081374cfbaa37b57.md)) for supported runtime branches and model bindings.
- Read references on demand. Do not preload the entire Skill, `references/`, or raw project state merely because it may become useful.

# Serena LSP and MCP Tools

## General rules

### Activate the project and inspect code structurally

Activate Serena with the exact project root before querying code. The root must be the directory Serena should treat as the project, not an arbitrary nested source folder. Confirm that the intended project is active and that its language server for the relevant language is available. A worktree or a monorepo subproject may require activating its own root.

When first exploring an unfamiliar code file, call `get_symbols_overview` first. Then use the narrowest relevant symbol operation:

- `find_symbol` to locate a class, function, method, or other code entity; request its body only when the implementation is needed.
- `find_declaration` to resolve a declaration from a known use site.
- `find_referencing_symbols` to find callers or other references to a symbol.
- `find_implementations` to locate implementations of an interface or abstract symbol.

Limit each query to the known file or directory when possible, bound result size and match count, and preserve exact paths and symbol names as source pointers. Use `search_for_pattern` only to discover candidate files or text matches; verify code relationships and candidate symbols with the language server before treating them as structural evidence. A text match alone does not establish a declaration, reference, implementation, or call relationship.

If Serena, the relevant language server, or a required LSP operation is unavailable or does not support the needed semantics, state that limitation and fall back to targeted text search and small, path-bounded reads. Do not describe fallback findings as LSP evidence. Keep reads within the authorized project and task scope.

### Read and write durable project memories

For reusable Agent-facing project knowledge, use a name already provided or present in current context; call `list_memories` only when name discovery is needed. Read a relevant Memory when its contents are needed and are not already present and current in context. Refresh when required information is missing, stale or invalidated, an external update is known, a writer handoff or evidence of concurrent change occurs, a conflict or uncertain result must be resolved, or an explicit content check requires it. A merely possible external change is not by itself a reason to reread. Follow the effective memory-maintenance name Serena supplies when available. Use `write_memory` for stable, non-obvious project knowledge that will help future tasks, and for cross-session notes the user explicitly asks to preserve. Keep memories concise, factual, and linked to authoritative source paths where useful. Follow the specific lifecycle owner for task plans, Worker memos, capsules, indexes, and handoffs.

After a normal successful `write_memory` or `edit_memory`, do not immediately read the complete entry solely to confirm execution. Perform a stored-content check when explicitly requested, required for actual content acceptance, or triggered by an error, uncertain outcome, conflict, invalidated baseline, or suspected concurrent change; do not repeat the same check without a new trigger. Discover names only within the relevant topic. Respect ignored, read-only, and other access rules; never use ordinary file access to bypass Memory visibility or authorization. Keep durable general project knowledge distinct from task plans, Worker memos, capsules, indexes, and handoffs, and do not copy the same finding into multiple records without an owner-defined need.

Serena's default project data directory is `.serena`; project memories are stored under `.serena/memories/`. A memory name such as `architecture/services` maps to `.serena/memories/architecture/services.md`: slash-separated segments create topic subdirectories and Serena supplies the `.md` extension. If project configuration changes the data directory, follow that configured location. Use the `global/` name prefix only when the user explicitly requests a cross-project memory. When preserving an existing Skill's document names and subdirectory intent as memories, use the corresponding basename and slash-separated directory segments as the memory name.

Run onboarding only when Serena indicates that it has not been completed. Before invoking the onboarding tool, ask the user whether to proceed; if they do not authorize it, continue without onboarding. When authorized, follow its returned instructions and read the effective memory-maintenance name it supplies with `read_memory` before writing any onboarding notes. Serena's `ensure_memory_maintenance_memory` may select `global/memory_maintenance` as a configured override; otherwise it uses or creates the project `memory_maintenance` entry. Reading that configured guidance does not authorize writing cross-project memories: write under `global/` only when the user explicitly requests it. Then inspect only the project material needed and write the resulting durable notes with `write_memory`.

Memories are reusable Agent context, not authoritative copies of repository documentation. Do not move README files, normative specifications, or other source-of-truth documents into Memory as their replacement. Do not store secrets, full transcripts, private reasoning, or live parent mode/count/allocation/epoch state. Persist Worker execution memos and Context Exchange capsules/indexes/handoffs as project Memories under Worker Content Memo (instruction continuation: [unit.82536d18b84a698f](../instructions/unit.82536d18b84a698f.md)), Coding Context Exchange (instruction continuation: [unit.439bedbb36334cd3](../instructions/unit.439bedbb36334cd3.md)), Coding Context Exchange Workspace Boundary (instruction continuation: [unit.0a54c601ab09a7e6](../instructions/unit.0a54c601ab09a7e6.md)), Coding Context Exchange Handoff (instruction continuation: [unit.2d0f4872b823ef44](../instructions/unit.2d0f4872b823ef44.md)), and Session Context Firewall (instruction continuation: [unit.95aba471482062c9](../instructions/unit.95aba471482062c9.md)) when that owner authorizes a durable context record. A memory name expresses logical ownership only; Serena/tool visibility does not enforce Worker-level access isolation, read-only ACLs, or OS/RW/RO/DENY boundaries. Source code and authoritative repository files remain subject to their separately approved access boundaries.

## Codex CLI / ChatGPT Desktop optimizations

### Codex Serena MCP calls

In a Codex Session, invoke Serena only through the Serena MCP tools actually exposed to and authorized for that Session. The table lists the 24 Serena tools exposed in the current Codex Session; it is an observation, not a guarantee for other Sessions, and tool presence does not grant permission to call it. Call a tool by its exposed name and required arguments. If an LSP query operation is absent, report the limitation and use only an authorized bounded text-search/read fallback, without claiming LSP evidence. If `list_memories`, `read_memory`, or `write_memory` is absent for a required record, report the unavailable Memory capability and block dependent work; never fall back to file storage.


| Tool | Category | What it does |
| --- | --- | --- |
| `mcp__serena__activate_project` | Project and LSP query | Activates the selected project context. |
| `mcp__serena__delete_memory` | Memory change | Deletes a named Memory; call only with explicit task instruction and authorization. |
| `mcp__serena__edit_memory` | Memory change | Edits an existing named Memory. |
| `mcp__serena__find_declaration` | Code/LSP query | Finds a declaration from a known use site. |
| `mcp__serena__find_implementations` | Code/LSP query | Finds implementations of a symbol or interface. |
| `mcp__serena__find_referencing_symbols` | Code/LSP query | Finds symbols that reference the selected symbol. |
| `mcp__serena__find_symbol` | Code/LSP query | Locates a symbol and, when requested, its body. |
| `mcp__serena__get_current_config` | Runtime/workflow | Reports the current Serena configuration. |
| `mcp__serena__get_diagnostics_for_file` | Code/LSP query | Retrieves language-server diagnostics for a file. |
| `mcp__serena__get_symbols_overview` | Code/LSP query | Summarizes symbols in a code file. |
| `mcp__serena__initial_instructions` | Runtime/workflow | Provides Serena's initial usage instructions. |
| `mcp__serena__insert_after_symbol` | Source modification | Inserts content after a selected symbol. |
| `mcp__serena__insert_before_symbol` | Source modification | Inserts content before a selected symbol. |
| `mcp__serena__list_memories` | Memory read | Lists available Memory names. |
| `mcp__serena__onboarding` | Runtime/workflow | Runs project onboarding when it is incomplete and the user has authorized it. |
| `mcp__serena__open_dashboard` | Runtime/workflow | Opens the Serena Web dashboard. |
| `mcp__serena__read_memory` | Memory read | Reads the named Memory. |
| `mcp__serena__rename_memory` | Memory change | Renames a named Memory. |
| `mcp__serena__rename_symbol` | Source modification | Renames a code symbol. |
| `mcp__serena__replace_in_files` | Source modification | Replaces text in files and supports dry-run. |
| `mcp__serena__replace_symbol_body` | Source modification | Replaces the body of a symbol whose body has already been retrieved and understood. |
| `mcp__serena__safe_delete_symbol` | Source modification | Deletes a symbol if it has no references; otherwise returns the references. |
| `mcp__serena__search_for_pattern` | Code/text discovery | Searches for candidate text or files; verify structural claims with LSP queries. |
| `mcp__serena__write_memory` | Memory change | Creates or writes the named Memory. |

Source and Memory changes must remain within the task's authorized scope; tool exposure is not authorization. In particular, use `delete_memory` only with explicit instruction and authorization. This table describes available tool roles, not a blanket approval to mutate project files or memories.
`activate_project` confirms project activation and may report available language servers and project memory names. This output helps discover capabilities; it does not prove that every LSP operation or memory is available. Serena tool availability also does not override the Session's filesystem permissions or the task's read/write scope.

### Memory use in Codex

Use the exposed Serena Memory tools for project memories; Codex-local memory and chat compaction do not substitute for an authorized Serena record. In the current Codex schema observation, `read_memory` accepts only `memory_name` and returns the complete named Memory; do not invent range or pagination arguments. `max_chars` limits write content, not read output. A normal successful `write_memory` or `edit_memory` result is a short execution receipt, not proof of semantic correctness, stored-content equality, or concurrency control. `write_memory` replaces the complete named entry. For an authorized bounded change, prefer `edit_memory` with literal matching and protection against unintended multiple matches; do not replace a record from an unknown or incomplete baseline. If a required stored-content check is triggered, use the actual available read operation and compare the necessary complete content. If onboarding is incomplete, ask the user before invoking `mcp__serena__onboarding`. Memory state is project-scoped by Serena configuration and is not implicitly shared across Codex Sessions, child Agents, or other runtimes.

## Claude Code CLI / Claude Desktop optimizations

Claude Code supports MCP servers, and its MCP Tool Search can discover tool definitions on demand; configurations may also preload them. When Serena is needed, discover and verify the actual Serena server, tools, and schemas in the current Session before relying on them. Then use only the exposed and authorized Serena tools, following the same project-root, query-bounding, memory, and onboarding rules above. Read only when required information is absent or stale; a successful write result confirms execution, not content, semantic, or concurrency verification. Do not assume Codex's tool prefix, arguments, read granularity, or connections. Claude Code Code Intelligence can separately provide language-server navigation and diagnostics when its language plugin is installed; this is distinct from Serena MCP and does not imply Serena's tools or memories are present. Claude Desktop Agents may use Serena only when the relevant MCP tools are actually exposed to that Agent Session. Neither runtime should assume that Serena memories are shared with another Session or product.
