# unit.6dda2ed61cb61569

[English](unit.6dda2ed61cb61569.md) | [简体中文](unit.6dda2ed61cb61569_zh_cn.md)

Apply the current instruction and its included policy sections below. The current actions, guards, evidence and failure boundary are given directly. Before applying a named independent policy, obtain its exact instruction continuation; reuse any already held unit from this build and retain the affected action's return position. Do not retrieve author files or infer omitted policy. Check current facts and authorization before effects; an instruction is not a pass.

## Hard constraints

- Record hard user, runtime environment, repository, permission, safety, and Session constraints before acting.
- A task-level prohibition, such as “do not create subagents” or “do not use a browser,” remains active for the whole task.
- Computer Use is categorically forbidden: never control a computer, browser, or desktop app through its graphical interface — no screenshots to locate controls, mouse or keyboard simulation, clicking, accessibility APIs, window automation, remote-desktop control, or GUI scripting — and do not route such interaction through an API, CLI, MCP server, helper, or another Agent. Treat this as a blacklist rather than a list of allowed channels: every other tool, command, or capability actually exposed to and authorized for the current Session remains permitted. If a required step needs a forbidden operation, stop and report the blocker instead of attempting, delegating, or skipping it.
- Before route selection or any delegation/Session-topology work, the Mode checkpoint must compose and validate the delegation references; those references own conversation-level mode selection with a default Multi-Agent route and one-child budget, child counts, conditional creation, allocation, reuse, replacement, exceptions, and limits at their respective atomic boundaries. A reserved budget never initializes or authorizes a child by itself.
- Never invent authorization, capability, evidence, product support, or an executable route for an unmaintained scenario.
- Keep Core rules independent of product details; read Runtime and Model Provider Support (instruction continuation: [unit.081374cfbaa37b57](../instructions/unit.081374cfbaa37b57.md)) for supported runtime branches and model bindings.
- Read references on demand. Do not preload the entire Skill, `references/`, or raw project state merely because it may become useful.

# Repair Checkpoint


This checkpoint diagnoses failure evidence, affected paths, and the smallest repair candidate. It reports when the candidate exceeds the approved boundary; it does not authorize or execute repairs and does not define verification epochs.

## Actions

1. Name the failing evidence, affected paths, and smallest repair that can address it.
2. Identify the smallest candidate that could address the failure without assuming authorization.
3. If the candidate appears to change scope, architecture, security, compatibility, or another material decision, report that evidence and pause dependent repair pending the required decision.
4. Return a diagnosis record containing the failure evidence, affected paths, and either the smallest candidate or the specific missing decision/capability. A reviewable diagnosis does not require repair authorization, an applied repair, or re-verification results; it does not release any repair effect.

## Pass condition

The failing evidence, affected paths, and a smallest repair candidate are explicit, or the diagnostic result identifies the missing decision or capability.

## Boundary

This checkpoint does not authorize or execute repairs, run repair checks, define verification epochs, authorize broad cleanup, documentation, Git effects, or external effects.
