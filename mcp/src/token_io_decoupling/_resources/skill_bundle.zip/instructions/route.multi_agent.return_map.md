# route.multi_agent.return_map

[English](route.multi_agent.return_map.md) | [简体中文](route.multi_agent.return_map_zh_cn.md)

Apply the current instruction and its included policy sections below. The current actions, guards, evidence and failure boundary are given directly. Before applying a named independent policy, obtain its exact instruction continuation; reuse any already held unit from this build and retain the affected action's return position. Do not retrieve author files or infer omitted policy. Check current facts and authorization before effects; an instruction is not a pass.

## Outer route scheduling context

The selector states entry prerequisites. Before initial route entry complete missing prerequisites; after entry verify held current pass evidence without replaying gates or prompts. The selected route below owns cross-module returns. Resume only the recorded caller/substep after producer readback and epoch/effect checks; the current module body does not replace this schedule.

## Prerequisite return map

Resolve only the missing item at its producer/recheck location. Preserve the original suspended module/substep, completed effects, and relevant epochs; if the producer also suspends, keep a nested continuation in the existing caller context. After readback and epoch/effect rechecks, resume only the original caller position. Contract/Environment/Mode evidence gaps require missing evidence completion; recheck Route Entry only if material route facts change, then return to the original pending position with locked Mode/count retained. Never replay earlier effects or reopen released Mode/count. Unknown owner/position/effects, no progress, or unrecoverable effects block dependent work.

| Missing prerequisite | Producer/recheck location | Resume after readback |
| --- | --- | --- |
| Contract/acceptance criteria | Coding workflow Contract owner; complete missing evidence. | Original suspended MM module/substep; recheck Route Entry only if material route facts changed. |
| Environment/capability inventory | Corresponding Environment/capability owner; complete missing evidence. | Original suspended MM module/substep; recheck Route Entry only if material route facts changed. |
| Route Entry evidence or changed route fact | Route Entry owner, only for material fact changes; keep released Mode/count. | Original suspended MM module/substep if the route remains valid; otherwise block. |
| Released Multi-Agent Mode/count evidence | Existing Mode owner and locked record readback; do not repeat a released choice. | Original suspended MM module/substep only when current Multi-Agent mode and positive count are confirmed; conflict blocks. |
| Session state, authority, audit, or capacity | MM02 Session owners, including canonical state readback before audit/capacity reuse. | Original suspended MM module/substep after readback; if MM02 itself is caller, resume its recorded producer substep. |
| Context, Decision, plan, or advice | MM03 WD owners; resolve only the missing substep. | Original suspended MM module/substep; e.g. MM07 returns to MM07 after WD evidence is read back. |
| Bootstrap, task authorization, executor/output, role, Slice, or Control | MM04 DE01–DE08 owners; do not replay completed allocation/dispatch effects. | Original suspended MM module/substep after result readback and effect/epoch checks. |
| Verification, repair diagnosis, or handoff | MM05 VR owners; preserve current dimensions and repair effects. | Original suspended MM module/substep after current evidence; MM06 returns to its suspended DOC substep after verification. |
| Documentation impact, owner-required Memory content verification, or checks | MM06 DOC owners; after a VR return, finish the suspended DOC substep. | Original suspended MM module/substep after readback and impact/check completion. |
| Git target/effect, Acceptance criteria, or plan archive | MM07 DA owners; archive only after all criteria pass and required readback. | Original suspended MM module/substep after producer evidence is read back. |
