# 验证与修复模块

[English](workflows--modules--verification-repair.md) | [简体中文](workflows--modules--verification-repair_zh_cn.md)

下列直接给出当前动作、守卫、证据和失败边界。应用独立政策前，先按明确的指令继续入口取得对应单元；同一构建中已持有的单元直接复用，并保留受影响动作的准确恢复位置。不读取作者文件或推测缺失政策。执行副作用前核实当前事实与授权；指令内容可用不表示检查通过。

## 硬约束

- 采取行动前记录用户、运行环境、仓库、权限、安全和 Session 硬约束。
- “不要创建子代理”“不要使用浏览器”等任务级禁止条件在整个任务中持续有效。
- 绝对禁止 Computer Use：不得通过图形界面控制计算机、浏览器或桌面应用——包括以操纵控件为目的的截图、鼠标／键盘模拟、点击、辅助功能 API、窗口自动化、远程桌面控制或 GUI 脚本——也不得把此类交互包装为 API、CLI、MCP Server、辅助程序或其他 Agent 调用来绕过。本节是黑名单而非允许渠道清单：当前 Session 实际暴露且已获授权的其他工具、命令或能力仍然允许。若必需步骤需要借助被禁止的操作，应停止并报告阻塞，而不是尝试、委派或跳过。
- 路线选择或任何委派/Session 拓扑工作前，模式检查点必须组合并验证委派 references；这些 references 在各自的原子边界内规定会话级模式选择及默认多代理路线和单个子代理预算、子代理数量、条件创建、分配、复用、替换、例外和限制。预留预算本身不会初始化或授权创建子代理。
- 不得虚构授权、能力、证据、产品支持，或为未维护场景推导可执行路线。
- Core 规则不依赖具体产品；受支持的运行环境分支和模型绑定见[运行环境与模型厂商支持](../instructions/fundamental-concepts--session-runtime--runtime-provider-support_zh_cn.md)。
- 按需读取 reference。不要仅因为可能以后有用，就预加载整个 Skill、`references/` 或原始项目状态。

# 验证与修复模块


本 Layer-04 模块捕获并验证当前最终状态、分类和报告结果，并将具体失败路由到获授权的窄范围修复，再返回当前 Verification。入口不要求已有最终 Verification 结果；本模块针对当前状态产出最终 Verification。

## 入口声明

| 字段 | 要求 |
| --- | --- |
| 入口前置条件 | 适用的 Single-Agent 或 Multi-Agent Mode 门禁已有当前释放证据；当前 Session 身份与 authority 已确认；调用方 continuation 和已完成效果均已知，且无未解决的效果歧义。本入口不授权独立 verifier；所需独立性须已由其 owner 授权并提供证据。 |
| 必需输入 | 当前 Contract 和验收条件、已完成的实施或子代理实际结果、当前任务范围与来源/效果证据，以及可供捕获最终 Verification 的当前状态。 |
| 允许效果 | 读取状态、运行已授权检查、分类/报告证据，并按直接 owners 路由已诊断的修复。修复写入仅限于另行授权的窄范围。 |
| 结果 | 以当前最终指纹/epoch、必需检查、独立性状态、结果类别、未解决项目/阻塞报告，且无未解决必需失败返回 `complete`；否则连同 owner 和 continuation 返回 `needs_prerequisite` 或 `blocked`。 |
| 新鲜度 | 将各结果绑定到准确的当前指纹及适用的 implementation/content、documentation 和 Git metadata epoch。任何修复或其他相关变化仅使覆盖范围内的维度失效，并返回当前 Verification。 |

## 工作流路线图


## 有序模块清单

1. **VR00 — 解析入口。** 提供本声明、当前 Contract/标准、实施或子代理实际结果、任务范围、来源/效果证据和 continuation，调用[模块入口解析](../instructions/workflow-checkpoints--module-entry-resolution_zh_cn.md)。不要求预先存在最终 Verification 结果。证据缺失时返回 `needs_prerequisite`；冲突、状态不安全或效果无法恢复时返回 `blocked`。
2. **VR01 — 捕获实际当前最终状态。** 应用[Verification](../instructions/workflow-concepts--verification-and-repair--verification_zh_cn.md)检查实际当前状态、捕获准确指纹/epoch，并将每项 Contract 验收条件映射到覆盖维度。若先前输出使用了[输出物料化](../instructions/fundamental-concepts--execution-planning--output-materialization_zh_cn.md)，捕获前须根据实际当前文件核对其收据。先根据当前证据解决任何部分、冲突或不确定的应用；应用收据、候选预检或初步检查均不能替代实际状态指纹或最终 Verification。代码/配置/测试变化影响 implementation/content 维度；维护文档/注释变化影响 documentation 维度；改变可执行内容、Contract 或验收条件的文档还影响 implementation/content 维度。应用[Verification Epoch](../instructions/workflow-concepts--verification-and-repair--verification-epoch_zh_cn.md)，分别跟踪 implementation/content、documentation 和 Git metadata。只有指纹和 epoch 未变化的维度才能复用先前证据。当前状态或标准缺失/不确定时，返回 `needs_prerequisite` 或阻塞依赖验证。应用[任务计划 Memory 生命周期](../instructions/fundamental-concepts--execution-planning--task-plan-memory-lifecycle_zh_cn.md)：确认准确共享计划与当前读取访问，或其已记录的限制例外。独立验证者仅接收获授权计划/来源范围，可更新具名验证贡献，不得编辑被审实现。
3. **VR02 — 解析独立性要求。** 应用[Verification Independence](../instructions/workflow-concepts--verification-and-repair--verification-independence_zh_cn.md)和[Session 职责归属](../instructions/fundamental-concepts--session-runtime--session-role-ownership_zh_cn.md)。Contract 要求独立 Change Verification Session 时，使用该职责并仅提供给定范围证据和验收条件；否则将同 Session 检查分类为逻辑验证。在 Multi-Agent 执行中，Worker/子代理实际正文或结果是实施证据，不是独立验证；复用或完整可见也不满足必需的独立验证。必需的独立性不可用时返回 `needs_prerequisite`；不得声称满足 Contract。
4. **VR03 — 运行当前检查。** 针对 VR01 捕获的准确实际状态指纹运行适用的最强整体和定向检查。涵盖所有必需标准及变化维度所需检查。候选预检、应用收据和实施阶段检查仍是初步证据，不能替代这些当前检查。不得对受影响维度复用较早 epoch 的证据。必需检查不可运行时，保留不可用原因及阻塞影响。
5. **VR04 — 分类并报告证据。** 应用[Verification Reporting](../instructions/workflow-concepts--verification-and-repair--verification-reporting_zh_cn.md)和[Verification Epoch](../instructions/workflow-concepts--verification-and-repair--verification-epoch_zh_cn.md)。报告通过、失败、不可用和假设的检查、剩余风险、未解决项目及阻塞影响。只有在启用、符合条件、相关、已授权且绑定到当前指纹/epoch 时，才可通过[建议选择](../instructions/workflow-checkpoints--advisory-selection_zh_cn.md)和[Decisions Advisory](../instructions/fundamental-concepts--execution-planning--decisions-advisory_zh_cn.md)评估可选的 verification-impact 建议。它只能建议维度，不能免除检查或宣告成功。否则记录带原因的建议 `not_applicable`，并使用直接证据。 按计划 owner 规定的边界记录新验证事实；影响依赖动作的变化须在该动作前记录。确认持久化操作成功，并在依赖动作前完成 owner 要求的内容核验；必需访问、持久化或核验失败时阻塞该边界。遵守已记录的限制例外并保留验证独立性。
6. **VR05 — 路由失败或确立 Repair N/A。** 应用[Repair Disposition](../instructions/workflow-checkpoints--repair-disposition_zh_cn.md)。具体失败必须有诊断、受影响路径和最小候选；之后依次应用[Repair Scope Gate](../instructions/workflow-concepts--verification-and-repair--repair-scope-gate_zh_cn.md)、[Repair Execution](../instructions/workflow-concepts--verification-and-repair--repair-execution_zh_cn.md)及[Repair Verification Handoff](../instructions/workflow-concepts--verification-and-repair--repair-verification-handoff_zh_cn.md)。仅执行已授权的窄范围修复，保留实际变更路径/证据，并将新指纹/受影响 epoch 返回 VR01 进行当前重验。Contract 或 Decision 实质变化时，返回 `needs_prerequisite` 给调用方进行语义审查和调度；不得把它当作修复。无具体失败时，以证据依据记录 Repair `not_applicable` 并返回 VR01，确认当前 Verification 结果。诊断、授权、有界范围、修复证据或交接缺失时，阻塞依赖工作。
7. **VR06 — 返回当前最终 Verification。** 返回当前指纹、每个适用 epoch 及状态、标准与证据的映射、独立性分类、检查/结果类别、剩余风险、未解决项目和阻塞影响。仅当所有必需的当前 Verification 项目通过、必需的独立验证已满足、且没有未解决的必需修复/证据时返回 `complete`。此结果本身不宣告整体验收。
