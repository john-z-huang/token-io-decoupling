# Coding 委派 Worker 边界

[English](fundamental-concepts--delegation--delegation-worker-boundary.md) | [简体中文](fundamental-concepts--delegation--delegation-worker-boundary_zh_cn.md)

下列直接给出当前动作、守卫、证据和失败边界。应用独立政策前，先按明确的指令继续入口取得对应单元；同一构建中已持有的单元直接复用，并保留受影响动作的准确恢复位置。不读取作者文件或推测缺失政策。执行副作用前核实当前事实与授权；指令内容可用不表示检查通过。

## 硬约束

- 采取行动前记录用户、运行环境、仓库、权限、安全和 Session 硬约束。
- “不要创建子代理”“不要使用浏览器”等任务级禁止条件在整个任务中持续有效。
- 绝对禁止 Computer Use：不得通过图形界面控制计算机、浏览器或桌面应用——包括以操纵控件为目的的截图、鼠标／键盘模拟、点击、辅助功能 API、窗口自动化、远程桌面控制或 GUI 脚本——也不得把此类交互包装为 API、CLI、MCP Server、辅助程序或其他 Agent 调用来绕过。本节是黑名单而非允许渠道清单：当前 Session 实际暴露且已获授权的其他工具、命令或能力仍然允许。若必需步骤需要借助被禁止的操作，应停止并报告阻塞，而不是尝试、委派或跳过。
- 路线选择或任何委派/Session 拓扑工作前，模式检查点必须组合并验证委派 references；这些 references 在各自的原子边界内规定会话级模式选择及默认多代理路线和单个子代理预算、子代理数量、条件创建、分配、复用、替换、例外和限制。预留预算本身不会初始化或授权创建子代理。
- 不得虚构授权、能力、证据、产品支持，或为未维护场景推导可执行路线。
- Core 规则不依赖具体产品；受支持的运行环境分支和模型绑定见[运行环境与模型厂商支持](../instructions/fundamental-concepts--session-runtime--runtime-provider-support_zh_cn.md)。
- 按需读取 reference。不要仅因为可能以后有用，就预加载整个 Skill、`references/` 或原始项目状态。

# Coding 委派 Worker 边界

## 通用规范

### Worker 快照和访问边界

Worker 只能通过父级控制的 Dispatch 接收相关的已放行快照。不得推断、修改或替换根记录。Worker 只能在已放行范围内使用快照，并通过父级控制的路径返回所需事实。

### Dispatch 进入和持久化阻断

放行后，Worker 通过父级提供的 Dispatch Preview 进入，不重新打开根用户模式或数量门禁。运行时无法持久化或返回任务控制记录时，依赖该记录的路线被阻塞。

### 共享任务计划贡献

每个分配角色都应用[任务计划 Memory 生命周期](../instructions/fundamental-concepts--execution-planning--task-plan-memory-lifecycle_zh_cn.md)。派发指明准确项目与共享计划、允许贡献，以及实际获准的当前记录者写入轮次。Worker 仅确认已释放职责所需的访问；复用当前计划上下文，或在该 owner 的刷新条件触发时取得所需内容。在 owner 定义的边界，通过获准记录者或贡献路径提交带来源事实与进展；普通进度汇报不单独触发写入或全文读回。需求变化先记录再分析，分析/修订提议持久化并完成 owner 要求的核验后，才请求父级释放。影响授权、范围、验收、方向或依赖动作的事实，须在受影响动作前记录并分析。此具名贡献与 root 记录及可选执行 memo 分离，不授予源码/同级访问或 Contract 权威。验证者仅可贡献验证事实。缺少必需访问、持久化失败或必需核验失败时阻塞依赖工作，须向父级报告。

## Codex CLI / ChatGPT Desktop 特别优化指令

Codex 已配置的 `PreToolUse` Hook 可以通过 `Agent` 别名匹配本地 `spawn_agent` 工具；可用时，经测试后将其作为阻止未授权递归委派的辅助保护，同时遵循运行时真实工具／sandbox 限制。部分专用工具绕过 Hook，因此仅有提示词或 Hook 不证明递归或 peer 消息完全不可用。父级控制的创建／follow-up 权限与 Worker 权限必须分离。[OpenAI：Hooks 工具覆盖](https://learn.chatgpt.com/docs/hooks)。

### Worker 实际生效权限

Codex 自定义 Agent 文件可以设置 `developer_instructions`、`sandbox_mode`、具名 `mcp_servers` 和 `skills.config`，但省略字段会继承父级，spawn 时还可能重新应用父级的实时权限覆盖。必须检查最终 Child，而不是只信任文件内的目标 profile。安装并信任 `PreToolUse` Hook 时，可以在调用前匹配本地 `spawn_agent`／`Agent` 及实际暴露的 peer 操作；但覆盖范围之外的工具不受其完整保护，必须使用真实运行时／操作系统限制，否则阻塞依赖 Worker。[OpenAI：继承的子代理设置](https://learn.chatgpt.com/docs/agent-configuration/subagents)、[OpenAI：工具 Hook 覆盖例外](https://learn.chatgpt.com/docs/hooks)。

## Claude Code CLI / Claude Desktop 特别优化指令

### Worker 工具范围

对获准的 Claude Code 自定义 Worker，用 frontmatter `tools` 白名单和/或 `disallowedTools` 排除 `Agent` 及 peer messaging 工具。当前 Claude Code 中，Worker 具有 `Agent` 工具时可能继续创建嵌套子代理；纯文字禁止并不等于工具层边界。需要 MCP 时，只授予必需 Server/Tool，使用受支持的 `mcp__<server>` 模式禁止无关 MCP 工具；这限制的是工具可用性，不改变父级状态记录的所有权。项目/个人 Agent 定义可使用 `mcpServers` 限定范围，但插件自带 Agent 的该 frontmatter 字段会被忽略。不得假定 Desktop Chat 已安装同样的限制。

官方依据：[子代理工具、disallowedTools 与 MCP 范围](https://code.claude.com/docs/en/sub-agents)。

派发前应核验继承配置后**实际生效**的自定义 Agent 工具池符合已放行职责。父级到子代理的 `SendMessage` 和恢复权限留在 Worker 之外，不得把收窄的 `tools` 白名单当成已验证的逐路径文件系统边界。[Anthropic：子代理工具范围](https://code.claude.com/docs/en/sub-agents)。
