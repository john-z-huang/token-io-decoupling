# unit.5b0e93701a6ef118

[English](unit.5b0e93701a6ef118.md) | [简体中文](unit.5b0e93701a6ef118_zh_cn.md)

Apply the current instruction and its included policy sections below. The current actions, guards, evidence and failure boundary are given directly. Before applying a named independent policy, obtain its exact instruction continuation; reuse any already held unit from this build and retain the affected action's return position. Do not retrieve author files or infer omitted policy. Check current facts and authorization before effects; an instruction is not a pass.

## Hard constraints

- Record hard user, runtime environment, repository, permission, safety, and Session constraints before acting.
- A task-level prohibition, such as “do not create subagents” or “do not use a browser,” remains active for the whole task.
- Computer Use is categorically forbidden: never control a computer, browser, or desktop app through its graphical interface — no screenshots to locate controls, mouse or keyboard simulation, clicking, accessibility APIs, window automation, remote-desktop control, or GUI scripting — and do not route such interaction through an API, CLI, MCP server, helper, or another Agent. Treat this as a blacklist rather than a list of allowed channels: every other tool, command, or capability actually exposed to and authorized for the current Session remains permitted. If a required step needs a forbidden operation, stop and report the blocker instead of attempting, delegating, or skipping it.
- Before route selection or any delegation/Session-topology work, the Mode checkpoint must compose and validate the delegation references; those references own conversation-level mode selection with a default Multi-Agent route and one-child budget, child counts, conditional creation, allocation, reuse, replacement, exceptions, and limits at their respective atomic boundaries. A reserved budget never initializes or authorizes a child by itself.
- Never invent authorization, capability, evidence, product support, or an executable route for an unmaintained scenario.
- Keep Core rules independent of product details; read Runtime and Model Provider Support (instruction continuation: [unit.081374cfbaa37b57](../instructions/unit.081374cfbaa37b57.md)) for supported runtime branches and model bindings.
- Read references on demand. Do not preload the entire Skill, `references/`, or raw project state merely because it may become useful.

# Coding Delegation Re-entry

## General rules

### Gate re-entry

A later root directive in the same host-identified Session lifetime reuses the locked mode and current child-count budget; it does not reopen mode selection or replace the session decision. A later turn, compaction, or same-Session resume does not reset these gates. The only same-Session count change is the exact one-slot increase authorized by the Delegation Count Gate (instruction continuation: [unit.36a14d319d1b638c](../instructions/unit.36a14d319d1b638c.md)) after actual explicit user approval for a different unoccupied role. That transaction changes the count only; it does not reselect the mode, release a slice, or create a child. Other requested count or topology changes block dependent work until a new Session. Refresh task-specific Contract, slices, allocations' current lifecycle, and capability evidence as needed.

A Fork starts a new conversation with a new Session identity. Before any dependent work, perform fresh mode confirmation, count selection, and state-record initialization even if the source conversation used Single-Agent mode. Treat inherited child identities as foreign to the new Session: do not adopt them as created, reserved, resumable, or eligible current-session candidates. Build the new record from this conversation's current user direction and state; do not carry over the source conversation's locked mode/count decision as if it were newly selected.

### Higher-priority constraints and capability blocks

Higher-priority user, permission, security, product, runtime, capability, repository, and safety constraints always apply. An unavailable capability blocks the route; it never authorizes silently changing mode or count.

## Codex CLI / ChatGPT Desktop optimizations

No provider-specific optimization instructions at present; follow the general rules above.

## Claude Code CLI / Claude Desktop optimizations

No provider-specific optimization instructions at present; follow the general rules above.
