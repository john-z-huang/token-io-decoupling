# route.single_agent.return_map

[English](route.single_agent.return_map.md) | [简体中文](route.single_agent.return_map_zh_cn.md)

Apply the current instruction and its included policy sections below. The current actions, guards, evidence and failure boundary are given directly. Before applying a named independent policy, obtain its exact instruction continuation; reuse any already held unit from this build and retain the affected action's return position. Do not retrieve author files or infer omitted policy. Check current facts and authorization before effects; an instruction is not a pass.

## Outer route scheduling context

The selector states entry prerequisites. Before initial route entry complete missing prerequisites; after entry verify held current pass evidence without replaying gates or prompts. The selected route below owns cross-module returns. Resume only the recorded caller/substep after producer readback and epoch/effect checks; the current module body does not replace this schedule.

## Prerequisite return map

Resolve only the missing item at its producer/recheck location. Keep the original caller module/substep and its completed effects as a continuation stack entry; if resolving the prerequisite itself suspends, preserve that producer continuation too. After producer completion, read back its evidence and recheck relevant epochs/effects, then resume only the original caller position, not the producer position or the next route module. Do not replay effects, reopen released Mode, or repeat a completed prompt. Contract/Environment/Mode evidence gaps are read-only completion at the existing owner; re-enter Route Entry only when material route facts change, then return to the original caller while retaining the locked Mode. Unknown producer/position/effects or a loop with no new evidence blocks dependent work.

| Missing prerequisite | Producer/recheck location | Resume after readback |
| --- | --- |
| Contract or acceptance scope | Coding workflow Contract checkpoint; fill missing evidence only. | Original suspended module/substep, such as SM07; do not start at SM01. |
| Environment/capability inventory | Environment and capability-inventory owners; read/complete missing inventory only. | Original suspended module/substep; Route Entry only if a material route fact changed. |
| Route Entry evidence or material route fact | Route Entry owner, only for changed route facts; do not repeat a locked Mode choice. | Original suspended module/substep if the route remains valid; otherwise block the invalid route. |
| Released Mode evidence missing or inconsistent | Existing Mode owner and locked record readback; do not ask again for a released choice. | Original suspended module/substep when Single-Agent evidence is current; conflict blocks. |
| Session state, authority, or audit | SM02's SR02/SR03 and the specific Session/state/audit owner returned by it. | Original suspended module/substep after Session evidence is read back; SM02 itself resumes its producer substep if that is the suspended caller. |
| Context, Decision, planning output, or advice | SM03's WD01–WD03 and the specific Context/Decision/planning/advice owner. | Original suspended module/substep after evidence is current; a caller at SM07 returns to SM07, not SM03. |
| Executor/output, Slice, feedback, or Control | SM04's SE01–SE05 and the responsible owner. | Original suspended module/substep; a caller at SM07 returns to SM07, not SM04. |
| Verification, repair diagnosis, or handoff | SM05's VR01–VR05 and the responsible owner. | Original suspended module/substep after current evidence/handoff; SM06 returns to its suspended DOC substep after verification. |
| Documentation impact, owner-required Memory content verification, or required checks | SM06's DOC01–DOC06 and the specific Documentation/Memory/check owner. | Original suspended module/substep, including DOC after a verification return. |
| Git target/effect or Acceptance criteria/archive | SM07's DA02–DA05 and the Git/Acceptance/plan owner. | Original suspended DA substep after the producer evidence is read back. |
