# Output Materialization

[English](fundamental-concepts--execution-planning--output-materialization.md) | [简体中文](fundamental-concepts--execution-planning--output-materialization_zh_cn.md)

Apply the current instruction and its included policy sections below. The current actions, guards, evidence and failure boundary are given directly. Before applying a named independent policy, obtain its exact instruction continuation; reuse any already held unit from this build and retain the affected action's return position. Do not retrieve author files or infer omitted policy. Check current facts and authorization before effects; an instruction is not a pass.

## Hard constraints

- Record hard user, runtime environment, repository, permission, safety, and Session constraints before acting.
- A task-level prohibition, such as “do not create subagents” or “do not use a browser,” remains active for the whole task.
- Computer Use is categorically forbidden: never control a computer, browser, or desktop app through its graphical interface — no screenshots to locate controls, mouse or keyboard simulation, clicking, accessibility APIs, window automation, remote-desktop control, or GUI scripting — and do not route such interaction through an API, CLI, MCP server, helper, or another Agent. Treat this as a blacklist rather than a list of allowed channels: every other tool, command, or capability actually exposed to and authorized for the current Session remains permitted. If a required step needs a forbidden operation, stop and report the blocker instead of attempting, delegating, or skipping it.
- Before route selection or any delegation/Session-topology work, the Mode checkpoint must compose and validate the delegation references; those references own conversation-level mode selection with a default Multi-Agent route and one-child budget, child counts, conditional creation, allocation, reuse, replacement, exceptions, and limits at their respective atomic boundaries. A reserved budget never initializes or authorizes a child by itself.
- Never invent authorization, capability, evidence, product support, or an executable route for an unmaintained scenario.
- Keep Core rules independent of product details; read [Runtime and Model Provider Support](../instructions/fundamental-concepts--session-runtime--runtime-provider-support.md) for supported runtime branches and model bindings.
- Read references on demand. Do not preload the entire Skill, `references/`, or raw project state merely because it may become useful.

# Output Materialization

## General rules

### Keep preparation, review, and application distinct

Prepare output only when the current assignment, operation-specific grant, pinned roots, exact paths, and required safety capabilities are verified for the current call. A role assignment, tool discovery, capability listing, or ordinary write permission does not substitute for a separate matching grant. If the required context or guard is missing, stale, revoked, or ambiguous, stop without guessing a path or capability.

Preparation creates a bounded candidate artifact outside the project and must not be described as a project write. Preserve its identifier and manifest hash. Inspect only bounded portions and review the candidate before application. Apply the same prepared candidate only after rechecking current authority, artifact integrity, baselines, and a fresh whole-batch preflight for the pinned project. Do not regenerate content during apply or treat a prior preflight as current authorization.

Use only the finite locally rendered templates and declared limits. Any optional semantic service may select among supplied fact identifiers only; local code retains supplied facts and renders the output. Missing configuration, refusal, invalid response, stale context, or limit failure stops preparation without substituting free-form output. Do not infer zero usage when a service does not report usage.

Application is bounded by exact authorized paths and operations. Recheck current file state, preserve external changes, and inspect receipts and actual files after partial or uncertain outcomes. A same-candidate replay must not overwrite a later user change. Cooperative locks do not protect against unrelated writers; a multi-file batch may be partially applied and has no promised global rollback. When state is uncertain or authority has changed, stop and resolve from current evidence before preparing a new candidate.

This capability is optional. Native output work may continue under its own authorized route when this capability is unavailable. Never treat unavailable as success or weaken the relevant role, permission, or verification owner.

## Codex CLI / ChatGPT Desktop optimizations

The current MCP operation is `materialize_decoupled_output` with `payload.request` action `prepare`, `inspect`, or `apply`. It requires a trusted startup-injected authorization provider that supplies current Worker binding and assignment context, a separate operator grant, pinned project/artifact roots, and required read-only compliance preflight. The service checks that provider context matches the actual per-call Worker binding and rechecks authority across phases. Tool payloads cannot select or supply authority context. No standard provider is configured; without the trusted provider and grant, the capability is unavailable and no default root is guessed.

The supported role is `Primary Output` with output class `code_configuration` and policy scope `generic_project`. Project-specific Skill authoring belongs to the private development Skill; ordinary documentation and other roles/classes are unsupported. Policy version 2 has finite `literal_text`, `json_document`, and `fact_markdown` templates. `prepare` stores a candidate outside the project; `inspect` reads a bounded page; `apply` rechecks current grant, assignment, hashes, baselines, and whole-batch preflight before writing. Keep and pass the same manifest hash. Review per-file and batch receipts, especially `partial`, `conflict`, or `uncertain`; do not assume rollback or retry over changed content. The MCP output-materialization contract owns exact request fields, limits, and recovery classifications.

For the optional fact-ordering request, follow the fixed API contract stated in the actual MCP tool metadata; the model can return only an ordering of supplied fact IDs. This tool contract does not inspect or change the Agent Session's model. Agent runtime, model, and effort bindings belong to [Runtime and Model Provider Support](../instructions/fundamental-concepts--session-runtime--runtime-provider-support.md).

## Claude Code CLI / Claude Desktop optimizations

This repository's MCP Server supports local Codex CLI only. Claude's generic MCP capability does not make this server a supported direct client, and no Claude-specific direct-tool optimization is defined. Follow the general rules using capabilities actually exposed and authorized in the current Session. If this controlled capability is unavailable, use any independently authorized direct output route and its verification requirements.
