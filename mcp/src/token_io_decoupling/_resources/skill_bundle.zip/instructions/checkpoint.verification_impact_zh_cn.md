# checkpoint.verification_impact_zh_cn

[English](checkpoint.verification_impact.md) | [简体中文](checkpoint.verification_impact_zh_cn.md)

下列直接给出当前动作、守卫、证据和失败边界。应用独立政策前，先按明确的指令继续入口取得对应单元；同一构建中已持有的单元直接复用，并保留受影响动作的准确恢复位置。不读取作者文件或推测缺失政策。执行副作用前核实当前事实与授权；指令内容可用不表示检查通过。

## 硬约束

- 采取行动前记录用户、运行环境、仓库、权限、安全和 Session 硬约束。
- “不要创建子代理”“不要使用浏览器”等任务级禁止条件在整个任务中持续有效。
- 绝对禁止 Computer Use：不得通过图形界面控制计算机、浏览器或桌面应用——包括以操纵控件为目的的截图、鼠标／键盘模拟、点击、辅助功能 API、窗口自动化、远程桌面控制或 GUI 脚本——也不得把此类交互包装为 API、CLI、MCP Server、辅助程序或其他 Agent 调用来绕过。本节是黑名单而非允许渠道清单：当前 Session 实际暴露且已获授权的其他工具、命令或能力仍然允许。若必需步骤需要借助被禁止的操作，应停止并报告阻塞，而不是尝试、委派或跳过。
- 路线选择或任何委派/Session 拓扑工作前，模式检查点必须组合并验证委派 references；这些 references 在各自的原子边界内规定会话级模式选择及默认多代理路线和单个子代理预算、子代理数量、条件创建、分配、复用、替换、例外和限制。预留预算本身不会初始化或授权创建子代理。
- 不得虚构授权、能力、证据、产品支持，或为未维护场景推导可执行路线。
- Core 规则不依赖具体产品；受支持的运行环境分支和模型绑定见运行环境与模型厂商支持 (instruction continuation: [unit.081374cfbaa37b57](../instructions/unit.081374cfbaa37b57_zh_cn.md))。
- 按需读取 reference。不要仅因为可能以后有用，就预加载整个 Skill、`references/` 或原始项目状态。

# 验证 Epoch 检查点


本检查点负责按验证覆盖状态维度处理 epoch 失效。后续修改只推进其改变了验证覆盖范围的维度；未受影响维度的早期证据仍然有效。不定义检查内容、独立 Session、结果分类或修复。

## 动作

1. 跟踪三个维度：implementation/content、documentation 和 Git metadata。
2. 当实现、配置、测试或其他被产品验证覆盖的内容发生变化时，推进 implementation/content epoch；该内容的早期产品验证失效。
3. 当维护中的文档或注释发生变化时，推进 documentation epoch，并运行适用的 Markdown、链接、空白、多语言和范围检查。如果变化改动了可执行内容、Contract 或验收条件，还必须同时视为 implementation/content 变化，返回实现 Verification。
4. 当 commit、branch、index 或 history 状态发生变化时，推进 Git metadata epoch。仅 Git metadata 操作不会推进 implementation/content 或 documentation epoch。但 Git 状态仍须经过 Git 检查点确认 staged 或 committed content 与最新验证指纹一致；内容发生差异或包含未验证内容时，返回对应的 Verification epoch。
5. 不得将受影响维度的早期 epoch 证据用于当前状态；必须完成新 epoch 所需的检查或 Verification。

6. 路线提供 verification-impact 建议输出时，仅将其视为覆盖维度建议。必须根据当前 fingerprint 和直接 owner 核验候选维度；它不是验证结论，不能免除变化维度所需的检查或重新验证。依据当前证据确定必需覆盖。建议政策遵循Decisions 建议 (instruction continuation: [unit.4d827a8a683055da](../instructions/unit.4d827a8a683055da_zh_cn.md))。

## 通过条件

最新的 implementation/content、documentation 和 Git metadata 适用 epoch 已明确，各自所需的检查或 Verification 已排队或完成，且没有任何受影响维度依赖过期证据。

## 边界

本检查点不捕获指纹，不选择检查，不定义独立验证，不分类结果，不授权修复，不写文档，也不产生 Git 影响。
