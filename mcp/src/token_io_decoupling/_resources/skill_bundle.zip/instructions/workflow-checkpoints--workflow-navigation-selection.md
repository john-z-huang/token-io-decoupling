# Workflow Navigation Selection

[English](workflow-checkpoints--workflow-navigation-selection.md) | [简体中文](workflow-checkpoints--workflow-navigation-selection_zh_cn.md)

Apply the current instruction and its included policy sections below. The current actions, guards, evidence and failure boundary are given directly. Before applying a named independent policy, obtain its exact instruction continuation; reuse any already held unit from this build and retain the affected action's return position. Do not retrieve author files or infer omitted policy. Check current facts and authorization before effects; an instruction is not a pass.

## Hard constraints

- Record hard user, runtime environment, repository, permission, safety, and Session constraints before acting.
- A task-level prohibition, such as “do not create subagents” or “do not use a browser,” remains active for the whole task.
- Computer Use is categorically forbidden: never control a computer, browser, or desktop app through its graphical interface — no screenshots to locate controls, mouse or keyboard simulation, clicking, accessibility APIs, window automation, remote-desktop control, or GUI scripting — and do not route such interaction through an API, CLI, MCP server, helper, or another Agent. Treat this as a blacklist rather than a list of allowed channels: every other tool, command, or capability actually exposed to and authorized for the current Session remains permitted. If a required step needs a forbidden operation, stop and report the blocker instead of attempting, delegating, or skipping it.
- Before route selection or any delegation/Session-topology work, the Mode checkpoint must compose and validate the delegation references; those references own conversation-level mode selection with a default Multi-Agent route and one-child budget, child counts, conditional creation, allocation, reuse, replacement, exceptions, and limits at their respective atomic boundaries. A reserved budget never initializes or authorizes a child by itself.
- Never invent authorization, capability, evidence, product support, or an executable route for an unmaintained scenario.
- Keep Core rules independent of product details; read [Runtime and Model Provider Support](../instructions/fundamental-concepts--session-runtime--runtime-provider-support.md) for supported runtime branches and model bindings.
- Read references on demand. Do not preload the entire Skill, `references/`, or raw project state merely because it may become useful.

# Workflow Navigation Selection


This checkpoint selects the current compiled instruction delivery surface and any useful optional structural input check. Delivery and structural results remain separate from independently judging task facts and completion.

## Trigger and inputs

Use current [Environment](../instructions/workflow-concepts--entry-and-context--environment.md) and [capability inventory](../instructions/workflow-concepts--entry-and-context--environment-capability-inventory.md) results. Consult [Workflow Navigation Availability](../instructions/fundamental-concepts--workflow-navigation--navigation-availability.md) and [Workflow Rule Context](../instructions/fundamental-concepts--workflow-navigation--rule-context.md) when optional navigation may help. If a structural check of supplied checkpoint facts may help, apply [Checkpoint Structural Checks](../instructions/fundamental-concepts--workflow-navigation--checkpoint-structure-checks.md). Both aids are optional unless the task independently requires their result.

## Decision and result

1. Identify the current instruction unit and any explicitly named continuation needed by this action; retain the exact suspended position and completed effects.
2. If optional navigation is useful and available, consume its current complete instruction text. Verify language, resource/build identity and completeness; none establishes identity, permission, semantic truth, checkpoint completion, sequencing or acceptance.
3. If structural checking is useful, compare its result with supplied input and current compiled instructions, then judge evidence meaning independently. A structural result never establishes authorization or semantic truth.
4. When an optional aid is unnecessary, record `Not applicable` with a reason. Consume the corresponding delivered instruction directly, without looking up author documents.
5. If optional navigation is unavailable, an actually available, authorized same-build generated document-only instruction surface may provide the explicit current unit. Missing, incomplete or incompatible required resources block dependent judgment; resource errors never authorize author-source fallback.
6. Return the selected source and any requested structural result for review. This decision does not change workflow state, authorize an action, or establish a checkpoint result.

## Failure boundary

| Result | Required action |
| --- | --- |
| Optional navigation is not needed | Record `Not applicable`; consume the required delivered instruction directly. |
| Bounded navigation is available | Review current complete text and exact continuations; independently judge facts. |
| Optional structural checking is not needed or unavailable | Record `Not applicable` with the reason; continue from current compiled instructions unless the task independently requires that result. |
| Structural check is available and selected | Compare its result with current instructions and supplied input; judge evidence independently. |
| Navigation is unavailable but same-build generated instructions are accessible | Consume the exact delivered unit and record the limitation. |
| Required instruction resources are unavailable, incomplete or incompatible | Block dependent judgment; do not infer policy, skip guards or read author sources. |
