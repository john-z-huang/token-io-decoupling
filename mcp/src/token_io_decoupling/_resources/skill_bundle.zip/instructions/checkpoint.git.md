# checkpoint.git

[English](checkpoint.git.md) | [简体中文](checkpoint.git_zh_cn.md)

Apply the current instruction and its included policy sections below. The current actions, guards, evidence and failure boundary are given directly. Before applying a named independent policy, obtain its exact instruction continuation; reuse any already held unit from this build and retain the affected action's return position. Do not retrieve author files or infer omitted policy. Check current facts and authorization before effects; an instruction is not a pass.

## Hard constraints

- Record hard user, runtime environment, repository, permission, safety, and Session constraints before acting.
- A task-level prohibition, such as “do not create subagents” or “do not use a browser,” remains active for the whole task.
- Computer Use is categorically forbidden: never control a computer, browser, or desktop app through its graphical interface — no screenshots to locate controls, mouse or keyboard simulation, clicking, accessibility APIs, window automation, remote-desktop control, or GUI scripting — and do not route such interaction through an API, CLI, MCP server, helper, or another Agent. Treat this as a blacklist rather than a list of allowed channels: every other tool, command, or capability actually exposed to and authorized for the current Session remains permitted. If a required step needs a forbidden operation, stop and report the blocker instead of attempting, delegating, or skipping it.
- Before route selection or any delegation/Session-topology work, the Mode checkpoint must compose and validate the delegation references; those references own conversation-level mode selection with a default Multi-Agent route and one-child budget, child counts, conditional creation, allocation, reuse, replacement, exceptions, and limits at their respective atomic boundaries. A reserved budget never initializes or authorizes a child by itself.
- Never invent authorization, capability, evidence, product support, or an executable route for an unmaintained scenario.
- Keep Core rules independent of product details; read Runtime and Model Provider Support (instruction continuation: [unit.081374cfbaa37b57](../instructions/unit.081374cfbaa37b57.md)) for supported runtime branches and model bindings.
- Read references on demand. Do not preload the entire Skill, `references/`, or raw project state merely because it may become useful.

# Git Checkpoint


## Actions

1. Confirm the exact repository, worktree, branch or ref, remote, operation, and intended external effect.
2. Inspect status and relevant history before mutating Git state. Do not include unrelated user changes.
3. Treat commit, branch, index, and history changes as Git metadata operations that do not automatically invalidate the implementation/content or documentation epoch.
4. Confirm that staged or committed content matches the latest verified fingerprints and contains no unverified content. If it differs, return to the corresponding implementation/content or documentation Verification epoch before continuing.
5. Keep commit, push, Issue, PR, remote changes, and other external effects separate unless each effect is explicitly authorized.
6. Record the latest applicable implementation/content and documentation epochs that the Git operation targets.
7. Stop on an ambiguous target, unexpected conflict, missing authorization, or failed prerequisite; do not broaden the operation to recover.

## Pass condition

The authorized Git operation completes against the exact target, records the latest applicable content and documentation epochs, and matches their verified fingerprints; otherwise the unavailable authorization, conflict, prerequisite, or required Verification return is reported.

## Boundary

This checkpoint does not grant product decision authority, permit unrequested cleanup, or turn a possible Git effect into an authorized one.
