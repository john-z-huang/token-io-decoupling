# unit.6063588dfa2ee6c4_zh_cn

[English](unit.6063588dfa2ee6c4.md) | [简体中文](unit.6063588dfa2ee6c4_zh_cn.md)

下列直接给出当前动作、守卫、证据和失败边界。应用独立政策前，先按明确的指令继续入口取得对应单元；同一构建中已持有的单元直接复用，并保留受影响动作的准确恢复位置。不读取作者文件或推测缺失政策。执行副作用前核实当前事实与授权；指令内容可用不表示检查通过。

## 硬约束

- 采取行动前记录用户、运行环境、仓库、权限、安全和 Session 硬约束。
- “不要创建子代理”“不要使用浏览器”等任务级禁止条件在整个任务中持续有效。
- 绝对禁止 Computer Use：不得通过图形界面控制计算机、浏览器或桌面应用——包括以操纵控件为目的的截图、鼠标／键盘模拟、点击、辅助功能 API、窗口自动化、远程桌面控制或 GUI 脚本——也不得把此类交互包装为 API、CLI、MCP Server、辅助程序或其他 Agent 调用来绕过。本节是黑名单而非允许渠道清单：当前 Session 实际暴露且已获授权的其他工具、命令或能力仍然允许。若必需步骤需要借助被禁止的操作，应停止并报告阻塞，而不是尝试、委派或跳过。
- 路线选择或任何委派/Session 拓扑工作前，模式检查点必须组合并验证委派 references；这些 references 在各自的原子边界内规定会话级模式选择及默认多代理路线和单个子代理预算、子代理数量、条件创建、分配、复用、替换、例外和限制。预留预算本身不会初始化或授权创建子代理。
- 不得虚构授权、能力、证据、产品支持，或为未维护场景推导可执行路线。
- Core 规则不依赖具体产品；受支持的运行环境分支和模型绑定见运行环境与模型厂商支持 (instruction continuation: [unit.081374cfbaa37b57](../instructions/unit.081374cfbaa37b57_zh_cn.md))。
- 按需读取 reference。不要仅因为可能以后有用，就预加载整个 Skill、`references/` 或原始项目状态。

# Coding 会话审计可见性

## 通用规范

### 配置值

根父级负责会话配置。用户可选择 `audit_mode`、`root_reasoning_cadence` 和 `worker_reasoning_cadence`；每个字段分别记录来源。这些是 Skill 策略，不是产品原生开关。

```yaml
audit_mode: balanced
root_reasoning_cadence: milestone_only
worker_reasoning_cadence: full
source: {audit_mode: default, root_reasoning_cadence: default, worker_reasoning_cadence: default}
```

| 字段 | 合法值 | 默认值 | 含义 |
| --- | --- | --- | --- |
| `audit_mode` | `economy`、`balanced`、`full` | `balanced` | 选择 Root 可见副本预设。 |
| `root_reasoning_cadence` | `full`、`milestone_only`、`off` | `milestone_only` | 选择 Root 可选摘要频率。 |
| `worker_reasoning_cadence` | `full`、`milestone_only`、`off` | `full` | 独立选择 Worker 可选摘要频率。 |
| `source.<field>` | 每个可选字段分别为 `explicit`、`default` | `default` | `explicit` 表示用户选择了该字段；`default` 表示由策略提供。 |
Root 父级可随时接受用户显式偏好。未提供值时立即应用缺省值；不得将提问、计时器或回复设为 Coding 工作的前置条件。

任务记录结构由委派状态记录 (instruction continuation: [unit.04519b62e6c4f711](../instructions/unit.04519b62e6c4f711_zh_cn.md))定义。适用工作流检查点记录生效值及其显式/缺省来源。

### 可见副本预设

所有预设下，完整实际安全任务正文和返回正文都必须可取得。Root 在依赖 Worker 返回前完整读取实际正文。预设仅控制 Root 展示的可见副本，不降低证据要求或 Worker 可见性。Worker 消息及安全正文规则遵循子代理消息可见性 (instruction continuation: [unit.5fcfa7ba9fb0828d](../instructions/unit.5fcfa7ba9fb0828d_zh_cn.md))。

| 预设 | Root 出站可见副本 | Root 入站可见副本 |
| --- | --- | --- |
| `economy` | 最多 3 项的 preview：目标、允许改动、返回条件。 | 与决策相关的摘要。 |
| `balanced` | 仅在下述确定触发条件时展示完整相关安全消息；否则使用 `economy` preview。 | 仅在下述确定触发条件时展示完整相关安全消息；否则使用 `economy` 摘要。 |
| `full` | 完整安全消息正文。 | 完整安全消息正文。 |

对 `economy`/`balanced` preview，按实际展示的 Markdown 源文本计数，包括空白、链接文字和链接目标：最多 3 项、600 个 Unicode 码位。入站摘要对应上限为 5 项、800 个 Unicode 码位；字段依次为结论、证据指针、关键依据、风险/阻塞、下一步，无值时省略。按字符而非 token 计数，无需逐条消息调用计数工具。完整正文须单独保持可用。若更高优先级指令或重要授权/失败证据无法容纳，只允许必要超限并说明原因；不得静默截断或拆分副本规避预算。预算不限制全文展示或 Worker 可见性。摘要不得泄露私有推理。

`economy` 仍允许并要求必要的面向用户进度、授权、失败、验证、阶段验收和最终报告。这些报告不能替代完整实际正文或其审阅。

### `balanced` 全文展示触发条件

仅在出现可观察事件时展示完整相关安全消息：已批准的 Contract 目标、验收条件、路径或允许影响发生变化；明确授予或撤回授权；已执行检查失败或证据直接冲突/存在争议；或用户要求精确审计本次交换。完全在既有 Contract 内执行的新切片不构成触发条件。若无法确定是否触发，保留事实供 Root 判断。不得自动将所有消息升级为 `full`。

### Worker 日志可见性

`worker_log_visibility` 描述当前 Session 对完整安全 Worker 入站/出站会话记录的访问能力；它既不是 Root 收到的最终返回正文，也不是原始加密运行日志。`available` 必须有直接证据能定位完整记录；仅工具存在不足以证明。`unverified` 表示没有肯定的成功/失败证据，包括尚未检查。`unavailable` 必须有能力明确缺失、访问失败或等价负面证据。仅未创建 Worker 时可使用 `Not applicable`，并在证据字段记录原因。

首次需要 Worker 日志证据时检查一次；仅在出现新的实际访问/能力证据或失败时更新，不逐消息检查。任务明确依赖此日志证据时，不可用/未验证状态会阻塞该审计依赖。否则报告限制并继续；完整实际返回正文仍是硬要求。

### 摘要频率

Root 和 Worker 分别应用各自的频率。摘要回合边界和内容格式遵循推理摘要可见性 (instruction continuation: [unit.d97fa46d10460df3](../instructions/unit.d97fa46d10460df3_zh_cn.md))。`full` 在每个已完成边界输出必需的安全摘要。`milestone_only` 在以下可观察事件时输出：

| 事件 | 输出条件 |
| --- | --- |
| 实质决策 | 新确认或变更的选择会改变下一切片执行方式或验收标准；常规读取或命令选择不算。 |
| 授权变化 | 明确授予或撤回某项允许影响的权限。 |
| 验证失败 | 已执行检查失败，或当前验收条件有直接失败证据。 |
| 阻塞 | 已授权的下一步因必需权限、能力或证据确实缺失而无法继续。 |
| 阶段验收 | Root 最终接受已声明的阶段证据并放行下一阶段；普通进度不算验收。 |

按“事件类别 + 相关决策/证据 epoch”去重。每个事实只输出一次，同一回合多个触发合并；只有相关事实或 epoch 实质变化才再次输出。不得按经过时间或重复活动推断实质性。`off` 仅抑制可选摘要；必需报告、证据、Control 更新、Progress Signal 和更高层周期更新仍然必需。任何频率都不允许披露私有推理。

## Codex CLI / ChatGPT Desktop 特别优化指令

目前没有该概念的厂商专用优化。仅使用当前 Session 实际可用的能力和证据遵循通用规范。

## Claude Code CLI / Claude Desktop 特别优化指令

目前没有该概念的厂商专用优化。仅使用当前 Session 实际可用的能力和证据遵循通用规范。
