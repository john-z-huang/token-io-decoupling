# unit.8e91c00a9ae84af0_zh_cn

[English](unit.8e91c00a9ae84af0.md) | [简体中文](unit.8e91c00a9ae84af0_zh_cn.md)

下列直接给出当前动作、守卫、证据和失败边界。应用独立政策前，先按明确的指令继续入口取得对应单元；同一构建中已持有的单元直接复用，并保留受影响动作的准确恢复位置。不读取作者文件或推测缺失政策。执行副作用前核实当前事实与授权；指令内容可用不表示检查通过。

## 硬约束

- 采取行动前记录用户、运行环境、仓库、权限、安全和 Session 硬约束。
- “不要创建子代理”“不要使用浏览器”等任务级禁止条件在整个任务中持续有效。
- 绝对禁止 Computer Use：不得通过图形界面控制计算机、浏览器或桌面应用——包括以操纵控件为目的的截图、鼠标／键盘模拟、点击、辅助功能 API、窗口自动化、远程桌面控制或 GUI 脚本——也不得把此类交互包装为 API、CLI、MCP Server、辅助程序或其他 Agent 调用来绕过。本节是黑名单而非允许渠道清单：当前 Session 实际暴露且已获授权的其他工具、命令或能力仍然允许。若必需步骤需要借助被禁止的操作，应停止并报告阻塞，而不是尝试、委派或跳过。
- 路线选择或任何委派/Session 拓扑工作前，模式检查点必须组合并验证委派 references；这些 references 在各自的原子边界内规定会话级模式选择及默认多代理路线和单个子代理预算、子代理数量、条件创建、分配、复用、替换、例外和限制。预留预算本身不会初始化或授权创建子代理。
- 不得虚构授权、能力、证据、产品支持，或为未维护场景推导可执行路线。
- Core 规则不依赖具体产品；受支持的运行环境分支和模型绑定见运行环境与模型厂商支持 (instruction continuation: [unit.081374cfbaa37b57](../instructions/unit.081374cfbaa37b57_zh_cn.md))。
- 按需读取 reference。不要仅因为可能以后有用，就预加载整个 Skill、`references/` 或原始项目状态。

# Coding 路线入口


本检查点负责路线前验证组合及唯一获授权路线选择结果。

## 触发与输入

Coding 入口在Contract 检查点 (instruction continuation: [unit.e452c36c913b5771](../instructions/unit.e452c36c913b5771_zh_cn.md))、Environment 检查点 (instruction continuation: [unit.b92847af78d7f2a7](../instructions/unit.b92847af78d7f2a7_zh_cn.md))、能力清单 (instruction continuation: [unit.552ba8ac1f0543db](../instructions/unit.552ba8ac1f0543db_zh_cn.md))和Mode 检查点 (instruction continuation: [unit.bba9c45137f16455](../instructions/unit.bba9c45137f16455_zh_cn.md))通过后调用本检查点。输入为各项当前结果，包括已释放的 mode/count 及未解决的失败。

## 决策与结果

确认所有必需门禁均已完成，只选择 Mode 授权的路线，并向调用方返回所选路线标识和门禁证据，由调用方加载并核验。

## 失败边界

若前置项缺失、矛盾或尚未释放，返回对应入口检查点并停止依赖该结果的路线工作。不得重新解释 Mode、选择后备路线或在此初始化路线专用状态。
