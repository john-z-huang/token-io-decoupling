# Session Readiness Module

[English](workflows--modules--session-readiness.md) | [简体中文](workflows--modules--session-readiness_zh_cn.md)

Apply the current instruction and its included policy sections below. The current actions, guards, evidence and failure boundary are given directly. Before applying a named independent policy, obtain its exact instruction continuation; reuse any already held unit from this build and retain the affected action's return position. Do not retrieve author files or infer omitted policy. Check current facts and authorization before effects; an instruction is not a pass.

## Hard constraints

- Record hard user, runtime environment, repository, permission, safety, and Session constraints before acting.
- A task-level prohibition, such as “do not create subagents” or “do not use a browser,” remains active for the whole task.
- Computer Use is categorically forbidden: never control a computer, browser, or desktop app through its graphical interface — no screenshots to locate controls, mouse or keyboard simulation, clicking, accessibility APIs, window automation, remote-desktop control, or GUI scripting — and do not route such interaction through an API, CLI, MCP server, helper, or another Agent. Treat this as a blacklist rather than a list of allowed channels: every other tool, command, or capability actually exposed to and authorized for the current Session remains permitted. If a required step needs a forbidden operation, stop and report the blocker instead of attempting, delegating, or skipping it.
- Before route selection or any delegation/Session-topology work, the Mode checkpoint must compose and validate the delegation references; those references own conversation-level mode selection with a default Multi-Agent route and one-child budget, child counts, conditional creation, allocation, reuse, replacement, exceptions, and limits at their respective atomic boundaries. A reserved budget never initializes or authorizes a child by itself.
- Never invent authorization, capability, evidence, product support, or an executable route for an unmaintained scenario.
- Keep Core rules independent of product details; read [Runtime and Model Provider Support](../instructions/fundamental-concepts--session-runtime--runtime-provider-support.md) for supported runtime branches and model bindings.
- Read references on demand. Do not preload the entire Skill, `references/`, or raw project state merely because it may become useful.

# Session Readiness Module


This Layer-04 module establishes a current, verified Session record and audit result for bounded downstream work. It composes the Session owners and returns evidence to its caller; it does not reopen Mode, produce a plan/decision output, or schedule other modules.

## Entry declaration

| Field | Requirement |
| --- | --- |
| Required inputs | Current task scope and Contract, released entry/route/mode evidence, current Session identity/role facts, and the parent-controlled record source. The record is confirmed here, not an entry prerequisite. |
| Permitted effects | Read and confirm current Session facts and parent-controlled record; apply audit preferences to that record when authorized under its owner. |
| Results | The module returns `complete` with current Session facts, canonical parent-context record readback, effective audit preferences, and Multi-Agent capacity evidence when applicable; otherwise return `needs_prerequisite` with suspended position or `blocked`. Conditional substeps may be `not_applicable` with reason; the required Session module itself cannot be skipped. |
| Freshness | Bind evidence to current Session identity/role, latest parent-context readback, explicit/default audit values, allocation state, source, and relevant epoch. Material changes invalidate affected facts; read the parent-controlled record again before consuming dependent results. |

## Workflow map


## Ordered module checklist

1. **SR00 — Resolve entry.** Call [Module Entry Resolution](../instructions/workflow-checkpoints--module-entry-resolution.md) with this declaration, current task scope, released entry/route/mode evidence, Session identity/role facts, selected path, epochs, and continuation/effect state. The canonical record is produced here and is not a prerequisite to entry. Resume from the recorded substep. A missing prerequisite returns `needs_prerequisite` with its owner and suspended position; an unsafe or unrecoverable state returns `blocked`.
2. **SR01 — Recheck material changes.** If the current Contract, Context, or Decision materially changed, review current direct evidence before relying on it. Do not rerun planning, request advice, reopen Mode, or start downstream effects. When no material change exists, record `not_applicable` and why. Missing facts return `needs_prerequisite`; conflicting or unsafe facts return `blocked`.
3. **SR02 — Confirm the canonical parent-context record.** Apply [Session State Resolution](../instructions/workflow-checkpoints--session-state-resolution.md) and its directly linked Session, role, and Context Firewall owners. Verify released mode/count, current identity and role, required per-operation permissions, and record consistency. Read back the canonical record and applicable allocation state. A structural tool result or application request scope is not identity or authorization proof. Missing evidence returns `needs_prerequisite`; an unresolved conflict or unavailable required owner returns `blocked`.
4. **SR03 — Apply audit preferences.** Apply [Session Audit Resolution](../instructions/workflow-checkpoints--session-audit-resolution.md), [Session Audit Visibility](../instructions/fundamental-concepts--session-runtime--session-audit-visibility.md), [Reasoning Summary Visibility](../instructions/fundamental-concepts--session-runtime--reasoning-summary-visibility.md), and the [Delegation State Record](../instructions/fundamental-concepts--delegation--delegation-state-record.md). Keep required progress/report duties and confidentiality rules. Apply explicit preferences or defaults immediately; do not make a prompt, timer, migration, or audit preference a prerequisite. Record Worker-log visibility only from actual access evidence and block only a dependent judgment when required log evidence is unavailable or unverified.
5. **SR04 — Confirm capacity only when Multi-Agent applies.** Under released Multi-Agent mode, read the current parent-controlled allocation. Use [Delegation Count Gate](../instructions/fundamental-concepts--delegation--delegation-mode-count-gate.md), [Delegation State Record](../instructions/fundamental-concepts--delegation--delegation-state-record.md), and conditionally [Child Role Allocation](../instructions/fundamental-concepts--delegation--delegation-child-role-allocation.md) to confirm locked capacity, occupied roles, and unassigned slots. This is read-only confirmation: do not select/reserve a role, release a Slice, create a child, or recycle a slot. In Single-Agent mode, record capacity as `not_applicable` and why. Return `complete` with the current parent-record readback, effective audit preferences, and applicable capacity evidence; none authorizes a child task.
