# unit.b0e2251c1172aa52_zh_cn

[English](unit.b0e2251c1172aa52.md) | [简体中文](unit.b0e2251c1172aa52_zh_cn.md)

下列直接给出当前动作、守卫、证据和失败边界。应用独立政策前，先按明确的指令继续入口取得对应单元；同一构建中已持有的单元直接复用，并保留受影响动作的准确恢复位置。不读取作者文件或推测缺失政策。执行副作用前核实当前事实与授权；指令内容可用不表示检查通过。

## 硬约束

- 采取行动前记录用户、运行环境、仓库、权限、安全和 Session 硬约束。
- “不要创建子代理”“不要使用浏览器”等任务级禁止条件在整个任务中持续有效。
- 绝对禁止 Computer Use：不得通过图形界面控制计算机、浏览器或桌面应用——包括以操纵控件为目的的截图、鼠标／键盘模拟、点击、辅助功能 API、窗口自动化、远程桌面控制或 GUI 脚本——也不得把此类交互包装为 API、CLI、MCP Server、辅助程序或其他 Agent 调用来绕过。本节是黑名单而非允许渠道清单：当前 Session 实际暴露且已获授权的其他工具、命令或能力仍然允许。若必需步骤需要借助被禁止的操作，应停止并报告阻塞，而不是尝试、委派或跳过。
- 路线选择或任何委派/Session 拓扑工作前，模式检查点必须组合并验证委派 references；这些 references 在各自的原子边界内规定会话级模式选择及默认多代理路线和单个子代理预算、子代理数量、条件创建、分配、复用、替换、例外和限制。预留预算本身不会初始化或授权创建子代理。
- 不得虚构授权、能力、证据、产品支持，或为未维护场景推导可执行路线。
- Core 规则不依赖具体产品；受支持的运行环境分支和模型绑定见运行环境与模型厂商支持 (instruction continuation: [unit.081374cfbaa37b57](../instructions/unit.081374cfbaa37b57_zh_cn.md))。
- 按需读取 reference。不要仅因为可能以后有用，就预加载整个 Skill、`references/` 或原始项目状态。

# Coding Execution Control

## 通用规范

### Interaction Slice

对于非简单工作，每次只放行一个 **Interaction Slice**。每个 slice 必须写明：

- `Objective`：必须产出的结果；
- `Authorized scope/mutations`：允许的路径、行为和写入；
- `Return conditions`：结束 slice 的证据或里程碑；
- `Unreleased boundary`：仍被阻塞的下一个子系统、风险域、语义选择或变更。

Slice 是控制单元，不是逐命令脚本。只要 Contract 和边界未变，执行者可以继续处理低决策密度的机械步骤；到达 return conditions 或跨越未放行边界前必须暂停。简单的快路径任务可以将实现和聚焦检查保留在一个 slice 中。

### Slice 顺序

只有相互独立且不冲突的 slice 才可并行放行。存在依赖、共享写入目标或有序结果时必须顺序放行。上下文传输和仅限父级的反馈遵循各自 owner 协议，本文档不定义这些内容。

### Control Checkpoint

到达实质性边界时，消费执行阶段反馈 (instruction continuation: [unit.1199cd05bec7fedb](../instructions/unit.1199cd05bec7fedb_zh_cn.md))定义的 Progress Signal，附加当前 `Unreleased boundary`，再选择一个最终控制结果：`Continue`、`Amend` 或 `Stop`。Control 聚焦实质偏离、新证据或真实边界；不要把已放行 slice 变成逐命令审批，也不要重复无变化状态。`Continue` 只放行下一个有界 Slice；`Amend` 必须先修改 Contract 或边界再恢复执行。`Evidence-on-Demand` 是暂停放行并请求证据的中间动作，取得证据后重新经过本检查点；它不是第四种最终授权结果。单代理路线中这是内部推理暂停，不模拟发给自己的消息。

## Codex CLI / ChatGPT Desktop 特别优化指令

可用且已启用时，Codex `PreToolUse` 可在受支持的 `Bash`、编辑或 MCP 调用执行前拒绝操作；`PostToolUse` 只能在调用**结束后**观察。Codex 的 plan／只读及其他权限模式属于工具控制，不等于本 Skill 的 `Continue` 决策。Hook 覆盖并非完整，不能把它作为文件系统或语义授权边界的唯一证明。[OpenAI：Hooks](https://learn.chatgpt.com/docs/hooks)。

### 原生审批与聚焦审查

依赖非托管 Codex Hook 前，先检查并信任其确切定义；若当前 CLI Session 暴露了 `/hooks`，用它审查或信任已配置的 Hook。`PreToolUse` 命令 Hook 通过向 stdout 写入以下 JSON，拒绝受支持的本地调用：

```json
{
  "hookSpecificOutput": {
    "hookEventName": "PreToolUse",
    "permissionDecision": "deny",
    "permissionDecisionReason": "说明拒绝该操作的原因。"
  }
}
```

对该事件，`continue: false` 不受支持，Hook 报错后工具调用仍会继续；`PostToolUse` 在副作用发生后运行，不能追认授权。阶段边界时，Agent 必须通过获准的只读 diff 工具检查真实工作树 diff；若 Codex CLI Session 暴露 `/diff`，则调用该命令。`/diff` 包含已暂存、未暂存和未跟踪的改动。父级仍须按通用规则作出语义上的 `Continue`／`Amend`／`Stop` 决策。[OpenAI：PreToolUse 输出契约](https://learn.chatgpt.com/docs/hooks)、[OpenAI：Code review](https://learn.chatgpt.com/docs/code-review)、[OpenAI：CLI diff](https://learn.chatgpt.com/docs/developer-commands)。

## Claude Code CLI / Claude Desktop 特别优化指令

### 工具边界守卫与语义 Control 的区分

获准的 Claude Code `PreToolUse` Hook 在工具参数生成后、调用执行前运行。它从 stdin 接收含有 `tool_name`、`tool_input` 和 `tool_use_id` 的 JSON；Hook 组的 `matcher` 用于筛选 `tool_name`。要拒绝调用，向 stdout 写入以下 JSON：

```json
{
  "hookSpecificOutput": {
    "hookEventName": "PreToolUse",
    "permissionDecision": "deny",
    "permissionDecisionReason": "说明拒绝该操作的原因。"
  }
}
```

以退出码 0 且不输出内容结束，会继续正常权限流程，并不代表批准调用。`Stop` Hook 可以在当前 Agent 结束前请求最终证据检查。这些都只是**守卫**，不是 `Continue`、`Amend`、`Stop` 的替代决策权：父级仍须消费 Progress Signal，并按通用规则批准每个新 Slice。Hook 决策或 MCP 连接器不得暗中扩大 Contract 或子代理预算。仅在当前 Claude Code 运行环境实际暴露且获准时，才能使用原生 Hooks。

官方依据：[Claude Code Hooks 与决策](https://code.claude.com/docs/en/hooks)。

Claude Code 的 `PostToolUse` 在操作后提供观察结果，不能倒过来授权已经执行的操作。[Anthropic：Hooks](https://code.claude.com/docs/en/hooks)。
