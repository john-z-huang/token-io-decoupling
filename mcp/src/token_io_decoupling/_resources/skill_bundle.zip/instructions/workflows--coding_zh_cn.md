# workflows / coding_zh_cn

[English](workflows--coding.md) | [简体中文](workflows--coding_zh_cn.md)

下列直接给出当前动作、守卫、证据和失败边界。应用独立政策前，先按明确的指令继续入口取得对应单元；同一构建中已持有的单元直接复用，并保留受影响动作的准确恢复位置。不读取作者文件或推测缺失政策。执行副作用前核实当前事实与授权；指令内容可用不表示检查通过。

## 硬约束

- 采取行动前记录用户、运行环境、仓库、权限、安全和 Session 硬约束。
- “不要创建子代理”“不要使用浏览器”等任务级禁止条件在整个任务中持续有效。
- 绝对禁止 Computer Use：不得通过图形界面控制计算机、浏览器或桌面应用——包括以操纵控件为目的的截图、鼠标／键盘模拟、点击、辅助功能 API、窗口自动化、远程桌面控制或 GUI 脚本——也不得把此类交互包装为 API、CLI、MCP Server、辅助程序或其他 Agent 调用来绕过。本节是黑名单而非允许渠道清单：当前 Session 实际暴露且已获授权的其他工具、命令或能力仍然允许。若必需步骤需要借助被禁止的操作，应停止并报告阻塞，而不是尝试、委派或跳过。
- 路线选择或任何委派/Session 拓扑工作前，模式检查点必须组合并验证委派 references；这些 references 在各自的原子边界内规定会话级模式选择及默认多代理路线和单个子代理预算、子代理数量、条件创建、分配、复用、替换、例外和限制。预留预算本身不会初始化或授权创建子代理。
- 不得虚构授权、能力、证据、产品支持，或为未维护场景推导可执行路线。
- Core 规则不依赖具体产品；受支持的运行环境分支和模型绑定见[运行环境与模型厂商支持](../instructions/fundamental-concepts--session-runtime--runtime-provider-support_zh_cn.md)。
- 按需读取 reference。不要仅因为可能以后有用，就预加载整个 Skill、`references/` 或原始项目状态。

## 入口

1. 在路线选择前完成 Contract 检查点。
2. 识别真实运行环境，完成运行环境检查点，并建立或加载[运行环境能力清单](../instructions/workflow-concepts--entry-and-context--environment-capability-inventory_zh_cn.md)进行能力检查。
3. 通过消费已建立的运行环境能力清单的模式检查点，组合根指令模式门禁所需的委派 references。
4. 使用当前证据调用[路线入口](../instructions/workflow-checkpoints--route-entry_zh_cn.md)，确认 Contract、运行环境、能力清单和 Mode 均已通过。只选择其授权的完整路线，并将已释放的 mode/count 证据交给首个模块检查点 SM01/MM01。每条路线依次组合[入口就绪](../instructions/workflows--modules--entry-readiness_zh_cn.md)、[Session 就绪](../instructions/workflows--modules--session-readiness_zh_cn.md)、[工作定义](../instructions/workflows--modules--work-definition_zh_cn.md)、对应模式的执行模块、[验证与修复](../instructions/workflows--modules--verification-repair_zh_cn.md)、[文档](../instructions/workflows--modules--documentation_zh_cn.md)和[交付与验收](../instructions/workflows--modules--delivery-acceptance_zh_cn.md)。只在到达时加载已选路线及对应模块。

所有现有及未来路线均通过工作定义和执行检查点消费[任务计划 Memory 生命周期](../instructions/fundamental-concepts--execution-planning--task-plan-memory-lifecycle_zh_cn.md)。向执行阶段传递共享计划身份、当前计划证据与持久化确认，或有记录的限制例外；完成 owner 要求的任何内容核验。在 owner 规定的阶段、交接、暂停和完成边界记录更新；影响授权、范围、验收、方向或依赖动作的变化仍须在该动作前记录。只有匹配计划生命周期已解决后才完成。无需额外规划请求。

## 路线

- [单代理 Coding](../instructions/workflows--coding-single-agent_zh_cn.md)：用户明确选择 `mode: Single-Agent Coding` 时使用；与指令相关的任务事项留在当前 Session 中完成。
- [多代理 Coding](../instructions/workflows--coding-multi-agent_zh_cn.md)：已释放的 Mode 选择 Multi-Agent Coding 且已锁定正整数 `child_count` 时使用。Mode 检查点负责四项菜单、默认值和无效输入处理；锁定预算不初始化子代理。

不要同时加载两条路线。如果后续实质事实使路线失效，停止当前切片，按需修改 Contract，并返回路线入口。

## 完成

只有选定路线以当前证据通过验收后，才能返回 `COMPLETE`。报告不可用检查、假设、剩余风险、已授权影响和已记录的委派状态。没有明确授权时不得产生外部影响。
