# Verification Independence Checkpoint

[English](workflow-concepts--verification-and-repair--verification-independence.md) | [简体中文](workflow-concepts--verification-and-repair--verification-independence_zh_cn.md)

Apply the current instruction and its included policy sections below. The current actions, guards, evidence and failure boundary are given directly. Before applying a named independent policy, obtain its exact instruction continuation; reuse any already held unit from this build and retain the affected action's return position. Do not retrieve author files or infer omitted policy. Check current facts and authorization before effects; an instruction is not a pass.

## Hard constraints

- Record hard user, runtime environment, repository, permission, safety, and Session constraints before acting.
- A task-level prohibition, such as “do not create subagents” or “do not use a browser,” remains active for the whole task.
- Computer Use is categorically forbidden: never control a computer, browser, or desktop app through its graphical interface — no screenshots to locate controls, mouse or keyboard simulation, clicking, accessibility APIs, window automation, remote-desktop control, or GUI scripting — and do not route such interaction through an API, CLI, MCP server, helper, or another Agent. Treat this as a blacklist rather than a list of allowed channels: every other tool, command, or capability actually exposed to and authorized for the current Session remains permitted. If a required step needs a forbidden operation, stop and report the blocker instead of attempting, delegating, or skipping it.
- Before route selection or any delegation/Session-topology work, the Mode checkpoint must compose and validate the delegation references; those references own conversation-level mode selection with a default Multi-Agent route and one-child budget, child counts, conditional creation, allocation, reuse, replacement, exceptions, and limits at their respective atomic boundaries. A reserved budget never initializes or authorizes a child by itself.
- Never invent authorization, capability, evidence, product support, or an executable route for an unmaintained scenario.
- Keep Core rules independent of product details; read [Runtime and Model Provider Support](../instructions/fundamental-concepts--session-runtime--runtime-provider-support.md) for supported runtime branches and model bindings.
- Read references on demand. Do not preload the entire Skill, `references/`, or raw project state merely because it may become useful.

# Verification Independence Checkpoint


This checkpoint owns the distinction between an independent Change Verification Session and same-Session logical verification. It does not define check contents, evidence collection, result classification, or repair.

## Actions

1. For material changes, use an independent Change Verification Session when the Contract requires it.
2. Label same-Session checks as logical verification; do not call them independent verification.

## Pass condition

Independence status is explicitly classified: the required independent Session has verified the change, or same-Session checks are labeled logical and independence unavailable. The latter is a recorded limitation, **not** satisfaction of a Contract that requires independent verification; dependent effects remain blocked.

## Boundary

This checkpoint does not choose holistic or targeted checks, capture fingerprints, classify results, invalidate epochs, repair failures, or perform Git effects.
