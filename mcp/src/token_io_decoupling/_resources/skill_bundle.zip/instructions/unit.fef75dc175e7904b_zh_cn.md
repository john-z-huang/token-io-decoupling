# unit.fef75dc175e7904b_zh_cn

[English](unit.fef75dc175e7904b.md) | [简体中文](unit.fef75dc175e7904b_zh_cn.md)

下列直接给出当前动作、守卫、证据和失败边界。应用独立政策前，先按明确的指令继续入口取得对应单元；同一构建中已持有的单元直接复用，并保留受影响动作的准确恢复位置。不读取作者文件或推测缺失政策。执行副作用前核实当前事实与授权；指令内容可用不表示检查通过。

## 硬约束

- 采取行动前记录用户、运行环境、仓库、权限、安全和 Session 硬约束。
- “不要创建子代理”“不要使用浏览器”等任务级禁止条件在整个任务中持续有效。
- 绝对禁止 Computer Use：不得通过图形界面控制计算机、浏览器或桌面应用——包括以操纵控件为目的的截图、鼠标／键盘模拟、点击、辅助功能 API、窗口自动化、远程桌面控制或 GUI 脚本——也不得把此类交互包装为 API、CLI、MCP Server、辅助程序或其他 Agent 调用来绕过。本节是黑名单而非允许渠道清单：当前 Session 实际暴露且已获授权的其他工具、命令或能力仍然允许。若必需步骤需要借助被禁止的操作，应停止并报告阻塞，而不是尝试、委派或跳过。
- 路线选择或任何委派/Session 拓扑工作前，模式检查点必须组合并验证委派 references；这些 references 在各自的原子边界内规定会话级模式选择及默认多代理路线和单个子代理预算、子代理数量、条件创建、分配、复用、替换、例外和限制。预留预算本身不会初始化或授权创建子代理。
- 不得虚构授权、能力、证据、产品支持，或为未维护场景推导可执行路线。
- Core 规则不依赖具体产品；受支持的运行环境分支和模型绑定见运行环境与模型厂商支持 (instruction continuation: [unit.081374cfbaa37b57](../instructions/unit.081374cfbaa37b57_zh_cn.md))。
- 按需读取 reference。不要仅因为可能以后有用，就预加载整个 Skill、`references/` 或原始项目状态。

# Git 检查点


## 动作

1. 确认准确的仓库、worktree、分支或 ref、远程、操作和计划产生的外部影响。
2. 修改 Git 状态前检查 status 和相关历史，不要纳入用户无关的现有修改。
3. 将 commit、branch、index 和 history 变化视为 Git metadata 操作；它们不会自动使 implementation/content 或 documentation epoch 失效。
4. 确认 staged 或 committed content 与最新验证指纹一致，且不包含未验证内容。如果存在差异，继续前必须返回对应的 implementation/content 或 documentation Verification epoch。
5. 将 commit、push、Issue、PR、远程配置修改和其他外部影响分开处理，除非每项影响都得到明确授权。
6. 记录 Git 操作所针对的最新适用 implementation/content 和 documentation epoch。
7. 目标不明确、出现意外冲突、缺少授权或前置条件失败时停止；不要扩大操作范围来恢复。

## 通过条件

获授权的 Git 操作已针对准确目标完成，记录了最新适用的 content 和 documentation epoch，并与其验证指纹一致；否则报告不可用的授权、冲突、前置条件或所需的 Verification 返回。

## 边界

本检查点不授予产品决策权限，不允许未请求的清理，也不会把可能产生的 Git 影响变成已授权影响。
