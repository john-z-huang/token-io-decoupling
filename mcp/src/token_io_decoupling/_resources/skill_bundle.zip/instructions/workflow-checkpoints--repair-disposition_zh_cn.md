# 修复处置

[English](workflow-checkpoints--repair-disposition.md) | [简体中文](workflow-checkpoints--repair-disposition_zh_cn.md)

下列直接给出当前动作、守卫、证据和失败边界。应用独立政策前，先按明确的指令继续入口取得对应单元；同一构建中已持有的单元直接复用，并保留受影响动作的准确恢复位置。不读取作者文件或推测缺失政策。执行副作用前核实当前事实与授权；指令内容可用不表示检查通过。

## 硬约束

- 采取行动前记录用户、运行环境、仓库、权限、安全和 Session 硬约束。
- “不要创建子代理”“不要使用浏览器”等任务级禁止条件在整个任务中持续有效。
- 绝对禁止 Computer Use：不得通过图形界面控制计算机、浏览器或桌面应用——包括以操纵控件为目的的截图、鼠标／键盘模拟、点击、辅助功能 API、窗口自动化、远程桌面控制或 GUI 脚本——也不得把此类交互包装为 API、CLI、MCP Server、辅助程序或其他 Agent 调用来绕过。本节是黑名单而非允许渠道清单：当前 Session 实际暴露且已获授权的其他工具、命令或能力仍然允许。若必需步骤需要借助被禁止的操作，应停止并报告阻塞，而不是尝试、委派或跳过。
- 路线选择或任何委派/Session 拓扑工作前，模式检查点必须组合并验证委派 references；这些 references 在各自的原子边界内规定会话级模式选择及默认多代理路线和单个子代理预算、子代理数量、条件创建、分配、复用、替换、例外和限制。预留预算本身不会初始化或授权创建子代理。
- 不得虚构授权、能力、证据、产品支持，或为未维护场景推导可执行路线。
- Core 规则不依赖具体产品；受支持的运行环境分支和模型绑定见[运行环境与模型厂商支持](../instructions/fundamental-concepts--session-runtime--runtime-provider-support_zh_cn.md)。
- 按需读取 reference。不要仅因为可能以后有用，就预加载整个 Skill、`references/` 或原始项目状态。

# 修复处置


本检查点负责失败或实质性决策变化后的路线级恢复和重新验证路由。


## 触发与输入

当前 Verification 失败或决策发生重大变化后，使用本检查点路由恢复流程。应用[Repair](../instructions/workflow-concepts--verification-and-repair--repair_zh_cn.md)、[Repair Scope Gate](../instructions/workflow-concepts--verification-and-repair--repair-scope-gate_zh_cn.md)、[Repair Execution](../instructions/workflow-concepts--verification-and-repair--repair-execution_zh_cn.md)和[Repair Verification Handoff](../instructions/workflow-concepts--verification-and-repair--repair-verification-handoff_zh_cn.md)。

## 决策与结果

1. 必须提供具体失败证据、受影响路径和最小修复候选。没有具体失败的语义变更不能算作 Repair；应作为重大决策变化路由。
2. 用当前 Contract 和 Decision 应用 Repair 范围门禁。只释放获授权的窄范围修复及其定向检查。
3. 记录修复交接、新指纹和受影响 epoch；将当前证据交给 Verification，并在依赖工作前重跑所有变更 epoch 所需检查。
4. 重大决策变化应向调用方返回变更后的 Contract/Decision 事实和证据，以便重新审查 Contract 与 Decision 并调度路线。无具体失败时，返回 Repair `Not applicable` 及证据依据。若已验收的 epoch 发生变化，依赖工作继续前必须取得当前 Verification 证据。

## 失败边界

诊断、授权、有界范围、handoff 证据或变更 epoch 后重新验证缺失时，阻塞依赖路线。修复意图不构成授权，也不得复用过期通过证据。
