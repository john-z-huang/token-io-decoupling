# 实现检查点

[English](workflow-concepts--decision-and-execution--implementation.md) | [简体中文](workflow-concepts--decision-and-execution--implementation_zh_cn.md)

下列直接给出当前动作、守卫、证据和失败边界。应用独立政策前，先按明确的指令继续入口取得对应单元；同一构建中已持有的单元直接复用，并保留受影响动作的准确恢复位置。不读取作者文件或推测缺失政策。执行副作用前核实当前事实与授权；指令内容可用不表示检查通过。

## 硬约束

- 采取行动前记录用户、运行环境、仓库、权限、安全和 Session 硬约束。
- “不要创建子代理”“不要使用浏览器”等任务级禁止条件在整个任务中持续有效。
- 绝对禁止 Computer Use：不得通过图形界面控制计算机、浏览器或桌面应用——包括以操纵控件为目的的截图、鼠标／键盘模拟、点击、辅助功能 API、窗口自动化、远程桌面控制或 GUI 脚本——也不得把此类交互包装为 API、CLI、MCP Server、辅助程序或其他 Agent 调用来绕过。本节是黑名单而非允许渠道清单：当前 Session 实际暴露且已获授权的其他工具、命令或能力仍然允许。若必需步骤需要借助被禁止的操作，应停止并报告阻塞，而不是尝试、委派或跳过。
- 路线选择或任何委派/Session 拓扑工作前，模式检查点必须组合并验证委派 references；这些 references 在各自的原子边界内规定会话级模式选择及默认多代理路线和单个子代理预算、子代理数量、条件创建、分配、复用、替换、例外和限制。预留预算本身不会初始化或授权创建子代理。
- 不得虚构授权、能力、证据、产品支持，或为未维护场景推导可执行路线。
- Core 规则不依赖具体产品；受支持的运行环境分支和模型绑定见[运行环境与模型厂商支持](../instructions/fundamental-concepts--session-runtime--runtime-provider-support_zh_cn.md)。
- 按需读取 reference。不要仅因为可能以后有用，就预加载整个 Skill、`references/` 或原始项目状态。

# 实现检查点


## 动作

1. 重新读取切片目标、授权路径、允许的修改和返回条件。
2. 只检查该切片所需的文件，然后以最小修改满足已批准的方向。
3. 授权实施路径使用受控候选输出时，在各自 owner 规定的门禁处遵循[输出物料化](../instructions/fundamental-concepts--execution-planning--output-materialization_zh_cn.md)和[候选合规预检](../instructions/fundamental-concepts--execution-planning--candidate-compliance_zh_cn.md)。审阅准确的有界候选及其当前基线；应用前解决每项已选预检返回的失败、未知、遗漏或过期结果。未选择可选候选路径时，记录有原因的 `Not applicable`，且仅在独立授权的实施路径下继续。准备、预检和应用收据都是临时证据，不能替代本检查点的聚焦检查或后续最终 Verification。
4. 不要把无关清理、重构、生成产物或外部影响带入切片。
5. 运行可以指导修复的聚焦临时检查，但不要把它们当作最终验收。
6. 返回已修改路径、相关输出、剩余问题和尚未发布的边界。

实施前应用[任务计划 Memory 生命周期](../instructions/fundamental-concepts--execution-planning--task-plan-memory-lifecycle_zh_cn.md)：要求当前计划证据和持久化确认，以及该 owner 要求的内容核验，或其有记录的限制例外。按 owner 规定的边界记录更新；影响授权、范围、验收、方向或依赖实施的事实，须在该工作前记录并分析。仅父级可释放受影响工作。

## 通过条件

获批准的切片已在范围内实现，且聚焦检查要么通过，要么提供了可交给修复检查点的具体问题。

## 边界

本检查点不扩大范围，不改变实质性决策，不执行最终验证，不写入验证后的文档，也不产生未授权的 Git 影响。
