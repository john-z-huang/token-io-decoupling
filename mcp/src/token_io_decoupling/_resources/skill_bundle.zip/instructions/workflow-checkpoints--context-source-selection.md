# Context source selection

[English](workflow-checkpoints--context-source-selection.md) | [简体中文](workflow-checkpoints--context-source-selection_zh_cn.md)

Apply the current instruction and its included policy sections below. The current actions, guards, evidence and failure boundary are given directly. Before applying a named independent policy, obtain its exact instruction continuation; reuse any already held unit from this build and retain the affected action's return position. Do not retrieve author files or infer omitted policy. Check current facts and authorization before effects; an instruction is not a pass.

## Hard constraints

- Record hard user, runtime environment, repository, permission, safety, and Session constraints before acting.
- A task-level prohibition, such as “do not create subagents” or “do not use a browser,” remains active for the whole task.
- Computer Use is categorically forbidden: never control a computer, browser, or desktop app through its graphical interface — no screenshots to locate controls, mouse or keyboard simulation, clicking, accessibility APIs, window automation, remote-desktop control, or GUI scripting — and do not route such interaction through an API, CLI, MCP server, helper, or another Agent. Treat this as a blacklist rather than a list of allowed channels: every other tool, command, or capability actually exposed to and authorized for the current Session remains permitted. If a required step needs a forbidden operation, stop and report the blocker instead of attempting, delegating, or skipping it.
- Before route selection or any delegation/Session-topology work, the Mode checkpoint must compose and validate the delegation references; those references own conversation-level mode selection with a default Multi-Agent route and one-child budget, child counts, conditional creation, allocation, reuse, replacement, exceptions, and limits at their respective atomic boundaries. A reserved budget never initializes or authorizes a child by itself.
- Never invent authorization, capability, evidence, product support, or an executable route for an unmaintained scenario.
- Keep Core rules independent of product details; read [Runtime and Model Provider Support](../instructions/fundamental-concepts--session-runtime--runtime-provider-support.md) for supported runtime branches and model bindings.
- Read references on demand. Do not preload the entire Skill, `references/`, or raw project state merely because it may become useful.

# Context source selection


This checkpoint owns the route-level procedure for selecting and qualifying active-plan, bounded-rule, reusable project-memory, and persistent-exchange context.

## Trigger and inputs

After Session resolution, use current verified facts and task scope. Apply [Context](../instructions/workflow-concepts--entry-and-context--context.md), [Session Context Firewall](../instructions/fundamental-concepts--session-runtime--session-context-firewall.md), [project-memory and code-structure capability](../instructions/fundamental-concepts--session-runtime--lsp-mcp-tools.md), [Workflow Rule Context](../instructions/fundamental-concepts--workflow-navigation--rule-context.md), and the context-exchange owners when their triggers apply.

## Decision and result

1. Define the smallest current Context question, its task scope, and which source class can answer it. Apply the Context owner; do not read unrelated project state.
2. Always list active plan Memories under `plans/` and read every match for this task. Compare each match with current instructions, task match, source pointers, and freshness; current instructions take precedence, and a plan never grants authorization. If there is no matching active plan, record `Not applicable` and why. If listing or reading a relevant active plan fails, block work depending on it; do not substitute filesystem files for that plan.
3. For reusable project knowledge from prior work, list project Memories and read relevant entries; verify source pointers and freshness against authoritative project files. If there is no relevant entry or cross-session knowledge is unnecessary, record `Not applicable` and why. If Memory is unavailable, return to approved authoritative project files; block only if an essential fact cannot otherwise be established. This fallback applies to ordinary reusable project knowledge, not the required active-plan listing/read in step 2.
4. If the question needs workflow instructions, consume the explicit current compiled node/unit from one build and language under Workflow Rule Context. Verify identity, completeness and unresolved facts; obtain each named instruction continuation before its dependent action, retaining the exact return position. When optional bounded navigation is unnecessary, record `Not applicable` and use the corresponding already delivered instruction. When optional navigation is unavailable, an actually available, authorized same-build generated document-only surface may supply the unit. Missing, corrupt, incomplete or incompatible required resources block dependent decisions; never search author owners or infer omitted policy.
5. Apply Session Context Firewall to source scope and ingress. If Worker memo or memo dispatch is needed, use [Content Memo Dispatch](../instructions/fundamental-concepts--context-exchange--content-memo-dispatch.md) and its [Content Memo Lifecycle](../instructions/fundamental-concepts--context-exchange--content-memo-lifecycle.md), confirm required Memory capability and evidence, and retain it as evidence for any later authorized Worker memo dispatch; when the trigger is absent, record `Not applicable` and why. If a Worker requires cross-Worker exchange/bootstrap, use [Coding Context Exchange](../instructions/fundamental-concepts--context-exchange--context-exchange.md) and [Workspace Boundary](../instructions/fundamental-concepts--context-exchange--context-exchange-workspace-boundary.md). Use [Context Exchange Handoff](../instructions/fundamental-concepts--context-exchange--context-exchange-handoff.md) only for a concrete handoff or recovery. Evaluate each independent trigger under its named owner; confirm required persistent-memory capability and evidence. Do not create exchange records merely because Context is being gathered. If a required exchange capability is unavailable, block dependent work; never use filesystem fallback for an owner-required persistent record.
6. Return the minimal current facts with source pointers, provenance, freshness/epoch, and any limitation. Stale, incomplete, or conflicting essential context blocks dependent decisions. Memo eligibility, consent, and persistence remain with their owners.

## Failure boundary

Stale, inaccessible, or conflicting essential context blocks dependent decisions. Do not broaden source scope, infer authorization from memory, or bypass required Memory capability.
