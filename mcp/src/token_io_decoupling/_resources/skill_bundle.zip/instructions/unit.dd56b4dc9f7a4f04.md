# unit.dd56b4dc9f7a4f04

[English](unit.dd56b4dc9f7a4f04.md) | [简体中文](unit.dd56b4dc9f7a4f04_zh_cn.md)

Apply the current instruction and its included policy sections below. The current actions, guards, evidence and failure boundary are given directly. Before applying a named independent policy, obtain its exact instruction continuation; reuse any already held unit from this build and retain the affected action's return position. Do not retrieve author files or infer omitted policy. Check current facts and authorization before effects; an instruction is not a pass.

## Hard constraints

- Record hard user, runtime environment, repository, permission, safety, and Session constraints before acting.
- A task-level prohibition, such as “do not create subagents” or “do not use a browser,” remains active for the whole task.
- Computer Use is categorically forbidden: never control a computer, browser, or desktop app through its graphical interface — no screenshots to locate controls, mouse or keyboard simulation, clicking, accessibility APIs, window automation, remote-desktop control, or GUI scripting — and do not route such interaction through an API, CLI, MCP server, helper, or another Agent. Treat this as a blacklist rather than a list of allowed channels: every other tool, command, or capability actually exposed to and authorized for the current Session remains permitted. If a required step needs a forbidden operation, stop and report the blocker instead of attempting, delegating, or skipping it.
- Before route selection or any delegation/Session-topology work, the Mode checkpoint must compose and validate the delegation references; those references own conversation-level mode selection with a default Multi-Agent route and one-child budget, child counts, conditional creation, allocation, reuse, replacement, exceptions, and limits at their respective atomic boundaries. A reserved budget never initializes or authorizes a child by itself.
- Never invent authorization, capability, evidence, product support, or an executable route for an unmaintained scenario.
- Keep Core rules independent of product details; read Runtime and Model Provider Support (instruction continuation: [unit.081374cfbaa37b57](../instructions/unit.081374cfbaa37b57.md)) for supported runtime branches and model bindings.
- Read references on demand. Do not preload the entire Skill, `references/`, or raw project state merely because it may become useful.

# Documentation impact


This checkpoint owns route-level impact classification and return routing after documentation/content changes.


## Trigger and inputs

After Documentation or an approved content change, determine whether implementation/content, documentation, or Contract evidence changed. Apply Documentation (instruction continuation: [unit.f681f793a092a894](../instructions/unit.f681f793a092a894.md)) and Verification Epoch (instruction continuation: [unit.a831ed90e8918688](../instructions/unit.a831ed90e8918688.md)).

## Decision and result

1. Capture before/after fingerprints and classify each affected dimension: implementation/content, documentation, Git metadata, or multiple. Attach evidence for each classification.
2. Name required checks, evidence that remains reusable, and why each unaffected dimension is unchanged. A no-change result is `Not applicable` with fingerprint evidence.
3. Re-verify changed dimensions. If content changes behavior, Contract, or acceptance, return the evidence to implementation/content Verification; if only documentation changed, return documentation checks and unaffected-dimension rationale.
4. Return the classification, fingerprints, checks, reuse rationale, and Verification disposition to route scheduling.

## Failure boundary

Unknown impact, missing required checks, or stale evidence blocks Acceptance. Preserve the affected/unaffected dimension reasoning and permitted output scope; do not reuse evidence across a changed epoch.
