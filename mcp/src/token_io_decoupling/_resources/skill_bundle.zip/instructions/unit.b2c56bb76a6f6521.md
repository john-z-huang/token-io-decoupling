# unit.b2c56bb76a6f6521

[English](unit.b2c56bb76a6f6521.md) | [简体中文](unit.b2c56bb76a6f6521_zh_cn.md)

Apply the current instruction and its included policy sections below. The current actions, guards, evidence and failure boundary are given directly. Before applying a named independent policy, obtain its exact instruction continuation; reuse any already held unit from this build and retain the affected action's return position. Do not retrieve author files or infer omitted policy. Check current facts and authorization before effects; an instruction is not a pass.

## Hard constraints

- Record hard user, runtime environment, repository, permission, safety, and Session constraints before acting.
- A task-level prohibition, such as “do not create subagents” or “do not use a browser,” remains active for the whole task.
- Computer Use is categorically forbidden: never control a computer, browser, or desktop app through its graphical interface — no screenshots to locate controls, mouse or keyboard simulation, clicking, accessibility APIs, window automation, remote-desktop control, or GUI scripting — and do not route such interaction through an API, CLI, MCP server, helper, or another Agent. Treat this as a blacklist rather than a list of allowed channels: every other tool, command, or capability actually exposed to and authorized for the current Session remains permitted. If a required step needs a forbidden operation, stop and report the blocker instead of attempting, delegating, or skipping it.
- Before route selection or any delegation/Session-topology work, the Mode checkpoint must compose and validate the delegation references; those references own conversation-level mode selection with a default Multi-Agent route and one-child budget, child counts, conditional creation, allocation, reuse, replacement, exceptions, and limits at their respective atomic boundaries. A reserved budget never initializes or authorizes a child by itself.
- Never invent authorization, capability, evidence, product support, or an executable route for an unmaintained scenario.
- Keep Core rules independent of product details; read Runtime and Model Provider Support (instruction continuation: [unit.081374cfbaa37b57](../instructions/unit.081374cfbaa37b57.md)) for supported runtime branches and model bindings.
- Read references on demand. Do not preload the entire Skill, `references/`, or raw project state merely because it may become useful.

# Workflow Rule Context

## General rules

### Consume the current executable instruction

Author owners are the development-time policy source. During execution consume the current step's complete compiled instruction, not author filenames or excerpts that require reconstructing policy. An explicit instruction continuation identifies the next independent unit to obtain before its dependent action; preserve the suspended action and reuse already held units only when their build and language still match. A resource identity, hash or completeness result never proves task facts or checkpoint completion.

Keep consumption bounded to the current judgment. Do not scan the repository or follow original owner links. Resolve only the explicit continuation needed by the current action. Missing, corrupt, incompatible or mixed-build instruction resources block dependent work; do not fall back to author Markdown or infer omitted policy. A same-build generated document-only Skill may supply the corresponding compiled unit when an authorized document path is selected. Record `Not applicable` with a reason when optional navigation is unnecessary.

## Codex CLI / ChatGPT Desktop optimizations

Use `rules_get_context` with `context_version: 2`, the registered `node_id`, one language and any explicit compiled `fragment_ids` requested by the current continuation. Review returned instruction text, build identity, unresolved facts and failure status; a budget failure never permits partial execution. Tool discovery does not establish identity or authority. The server supports local Codex CLI only under its client boundary.

## Claude Code CLI / Claude Desktop optimizations

This project's MCP server has no supported direct Claude counterpart. Mark that MCP optimization `Not applicable` and use the same-build generated document-only Skill's explicit instruction units through actually exposed, authorized document capabilities. This does not add another MCP client or permit author-source fallback. Follow the general evidence and failure boundaries.
