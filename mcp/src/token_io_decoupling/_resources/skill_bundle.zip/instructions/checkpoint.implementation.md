# checkpoint.implementation

[English](checkpoint.implementation.md) | [简体中文](checkpoint.implementation_zh_cn.md)

Apply the current instruction and its included policy sections below. The current actions, guards, evidence and failure boundary are given directly. Before applying a named independent policy, obtain its exact instruction continuation; reuse any already held unit from this build and retain the affected action's return position. Do not retrieve author files or infer omitted policy. Check current facts and authorization before effects; an instruction is not a pass.

## Hard constraints

- Record hard user, runtime environment, repository, permission, safety, and Session constraints before acting.
- A task-level prohibition, such as “do not create subagents” or “do not use a browser,” remains active for the whole task.
- Computer Use is categorically forbidden: never control a computer, browser, or desktop app through its graphical interface — no screenshots to locate controls, mouse or keyboard simulation, clicking, accessibility APIs, window automation, remote-desktop control, or GUI scripting — and do not route such interaction through an API, CLI, MCP server, helper, or another Agent. Treat this as a blacklist rather than a list of allowed channels: every other tool, command, or capability actually exposed to and authorized for the current Session remains permitted. If a required step needs a forbidden operation, stop and report the blocker instead of attempting, delegating, or skipping it.
- Before route selection or any delegation/Session-topology work, the Mode checkpoint must compose and validate the delegation references; those references own conversation-level mode selection with a default Multi-Agent route and one-child budget, child counts, conditional creation, allocation, reuse, replacement, exceptions, and limits at their respective atomic boundaries. A reserved budget never initializes or authorizes a child by itself.
- Never invent authorization, capability, evidence, product support, or an executable route for an unmaintained scenario.
- Keep Core rules independent of product details; read Runtime and Model Provider Support (instruction continuation: [unit.081374cfbaa37b57](../instructions/unit.081374cfbaa37b57.md)) for supported runtime branches and model bindings.
- Read references on demand. Do not preload the entire Skill, `references/`, or raw project state merely because it may become useful.

# Implementation Checkpoint


## Actions

1. Re-read the slice objective, authorized paths, allowed mutations, and return conditions.
2. Inspect only the files needed for this slice, then make the smallest change that satisfies the approved direction.
3. When the authorized implementation path uses controlled candidate output, follow Output Materialization (instruction continuation: [unit.f6dfdbe9ab2522eb](../instructions/unit.f6dfdbe9ab2522eb.md)) and Candidate Compliance Preflight (instruction continuation: [unit.fe5e2c4674619c83](../instructions/unit.fe5e2c4674619c83.md)) at their owned gates. Review the exact bounded candidate and its current baseline; resolve every selected failed, unknown, omitted, or stale preflight result before applying it. If the optional candidate path is not selected, record `Not applicable` with the reason and continue only under the independently authorized implementation path. Preparation, preflight, and apply receipts are provisional evidence, not a substitute for this checkpoint's focused checks or later final Verification.
4. Keep unrelated cleanup, refactoring, generated output, and external effects out of the slice.
5. Run focused provisional checks that can guide repair without treating them as final acceptance.
6. Return changed paths, relevant output, remaining issue, and the boundary that was not released.

Apply Task Plan Memory Lifecycle (instruction continuation: [unit.c3c732f022fc8a5e](../instructions/unit.c3c732f022fc8a5e.md)) before implementation: require current plan evidence and confirmed persistence, any content verification required by that owner, or its documented restriction exception. Record updates at owner-defined boundaries; facts affecting authorization, scope, acceptance, direction, or dependent implementation must be recorded and analyzed before that work. Only the parent releases affected work.

## Pass condition

The approved slice is implemented within scope, and its focused checks either pass or provide a concrete issue for the Repair checkpoint.

## Boundary

This checkpoint does not expand scope, change a material decision, perform final verification, write post-verification documentation, or perform unapproved Git effects.
