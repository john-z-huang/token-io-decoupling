# unit.1199cd05bec7fedb_zh_cn

[English](unit.1199cd05bec7fedb.md) | [简体中文](unit.1199cd05bec7fedb_zh_cn.md)

下列直接给出当前动作、守卫、证据和失败边界。应用独立政策前，先按明确的指令继续入口取得对应单元；同一构建中已持有的单元直接复用，并保留受影响动作的准确恢复位置。不读取作者文件或推测缺失政策。执行副作用前核实当前事实与授权；指令内容可用不表示检查通过。

## 硬约束

- 采取行动前记录用户、运行环境、仓库、权限、安全和 Session 硬约束。
- “不要创建子代理”“不要使用浏览器”等任务级禁止条件在整个任务中持续有效。
- 绝对禁止 Computer Use：不得通过图形界面控制计算机、浏览器或桌面应用——包括以操纵控件为目的的截图、鼠标／键盘模拟、点击、辅助功能 API、窗口自动化、远程桌面控制或 GUI 脚本——也不得把此类交互包装为 API、CLI、MCP Server、辅助程序或其他 Agent 调用来绕过。本节是黑名单而非允许渠道清单：当前 Session 实际暴露且已获授权的其他工具、命令或能力仍然允许。若必需步骤需要借助被禁止的操作，应停止并报告阻塞，而不是尝试、委派或跳过。
- 路线选择或任何委派/Session 拓扑工作前，模式检查点必须组合并验证委派 references；这些 references 在各自的原子边界内规定会话级模式选择及默认多代理路线和单个子代理预算、子代理数量、条件创建、分配、复用、替换、例外和限制。预留预算本身不会初始化或授权创建子代理。
- 不得虚构授权、能力、证据、产品支持，或为未维护场景推导可执行路线。
- Core 规则不依赖具体产品；受支持的运行环境分支和模型绑定见运行环境与模型厂商支持 (instruction continuation: [unit.081374cfbaa37b57](../instructions/unit.081374cfbaa37b57_zh_cn.md))。
- 按需读取 reference。不要仅因为可能以后有用，就预加载整个 Skill、`references/` 或原始项目状态。

# Coding Execution Stage Feedback

## 通用规范

### 有界阶段

对于高不确定性工作，预先声明一组短小、能够产出证据的阶段。每个阶段以观察结果或决策边界结束，而不是命令列表。

### Progress Signals 与阶段反馈

在声明的阶段边界，只返回下一步决策所需的压缩进度信号：实质状态、发现、变更范围、验证、问题和所需动作。有新证据或状态变化时才增量更新父级记录；不要重复汇报无变化进度或重写稳定状态。普通读取、局部编辑、formatter/lint 修复、直接测试修复和重复 compile/test 循环留在已批准阶段内。不要仅为了汇报低价值机械步骤增加 checkpoint 或执行 slice。应用会话审计可见性 (instruction continuation: [unit.6063588dfa2ee6c4](../instructions/unit.6063588dfa2ee6c4_zh_cn.md))摘要频率，同时保留必需阶段反馈。

如果阶段证据显示下一阶段依赖高价值判断，应将信号交给 Decision Gate。Decision Gate 负责方案选择和 Contract 更新；本文档不重复这些策略。

### 反馈使用的共享计划证据

反馈使用共享计划证据时，应用任务计划 Memory 生命周期 (instruction continuation: [unit.c3c732f022fc8a5e](../instructions/unit.c3c732f022fc8a5e_zh_cn.md))：在该 owner 规定的阶段、交接、暂停或完成边界，通过获准的当前记录者或已释放贡献路径记录实质进展和带来源事实。普通进度汇报及阶段内的检查或修复，不单独触发持久化或全文读回。影响授权、范围、验收、方向或依赖动作的事实，仍须在受影响动作前记录并分析。反馈携带准确计划身份、持久化确认及 owner 要求的核验证据，不重复全文或改变释放权。缺少必需访问、持久化失败或必需核验失败时，暂停受影响边界；仅已记录的持久化限制可使用该 owner 的例外。

## Codex CLI / ChatGPT Desktop 特别优化指令

Codex 已配置的 `PostToolUse` 或 `SubagentStop` Hook 可以提供工具或子代理的观察结果，供父级压缩 Progress Signal；`PreCompact` 可以标记上下文将被压缩的边界。这些可选事件不证明语义验收，也不应导致完整工具日志或 transcript 倾倒。[OpenAI：工具与生命周期 Hooks](https://learn.chatgpt.com/docs/hooks)。

当前 Session 暴露的 Codex `/diff`、文件／diff 工具、`/agent` 或子代理结果工具可以在阶段边界定位变更文件、行与结果对应的 Worker。返回的 Progress Signal 应压缩为变更路径、实际检查、阻塞及来源指针。可用时，`/review` 产出关于 diff 的**审查发现**；但要求独立 Agent 验证时，仍须有真正独立且获准的验证者上下文。[OpenAI：Diff 与 review](https://learn.chatgpt.com/docs/code-review)、[OpenAI：CLI 命令](https://learn.chatgpt.com/docs/developer-commands)、[OpenAI：子代理线程](https://learn.chatgpt.com/docs/agent-configuration/subagents)。

## Claude Code CLI / Claude Desktop 特别优化指令

### Hook 辅助的精简阶段证据

持久 Claude Code 子代理的 `SubagentStop` 提供 `last_assistant_message`，父级可直接消费精简阶段结果，不必重读完整子代理 transcript。工具执行本身失败时，`PostToolUseFailure` 可提供错误信息，供执行者在**现有**阶段边界汇报；不得把每次失败命令都升级成新的高价值决策检查点。这两种事件都不能替代明确的进度证据、最终验证或父级的 Control 选择。只有当前 Claude Code Runtime 实际安装 Hooks 时才使用，不能套用于无关 Desktop Chat 对话。

官方依据：[SubagentStop 与 PostToolUseFailure 事件数据](https://code.claude.com/docs/en/hooks)。

已配置的 `PostToolUse` 可以在阶段边界提供实际工具结果，但不能替代压缩的 Progress Signal。diff 工具结果可以证明修改行，不代表测试通过或独立验证完成。[Anthropic：Hooks](https://code.claude.com/docs/en/hooks)。
