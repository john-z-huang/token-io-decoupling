# Output route selection

[English](workflow-checkpoints--output-route-selection.md) | [简体中文](workflow-checkpoints--output-route-selection_zh_cn.md)

Apply the current instruction and its included policy sections below. The current actions, guards, evidence and failure boundary are given directly. Before applying a named independent policy, obtain its exact instruction continuation; reuse any already held unit from this build and retain the affected action's return position. Do not retrieve author files or infer omitted policy. Check current facts and authorization before effects; an instruction is not a pass.

## Hard constraints

- Record hard user, runtime environment, repository, permission, safety, and Session constraints before acting.
- A task-level prohibition, such as “do not create subagents” or “do not use a browser,” remains active for the whole task.
- Computer Use is categorically forbidden: never control a computer, browser, or desktop app through its graphical interface — no screenshots to locate controls, mouse or keyboard simulation, clicking, accessibility APIs, window automation, remote-desktop control, or GUI scripting — and do not route such interaction through an API, CLI, MCP server, helper, or another Agent. Treat this as a blacklist rather than a list of allowed channels: every other tool, command, or capability actually exposed to and authorized for the current Session remains permitted. If a required step needs a forbidden operation, stop and report the blocker instead of attempting, delegating, or skipping it.
- Before route selection or any delegation/Session-topology work, the Mode checkpoint must compose and validate the delegation references; those references own conversation-level mode selection with a default Multi-Agent route and one-child budget, child counts, conditional creation, allocation, reuse, replacement, exceptions, and limits at their respective atomic boundaries. A reserved budget never initializes or authorizes a child by itself.
- Never invent authorization, capability, evidence, product support, or an executable route for an unmaintained scenario.
- Keep Core rules independent of product details; read [Runtime and Model Provider Support](../instructions/fundamental-concepts--session-runtime--runtime-provider-support.md) for supported runtime branches and model bindings.
- Read references on demand. Do not preload the entire Skill, `references/`, or raw project state merely because it may become useful.

# Output route selection


This checkpoint owns the independent assessment of whether each requested direct Root output should route away from Root under [Output Token Routing](../instructions/fundamental-concepts--execution-planning--output-token-routing.md). It does not select an executor.

## Trigger and inputs

Once the current task scope and mode are established, assess each requested direct Root output by its shape, expected output volume, explicit user direction, locked mode, and current verified facts. Check explicit direction before advice. Do not use unrelated input/transcript size or an arbitrary numeric threshold.

## Decision and result

1. If explicit user instruction settles who produces the output or whether it is produced, record that direction and skip only its corresponding advice; all other gates remain active.
2. Otherwise return `yes`, `no`, `insufficient_evidence`, or `failed` per output, with the evidence and current input/context/policy hashes. A stale input or policy-hash mismatch is unresolved, never `no`.
3. `yes` means Root should route the large output away from direct materialization. In Single-Agent mode, hold and report the topology boundary. In Multi-Agent mode, use a suitable idle current-Session child or wait/hold until one is idle. `no` permits Root to continue subject to all other gates.
4. Keep this result independent from executor selection. A `yes` alone does not authorize creating a child. Only a separately established need for a new executor can proceed to role/capacity, Slice, and creation gates in order.
5. Return the per-output result and evidence to route scheduling; do not release a Slice or dispatch here.

## Failure boundary

Insufficient facts, stale or mismatched hashes, failed advice, or conflicting output evidence returns unresolved. Review the direct owner from verified facts only when they suffice; otherwise block. Never default to `no`, create for output size alone, or bypass the locked-mode boundary.
