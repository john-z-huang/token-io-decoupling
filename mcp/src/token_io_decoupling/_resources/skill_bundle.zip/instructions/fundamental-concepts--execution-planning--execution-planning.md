# Coding Execution Planning

[English](fundamental-concepts--execution-planning--execution-planning.md) | [简体中文](fundamental-concepts--execution-planning--execution-planning_zh_cn.md)

Apply the current instruction and its included policy sections below. The current actions, guards, evidence and failure boundary are given directly. Before applying a named independent policy, obtain its exact instruction continuation; reuse any already held unit from this build and retain the affected action's return position. Do not retrieve author files or infer omitted policy. Check current facts and authorization before effects; an instruction is not a pass.

## Hard constraints

- Record hard user, runtime environment, repository, permission, safety, and Session constraints before acting.
- A task-level prohibition, such as “do not create subagents” or “do not use a browser,” remains active for the whole task.
- Computer Use is categorically forbidden: never control a computer, browser, or desktop app through its graphical interface — no screenshots to locate controls, mouse or keyboard simulation, clicking, accessibility APIs, window automation, remote-desktop control, or GUI scripting — and do not route such interaction through an API, CLI, MCP server, helper, or another Agent. Treat this as a blacklist rather than a list of allowed channels: every other tool, command, or capability actually exposed to and authorized for the current Session remains permitted. If a required step needs a forbidden operation, stop and report the blocker instead of attempting, delegating, or skipping it.
- Before route selection or any delegation/Session-topology work, the Mode checkpoint must compose and validate the delegation references; those references own conversation-level mode selection with a default Multi-Agent route and one-child budget, child counts, conditional creation, allocation, reuse, replacement, exceptions, and limits at their respective atomic boundaries. A reserved budget never initializes or authorizes a child by itself.
- Never invent authorization, capability, evidence, product support, or an executable route for an unmaintained scenario.
- Keep Core rules independent of product details; read [Runtime and Model Provider Support](../instructions/fundamental-concepts--session-runtime--runtime-provider-support.md) for supported runtime branches and model bindings.
- Read references on demand. Do not preload the entire Skill, `references/`, or raw project state merely because it may become useful.

# Coding Execution Planning

## General rules

### Two-level planning

Translate an approved direction into bounded inspection, implementation, and focused-check steps. The plan records the stage outline and the evidence each stage is expected to produce without turning stages into a command list.

### Reconnaissance to implementation release

When project facts are needed before a material decision, plan a bounded reconnaissance slice that returns compressed facts, evidence-backed options, and unresolved questions. The decision gate then confirms or rejects the direction before implementation is released. Planning does not approve a new semantic or architecture direction. The shared task plan is persisted by default under [Task Plan Memory Lifecycle](../instructions/fundamental-concepts--execution-planning--task-plan-memory-lifecycle.md); an explicit planning request is unnecessary. Dedicated planning modes are optional drafting paths. Keep the plan separate from live parent scheduling state.

## Codex CLI / ChatGPT Desktop optimizations

In an interactive Codex CLI or an Agent Session that exposes the direct `/plan` command, invoke `/plan` to enter Plan mode; optionally append the first planning request, for example `/plan Propose a migration plan for this service`. Codex uses that prompt to draft an execution plan before implementation. The command is unavailable while Codex is already working; when no direct `/plan` control is exposed, use the general bounded planning process. By default, persist the concise synthesized plan and complete any required verification under [Task Plan Memory Lifecycle](../instructions/fundamental-concepts--execution-planning--task-plan-memory-lifecycle.md); `/plan` is an optional drafting path; the transcript is not the plan record. If required Memory tools or permission are unavailable, report the limitation and block dependent persistence without a file fallback. The parent task record remains the owner for live task state. [OpenAI: slash commands](https://learn.chatgpt.com/docs/developer-commands).

## Claude Code CLI / Claude Desktop optimizations

In an existing Claude Code Session, use Plan mode for read-only stage drafting only when that Session directly exposes and authorizes the control; the launch-only flag and Session-identity boundary are owned by [Runtime and Model Provider Support](../instructions/fundamental-concepts--session-runtime--runtime-provider-support.md). Otherwise use the general bounded planning process. By default, persist the concise synthesized stage/evidence outline and complete any required verification under [Task Plan Memory Lifecycle](../instructions/fundamental-concepts--execution-planning--task-plan-memory-lifecycle.md), subject to actual Serena tool exposure and effective permission; Claude Plan mode is an optional drafting path. Do not treat the transcript as the plan record or use it to bypass permission controls; report and block dependent persistence if unavailable, without a file fallback. The parent task record remains the owner for live task state. Before editing, confirm both the released Interaction Slice and effective tool permissions. `/tasks` reports running/background Agent work; it is not a durable plan record or a substitute for stage checkpoints. [Anthropic: workflows](https://code.claude.com/docs/en/common-workflows), [Anthropic: background agents](https://code.claude.com/docs/en/sub-agents).
