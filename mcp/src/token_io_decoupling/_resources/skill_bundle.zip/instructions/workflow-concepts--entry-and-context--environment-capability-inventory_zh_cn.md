# Coding 运行环境能力清单

[English](workflow-concepts--entry-and-context--environment-capability-inventory.md) | [简体中文](workflow-concepts--entry-and-context--environment-capability-inventory_zh_cn.md)

下列直接给出当前动作、守卫、证据和失败边界。应用独立政策前，先按明确的指令继续入口取得对应单元；同一构建中已持有的单元直接复用，并保留受影响动作的准确恢复位置。不读取作者文件或推测缺失政策。执行副作用前核实当前事实与授权；指令内容可用不表示检查通过。

## 硬约束

- 采取行动前记录用户、运行环境、仓库、权限、安全和 Session 硬约束。
- “不要创建子代理”“不要使用浏览器”等任务级禁止条件在整个任务中持续有效。
- 绝对禁止 Computer Use：不得通过图形界面控制计算机、浏览器或桌面应用——包括以操纵控件为目的的截图、鼠标／键盘模拟、点击、辅助功能 API、窗口自动化、远程桌面控制或 GUI 脚本——也不得把此类交互包装为 API、CLI、MCP Server、辅助程序或其他 Agent 调用来绕过。本节是黑名单而非允许渠道清单：当前 Session 实际暴露且已获授权的其他工具、命令或能力仍然允许。若必需步骤需要借助被禁止的操作，应停止并报告阻塞，而不是尝试、委派或跳过。
- 路线选择或任何委派/Session 拓扑工作前，模式检查点必须组合并验证委派 references；这些 references 在各自的原子边界内规定会话级模式选择及默认多代理路线和单个子代理预算、子代理数量、条件创建、分配、复用、替换、例外和限制。预留预算本身不会初始化或授权创建子代理。
- 不得虚构授权、能力、证据、产品支持，或为未维护场景推导可执行路线。
- Core 规则不依赖具体产品；受支持的运行环境分支和模型绑定见[运行环境与模型厂商支持](../instructions/fundamental-concepts--session-runtime--runtime-provider-support_zh_cn.md)。
- 按需读取 reference。不要仅因为可能以后有用，就预加载整个 Skill、`references/` 或原始项目状态。

# Coding 运行环境能力清单


本文档负责已分类运行环境的能力清单：暴露能力、未知能力处理和依赖路线阻断。分支定义和模型绑定由[运行环境与模型厂商支持](../instructions/fundamental-concepts--session-runtime--runtime-provider-support_zh_cn.md)负责。本文档不分类运行环境，不选择执行模式，不绑定角色，不授权委派，不授权实现，也不定义任务策略。

## 暴露能力清单

只记录当前界面直接暴露的能力：模型身份和参数控制、Session 拓扑、文件系统与沙箱访问、工具、连接器、认证，以及委派工作可用的返回路径。

## 未知能力和路线阻断

未观察到的能力标记为未知。不得替换成其他运行环境、模型、参数、Session、工具、权限或推断出的能力。所需能力缺失或未知时，阻塞依赖该能力的切片。

## 受保护操作能力

针对每项受保护操作，记录当前 Session 和角色事实，以及该操作实际要求的能力和权限检查，并附上证据与范围。应用请求范围或公共规则接口不能认证身份或证明授权。必需能力缺失时，只阻塞依赖工作。本清单不授权受保护调用。

## 路线消费

路线消费这份能力清单和状态，只记录各自拓扑差异。按[运行环境与模型厂商支持](../instructions/fundamental-concepts--session-runtime--runtime-provider-support_zh_cn.md)应用分支特定的控制和模型绑定。

路线所需的 profile 是能力要求，不是对整个产品可用性的声明。分支特定路线只有在本清单记录当前 surface 实际生效的模型身份及该 profile 要求的每项参数后，才能消费该 profile。如果必需的模型或参数未暴露或未知，必须将该要求记录到 `unavailable_capabilities`，并阻塞依赖的切片或路线。不得静默替换模型、reasoning effort、Session、工具、权限或 mode/count；选择其他路线必须重新进入其适用门禁并取得新的明确确认。这使 Core 规则与产品细节解耦，同时允许路线消费其所需的、特定于 surface 的 profile。
