# unit.33ed6b6bb3ad7509_zh_cn

[English](unit.33ed6b6bb3ad7509.md) | [简体中文](unit.33ed6b6bb3ad7509_zh_cn.md)

下列直接给出当前动作、守卫、证据和失败边界。应用独立政策前，先按明确的指令继续入口取得对应单元；同一构建中已持有的单元直接复用，并保留受影响动作的准确恢复位置。不读取作者文件或推测缺失政策。执行副作用前核实当前事实与授权；指令内容可用不表示检查通过。

## 硬约束

- 采取行动前记录用户、运行环境、仓库、权限、安全和 Session 硬约束。
- “不要创建子代理”“不要使用浏览器”等任务级禁止条件在整个任务中持续有效。
- 绝对禁止 Computer Use：不得通过图形界面控制计算机、浏览器或桌面应用——包括以操纵控件为目的的截图、鼠标／键盘模拟、点击、辅助功能 API、窗口自动化、远程桌面控制或 GUI 脚本——也不得把此类交互包装为 API、CLI、MCP Server、辅助程序或其他 Agent 调用来绕过。本节是黑名单而非允许渠道清单：当前 Session 实际暴露且已获授权的其他工具、命令或能力仍然允许。若必需步骤需要借助被禁止的操作，应停止并报告阻塞，而不是尝试、委派或跳过。
- 路线选择或任何委派/Session 拓扑工作前，模式检查点必须组合并验证委派 references；这些 references 在各自的原子边界内规定会话级模式选择及默认多代理路线和单个子代理预算、子代理数量、条件创建、分配、复用、替换、例外和限制。预留预算本身不会初始化或授权创建子代理。
- 不得虚构授权、能力、证据、产品支持，或为未维护场景推导可执行路线。
- Core 规则不依赖具体产品；受支持的运行环境分支和模型绑定见运行环境与模型厂商支持 (instruction continuation: [unit.081374cfbaa37b57](../instructions/unit.081374cfbaa37b57_zh_cn.md))。
- 按需读取 reference。不要仅因为可能以后有用，就预加载整个 Skill、`references/` 或原始项目状态。

# Session 就绪模块


本 Layer-04 模块为有界下游工作建立当前且已核验的 Session 记录与审计结果。它组合 Session owners 并向调用方返回证据；不重开 Mode、不产生计划/决策输出，也不调度其他模块。

## 入口声明

| 字段 | 要求 |
| --- | --- |
| 必需输入 | 当前任务范围和 Contract、已释放入口/路线/模式证据、当前 Session 身份/角色事实及父级控制记录来源。此处核验该记录，但它不是入口前置条件。 |
| 允许效果 | 读取并核实当前 Session 事实和父级控制记录；在其 owner 授权下将审计偏好应用于该记录。 |
| 结果 | 适用时，模块返回含当前 Session 事实、规范 parent-context 记录回读、生效审计偏好和 Multi-Agent 容量证据的 `complete`；否则返回带暂停位置的 `needs_prerequisite` 或 `blocked`。条件子步骤可记录有原因的 `not_applicable`；Session 模块本身不可跳过。 |
| 新鲜度 | 将证据绑定至当前 Session 身份/角色、最新 parent-context 回读、显式/缺省审计值、分配状态、来源及相关 epoch。实质变化会使受影响事实失效；消费依赖结果前重新读取父级控制记录。 |

## 工作流路线图


## 有序模块清单

1. **SR00 — 解析入口。** 提供本声明、当前任务范围、已释放的入口/路线/模式证据、Session 身份/角色事实、所选路径、epoch 和 continuation/效果状态，调用模块入口解析 (instruction continuation: [unit.f56021d97f9b69f7](../instructions/unit.f56021d97f9b69f7_zh_cn.md))。规范记录由本模块建立，不是入口前置条件。从记录的子步骤恢复。缺少前置条件时，以 owner 和暂停位置返回 `needs_prerequisite`；状态不安全或无法恢复时返回 `blocked`。
2. **SR01 — 复核实质变化。** 若当前 Contract、Context 或 Decision 发生实质变化，在依赖它们前审阅当前直接证据。不得重做规划、请求建议、重开 Mode 或启动下游效果。无实质变化时，记录有原因的 `not_applicable`。事实缺失时返回 `needs_prerequisite`；冲突或不安全事实返回 `blocked`。
3. **SR02 — 核验规范 parent-context 记录。** 应用Session 状态解决 (instruction continuation: [unit.690f2bdc7f95134d](../instructions/unit.690f2bdc7f95134d_zh_cn.md))及其直接链接的 Session、角色和 Context Firewall owner。核实已释放的 mode/count、当前身份和角色、逐操作所需权限以及记录一致性。回读规范记录和适用的 allocation 状态。结构工具结果或应用请求范围不能证明身份或授权。证据缺失时返回 `needs_prerequisite`；未解决冲突或必需 owner 不可用时返回 `blocked`。
4. **SR03 — 应用审计偏好。** 应用Session 审计解决 (instruction continuation: [unit.d8fab56bd46fe7b7](../instructions/unit.d8fab56bd46fe7b7_zh_cn.md))、Session Audit Visibility (instruction continuation: [unit.6063588dfa2ee6c4](../instructions/unit.6063588dfa2ee6c4_zh_cn.md))、Reasoning Summary Visibility (instruction continuation: [unit.d97fa46d10460df3](../instructions/unit.d97fa46d10460df3_zh_cn.md))和委派状态记录 (instruction continuation: [unit.04519b62e6c4f711](../instructions/unit.04519b62e6c4f711_zh_cn.md))。保留必需进度/报告义务和保密规则。立即应用显式偏好或缺省值；不得将提示、计时器、迁移或审计偏好设为前置条件。Worker 日志可见性只依据实际访问证据记录；仅当必需日志证据不可用或未验证时，才阻塞依赖它的判断。
5. **SR04 — 仅在 Multi-Agent 适用时核验容量。** 在已放行 Multi-Agent 模式下，读取当前父级控制分配。应用委派数量门禁 (instruction continuation: [unit.36a14d319d1b638c](../instructions/unit.36a14d319d1b638c_zh_cn.md))、委派状态记录 (instruction continuation: [unit.04519b62e6c4f711](../instructions/unit.04519b62e6c4f711_zh_cn.md))，并按条件应用子代理职责分配 (instruction continuation: [unit.4706ccaa5a523c17](../instructions/unit.4706ccaa5a523c17_zh_cn.md))，核实锁定容量、已占用角色和未分配名额。这只是只读核验：不得选择/预留角色、释放 Slice、创建子代理或回收名额。Single-Agent 模式记录附有理由的 `not_applicable`。返回 `complete`，并附上当前父级记录读回、生效的审计偏好和适用的容量证据；这些证据均不授权子代理任务。
