# Executor selection

[English](workflow-checkpoints--executor-selection.md) | [简体中文](workflow-checkpoints--executor-selection_zh_cn.md)

Apply the current instruction and its included policy sections below. The current actions, guards, evidence and failure boundary are given directly. Before applying a named independent policy, obtain its exact instruction continuation; reuse any already held unit from this build and retain the affected action's return position. Do not retrieve author files or infer omitted policy. Check current facts and authorization before effects; an instruction is not a pass.

## Hard constraints

- Record hard user, runtime environment, repository, permission, safety, and Session constraints before acting.
- A task-level prohibition, such as “do not create subagents” or “do not use a browser,” remains active for the whole task.
- Computer Use is categorically forbidden: never control a computer, browser, or desktop app through its graphical interface — no screenshots to locate controls, mouse or keyboard simulation, clicking, accessibility APIs, window automation, remote-desktop control, or GUI scripting — and do not route such interaction through an API, CLI, MCP server, helper, or another Agent. Treat this as a blacklist rather than a list of allowed channels: every other tool, command, or capability actually exposed to and authorized for the current Session remains permitted. If a required step needs a forbidden operation, stop and report the blocker instead of attempting, delegating, or skipping it.
- Before route selection or any delegation/Session-topology work, the Mode checkpoint must compose and validate the delegation references; those references own conversation-level mode selection with a default Multi-Agent route and one-child budget, child counts, conditional creation, allocation, reuse, replacement, exceptions, and limits at their respective atomic boundaries. A reserved budget never initializes or authorizes a child by itself.
- Never invent authorization, capability, evidence, product support, or an executable route for an unmaintained scenario.
- Keep Core rules independent of product details; read [Runtime and Model Provider Support](../instructions/fundamental-concepts--session-runtime--runtime-provider-support.md) for supported runtime branches and model bindings.
- Read references on demand. Do not preload the entire Skill, `references/`, or raw project state merely because it may become useful.

# Executor selection


This checkpoint owns executor routing after the current task scope and mode are established. [Task Assignment](../instructions/fundamental-concepts--execution-planning--task-assignment.md) remains authoritative for executor and candidate selection policy.

## Trigger and inputs

Run after current facts, explicit user direction, locked mode, and an authorized proposed task are established. Read the Task Assignment owner and current verified Session allocation, identity, capability, permission, and availability facts. Executor selection does not settle output size or release a child Slice.

## Decision and result

1. Check explicit direction first. Honor an explicit executor/candidate subject to mode, permission, current identity, capability, scope, and availability; skip only the corresponding advice. Under locked Single-Agent mode, explicit `sub_agent` conflicts and returns for Root review; explicit `root` is valid. With no executor instruction, the Single-Agent route is deterministic Root and makes no executor-advice request.
2. In Multi-Agent mode, compare current task facts and authorized scope. If Root is appropriate under permissions and capability, return `root`; if a child is required, examine only verified, eligible current-Session children. After a Fork, first complete fresh mode/count re-entry for the new Session; inherited children never become candidates for that new Session through re-entry.
3. Apply the owner’s candidate filter. Select a single eligible candidate directly. When multiple candidates remain, prefer eligible idle candidates; if exactly one idle candidate remains after filtering, select it. If two or more eligible idle candidates remain, compare them using the current task-context procedure in Task Assignment, including its suitable idle Primary branch. Do not select by transcript size or invented thresholds. If no suitable existing child exists but child execution is required, record the route disposition `new-executor-needed` from the verified `sub_agent` direction and empty eligible-candidate result, with authorization, task facts, and candidate-filter evidence. This is not a new registration decision or tool-return enum and does not authorize creation. If suitable children exist but are busy, pass the busy state to the route for independent output assessment before waiting.
4. For busy candidates, route each requested direct Root output under Output Token Routing before waiting. A `no` returns to remaining Root gates; a `yes` requires a suitable idle child or hold/wait; insufficient/failure stays unresolved unless verified direct facts suffice. Recheck identity, authority, role, capability, permission, scope, and latest availability immediately before dispatch.
5. Return `root`, selected candidate, `new-executor-needed`, `hold`, or `insufficient_evidence` with current evidence, policy/input/context hashes when advice was used, and rationale. Advice failure never defaults to Root. This checkpoint does not reserve a new role, release a Slice, create, or dispatch.

## Failure boundary

Missing or stale facts, conflicting direction, unknown mode/permission/capability, unavailable candidate identity, unresolved selection, or advice/hash failure without sufficient direct evidence returns unresolved and blocks downstream release. Never assume Root or candidate availability.
