# 工作流导航选择

[English](workflow-checkpoints--workflow-navigation-selection.md) | [简体中文](workflow-checkpoints--workflow-navigation-selection_zh_cn.md)

下列直接给出当前动作、守卫、证据和失败边界。应用独立政策前，先按明确的指令继续入口取得对应单元；同一构建中已持有的单元直接复用，并保留受影响动作的准确恢复位置。不读取作者文件或推测缺失政策。执行副作用前核实当前事实与授权；指令内容可用不表示检查通过。

## 硬约束

- 采取行动前记录用户、运行环境、仓库、权限、安全和 Session 硬约束。
- “不要创建子代理”“不要使用浏览器”等任务级禁止条件在整个任务中持续有效。
- 绝对禁止 Computer Use：不得通过图形界面控制计算机、浏览器或桌面应用——包括以操纵控件为目的的截图、鼠标／键盘模拟、点击、辅助功能 API、窗口自动化、远程桌面控制或 GUI 脚本——也不得把此类交互包装为 API、CLI、MCP Server、辅助程序或其他 Agent 调用来绕过。本节是黑名单而非允许渠道清单：当前 Session 实际暴露且已获授权的其他工具、命令或能力仍然允许。若必需步骤需要借助被禁止的操作，应停止并报告阻塞，而不是尝试、委派或跳过。
- 路线选择或任何委派/Session 拓扑工作前，模式检查点必须组合并验证委派 references；这些 references 在各自的原子边界内规定会话级模式选择及默认多代理路线和单个子代理预算、子代理数量、条件创建、分配、复用、替换、例外和限制。预留预算本身不会初始化或授权创建子代理。
- 不得虚构授权、能力、证据、产品支持，或为未维护场景推导可执行路线。
- Core 规则不依赖具体产品；受支持的运行环境分支和模型绑定见[运行环境与模型厂商支持](../instructions/fundamental-concepts--session-runtime--runtime-provider-support_zh_cn.md)。
- 按需读取 reference。不要仅因为可能以后有用，就预加载整个 Skill、`references/` 或原始项目状态。

# 工作流导航选择


本检查点选择当前编译指令交付入口及有用的可选结构输入检查；交付和结构结果与独立判断任务事实及完成状态保持分离。

## 触发与输入

使用当前[环境](../instructions/workflow-concepts--entry-and-context--environment_zh_cn.md)及[能力清单](../instructions/workflow-concepts--entry-and-context--environment-capability-inventory_zh_cn.md)结果。可选导航可能有帮助时，参考[工作流导航可用性](../instructions/fundamental-concepts--workflow-navigation--navigation-availability_zh_cn.md)和[工作流规则上下文](../instructions/fundamental-concepts--workflow-navigation--rule-context_zh_cn.md)。若对所供检查点事实执行结构检查可能有帮助，则应用[检查点结构检查](../instructions/fundamental-concepts--workflow-navigation--checkpoint-structure-checks_zh_cn.md)。除非任务本身要求相关结果，否则两种辅助能力均为可选。

## 决策与结果

1. 标识当前指令单元及动作所需的明确继续入口，保留准确暂停位置与已完成副作用。
2. 可选导航有用且可用时，消费其当前完整指令正文，核验语言、资源或构建标识及完整性；这些均不建立身份、权限、语义真实性、检查点完成、跨调用顺序或验收。
3. 结构检查有用时，对照所供输入和当前编译指令审阅结构结果，再独立判断证据含义；结构结果不建立授权或语义真实性。
4. 可选辅助能力不需要时，记录附理由的 `Not applicable`，直接消费对应已交付指令，不查找作者文档。
5. 可选导航不可用时，可由实际可用且获授权的同构建生成纯文档指令入口提供明确当前单元。必需资源缺失、不完整或不兼容时阻塞依赖判断；资源错误不授权作者源回退。
6. 返回所选来源和任何所需的结构检查结果供审阅。本决策不会更改工作流状态、授权操作或建立检查点结果。

## 失败边界

| 结果 | 必需操作 |
| --- | --- |
| 不需要可选导航 | 记录 `Not applicable`；直接消费必要已交付指令。 |
| 有界导航可用 | 审阅当前完整正文及准确继续入口，独立判断事实。 |
| 不需要或无法进行可选结构检查 | 附理由记录 `Not applicable`；除非任务独立要求该结果，否则依据当前编译指令继续。 |
| 结构检查可用且已选择 | 对照当前指令和所供输入审阅结果，独立判断证据。 |
| 导航不可用但同构建生成指令可访问 | 消费准确交付单元并记录限制。 |
| 必需指令资源不可用、不完整或不兼容 | 阻塞依赖判断，不推断政策、跳过守卫或读取作者源。 |
