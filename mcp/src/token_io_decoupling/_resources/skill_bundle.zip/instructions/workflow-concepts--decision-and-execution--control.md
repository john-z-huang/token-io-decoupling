# Control Boundary Checkpoint

[English](workflow-concepts--decision-and-execution--control.md) | [简体中文](workflow-concepts--decision-and-execution--control_zh_cn.md)

Apply the current instruction and its included policy sections below. The current actions, guards, evidence and failure boundary are given directly. Before applying a named independent policy, obtain its exact instruction continuation; reuse any already held unit from this build and retain the affected action's return position. Do not retrieve author files or infer omitted policy. Check current facts and authorization before effects; an instruction is not a pass.

## Hard constraints

- Record hard user, runtime environment, repository, permission, safety, and Session constraints before acting.
- A task-level prohibition, such as “do not create subagents” or “do not use a browser,” remains active for the whole task.
- Computer Use is categorically forbidden: never control a computer, browser, or desktop app through its graphical interface — no screenshots to locate controls, mouse or keyboard simulation, clicking, accessibility APIs, window automation, remote-desktop control, or GUI scripting — and do not route such interaction through an API, CLI, MCP server, helper, or another Agent. Treat this as a blacklist rather than a list of allowed channels: every other tool, command, or capability actually exposed to and authorized for the current Session remains permitted. If a required step needs a forbidden operation, stop and report the blocker instead of attempting, delegating, or skipping it.
- Before route selection or any delegation/Session-topology work, the Mode checkpoint must compose and validate the delegation references; those references own conversation-level mode selection with a default Multi-Agent route and one-child budget, child counts, conditional creation, allocation, reuse, replacement, exceptions, and limits at their respective atomic boundaries. A reserved budget never initializes or authorizes a child by itself.
- Never invent authorization, capability, evidence, product support, or an executable route for an unmaintained scenario.
- Keep Core rules independent of product details; read [Runtime and Model Provider Support](../instructions/fundamental-concepts--session-runtime--runtime-provider-support.md) for supported runtime branches and model bindings.
- Read references on demand. Do not preload the entire Skill, `references/`, or raw project state merely because it may become useful.

# Control Boundary Checkpoint


## Actions

1. Consume the compressed Progress Signal from the Stage Feedback owner; append the current `Unreleased boundary` without creating a second progress report.
2. Check whether the next action crosses an interface, schema, compatibility, security, risk, irreversible, scope, or external-effect boundary.
3. If more evidence is required, request Evidence-on-Demand and **pause** release; return to this checkpoint after evidence arrives. This is an intermediate action, not a fourth final authorization outcome.
4. Choose the final `Continue`, `Amend`, or `Stop` outcome. Only an explicit `Continue` releases the next slice within the approved envelope; `Amend` returns through Contract and Decision. In Single-Agent this is a logical pause; in Multi-Agent the parent controls release.
   - A material change to the task record, authorization, scope, implementation, or relevant evidence invalidates any dependent earlier Control result. Re-evaluate Control from current authoritative facts before releasing or resuming a Slice.

5. If the route supplies advisory output, treat it only as input. Verify current Root state and direct Control owner, then make and persist the explicit outcome through the trusted transition; advice itself has no effect. Use current direct evidence to make the decision. Apply [Decisions Advisory](../instructions/fundamental-concepts--execution-planning--decisions-advisory.md) for advisory policy.

Apply [Task Plan Memory Lifecycle](../instructions/fundamental-concepts--execution-planning--task-plan-memory-lifecycle.md) to confirm current plan evidence and persistence, plus any verification the owner requires, before dependent release. On a user requirement change, record the instruction first, then analyze and persist the impact/revised proposal before resolving the affected Contract/Decision and authorizing changes. Required persistence or verification failure pauses affected release; plan text alone never authorizes it.

## Pass condition

The next action is either released within the current envelope or is paused with the required amendment, evidence, capability, or authorization named.

## Boundary

This checkpoint controls release and authority. It does not silently approve scope expansion, replace verification, or grant Git or external-effect authorization.
