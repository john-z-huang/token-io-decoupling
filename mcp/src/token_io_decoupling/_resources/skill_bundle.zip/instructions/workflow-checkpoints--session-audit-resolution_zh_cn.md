# Session 审计解决

[English](workflow-checkpoints--session-audit-resolution.md) | [简体中文](workflow-checkpoints--session-audit-resolution_zh_cn.md)

下列直接给出当前动作、守卫、证据和失败边界。应用独立政策前，先按明确的指令继续入口取得对应单元；同一构建中已持有的单元直接复用，并保留受影响动作的准确恢复位置。不读取作者文件或推测缺失政策。执行副作用前核实当前事实与授权；指令内容可用不表示检查通过。

## 硬约束

- 采取行动前记录用户、运行环境、仓库、权限、安全和 Session 硬约束。
- “不要创建子代理”“不要使用浏览器”等任务级禁止条件在整个任务中持续有效。
- 绝对禁止 Computer Use：不得通过图形界面控制计算机、浏览器或桌面应用——包括以操纵控件为目的的截图、鼠标／键盘模拟、点击、辅助功能 API、窗口自动化、远程桌面控制或 GUI 脚本——也不得把此类交互包装为 API、CLI、MCP Server、辅助程序或其他 Agent 调用来绕过。本节是黑名单而非允许渠道清单：当前 Session 实际暴露且已获授权的其他工具、命令或能力仍然允许。若必需步骤需要借助被禁止的操作，应停止并报告阻塞，而不是尝试、委派或跳过。
- 路线选择或任何委派/Session 拓扑工作前，模式检查点必须组合并验证委派 references；这些 references 在各自的原子边界内规定会话级模式选择及默认多代理路线和单个子代理预算、子代理数量、条件创建、分配、复用、替换、例外和限制。预留预算本身不会初始化或授权创建子代理。
- 不得虚构授权、能力、证据、产品支持，或为未维护场景推导可执行路线。
- Core 规则不依赖具体产品；受支持的运行环境分支和模型绑定见[运行环境与模型厂商支持](../instructions/fundamental-concepts--session-runtime--runtime-provider-support_zh_cn.md)。
- 按需读取 reference。不要仅因为可能以后有用，就预加载整个 Skill、`references/` 或原始项目状态。

# Session 审计解决


本检查点负责将当前 Session 审计偏好应用于父级控制记录，并核对最终值；不将审计可见性设为权限或执行门禁。

## 触发与输入

取得规范 parent-context 记录后，使用该记录和当前 Session 审计事实。应用[Session Audit Visibility](../instructions/fundamental-concepts--session-runtime--session-audit-visibility_zh_cn.md)了解字段值与显示语义，并应用[委派状态记录](../instructions/fundamental-concepts--delegation--delegation-state-record_zh_cn.md)了解记录归属和结构。

## 决策与结果

使用用户已提供或当前父级控制记录中保留的有效显式偏好。否则立即应用缺省值：Root 为 `balanced/milestone_only`；Worker 为 `full`。用户可明确更改任一偏好，父级记录最终值及其显式或缺省来源。不得强制首次提问。不得启动计时器、等待回复或迁移旧提示状态值。

若现有记录含过时提示/计时或迁移字段，则忽略这些字段并保留有效偏好值。不得根据过时提示状态推断偏好。若当前显式值冲突或无效，适当时只针对受影响偏好请求澄清；若无法解决，则使用策略缺省值并报告限制，不阻塞无关工作。

Worker 日志可见性仍只是证据描述。若任务依赖访问完整安全 Worker 会话记录，只能依据实际访问证据报告 `available`、`unverified` 或 `unavailable`；不存在 Worker 时，记录带理由的 `Not applicable`。若该证据是必需的且不可用或未验证，则仅阻塞依赖它的审计判断。仅返回最终正文或发现工具均不能证明可访问完整日志。

## 失败边界

偏好收集是可选项，绝不授予授权。未提供偏好时，继续使用有效缺省值。保留必需进度报告和保密规则。仅当某项判断依赖缺失的必需审计证据时才阻塞；报告偏好或 Worker 日志证据不可用，但不得把它视为完成证明。
