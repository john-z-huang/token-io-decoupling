# unit.90ad9fe16c44d13f_zh_cn

[English](unit.90ad9fe16c44d13f.md) | [简体中文](unit.90ad9fe16c44d13f_zh_cn.md)

下列直接给出当前动作、守卫、证据和失败边界。应用独立政策前，先按明确的指令继续入口取得对应单元；同一构建中已持有的单元直接复用，并保留受影响动作的准确恢复位置。不读取作者文件或推测缺失政策。执行副作用前核实当前事实与授权；指令内容可用不表示检查通过。

## 硬约束

- 采取行动前记录用户、运行环境、仓库、权限、安全和 Session 硬约束。
- “不要创建子代理”“不要使用浏览器”等任务级禁止条件在整个任务中持续有效。
- 绝对禁止 Computer Use：不得通过图形界面控制计算机、浏览器或桌面应用——包括以操纵控件为目的的截图、鼠标／键盘模拟、点击、辅助功能 API、窗口自动化、远程桌面控制或 GUI 脚本——也不得把此类交互包装为 API、CLI、MCP Server、辅助程序或其他 Agent 调用来绕过。本节是黑名单而非允许渠道清单：当前 Session 实际暴露且已获授权的其他工具、命令或能力仍然允许。若必需步骤需要借助被禁止的操作，应停止并报告阻塞，而不是尝试、委派或跳过。
- 路线选择或任何委派/Session 拓扑工作前，模式检查点必须组合并验证委派 references；这些 references 在各自的原子边界内规定会话级模式选择及默认多代理路线和单个子代理预算、子代理数量、条件创建、分配、复用、替换、例外和限制。预留预算本身不会初始化或授权创建子代理。
- 不得虚构授权、能力、证据、产品支持，或为未维护场景推导可执行路线。
- Core 规则不依赖具体产品；受支持的运行环境分支和模型绑定见运行环境与模型厂商支持 (instruction continuation: [unit.081374cfbaa37b57](../instructions/unit.081374cfbaa37b57_zh_cn.md))。
- 按需读取 reference。不要仅因为可能以后有用，就预加载整个 Skill、`references/` 或原始项目状态。

# Worker Content Memo Dispatch

## 通用规范

### Dispatch 开关

每个已放行 bundle 都必须显式包含 `write_content_memo: true` 或 `false`；Worker 不得自行推断默认值。`true` 启用对 `context-exchange/workers/<worker-context-id>/content-memo` 的写入；`false` 只关闭该 memo。已放行 bundle 中须包含准确 Memory 名称。父级控制开关和名称，但这只是逻辑归属：Serena 不强制 Worker 级访问或只读 ACL。

Memory 工具未暴露或未获授权时，报告限制并阻塞依赖 memo 的切片；不得把 memo 物化为文件。其他独立工作可以继续。

## Codex CLI / ChatGPT Desktop 特别优化指令

在实际放行的子任务提示中序列化开关和准确 Memory 名称。只使用实际暴露且获准的 Serena Memory 工具，并确认写入结果。Codex 配置、Hooks、本地 Memory 或 compaction 本身均不实现此开关。

## Claude Code CLI / Claude Desktop 特别优化指令

当前 Agent Session 暴露且授权 Serena MCP Memory 工具时，在已放行 bundle 中包含开关和名称，并确认写入结果。Claude auto memory、Hooks 或 compaction 不能代替具名项目 Memory。工具不可用时按通用阻塞/报告规则处理。
