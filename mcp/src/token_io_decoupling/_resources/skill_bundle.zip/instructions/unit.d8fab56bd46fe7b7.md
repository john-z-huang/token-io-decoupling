# unit.d8fab56bd46fe7b7

[English](unit.d8fab56bd46fe7b7.md) | [简体中文](unit.d8fab56bd46fe7b7_zh_cn.md)

Apply the current instruction and its included policy sections below. The current actions, guards, evidence and failure boundary are given directly. Before applying a named independent policy, obtain its exact instruction continuation; reuse any already held unit from this build and retain the affected action's return position. Do not retrieve author files or infer omitted policy. Check current facts and authorization before effects; an instruction is not a pass.

## Hard constraints

- Record hard user, runtime environment, repository, permission, safety, and Session constraints before acting.
- A task-level prohibition, such as “do not create subagents” or “do not use a browser,” remains active for the whole task.
- Computer Use is categorically forbidden: never control a computer, browser, or desktop app through its graphical interface — no screenshots to locate controls, mouse or keyboard simulation, clicking, accessibility APIs, window automation, remote-desktop control, or GUI scripting — and do not route such interaction through an API, CLI, MCP server, helper, or another Agent. Treat this as a blacklist rather than a list of allowed channels: every other tool, command, or capability actually exposed to and authorized for the current Session remains permitted. If a required step needs a forbidden operation, stop and report the blocker instead of attempting, delegating, or skipping it.
- Before route selection or any delegation/Session-topology work, the Mode checkpoint must compose and validate the delegation references; those references own conversation-level mode selection with a default Multi-Agent route and one-child budget, child counts, conditional creation, allocation, reuse, replacement, exceptions, and limits at their respective atomic boundaries. A reserved budget never initializes or authorizes a child by itself.
- Never invent authorization, capability, evidence, product support, or an executable route for an unmaintained scenario.
- Keep Core rules independent of product details; read Runtime and Model Provider Support (instruction continuation: [unit.081374cfbaa37b57](../instructions/unit.081374cfbaa37b57.md)) for supported runtime branches and model bindings.
- Read references on demand. Do not preload the entire Skill, `references/`, or raw project state merely because it may become useful.

# Session Audit Resolution


This checkpoint owns applying current Session audit preferences to the parent-controlled record and confirming the resulting values. It does not make audit visibility a permission or execution gate.

## Trigger and inputs

After the canonical parent-context record is available, consume it and current Session audit facts. Apply Session Audit Visibility (instruction continuation: [unit.6063588dfa2ee6c4](../instructions/unit.6063588dfa2ee6c4.md)) for field values and display semantics, and Delegation State Record (instruction continuation: [unit.04519b62e6c4f711](../instructions/unit.04519b62e6c4f711.md)) for record ownership and shape.

## Decision and result

Use valid explicit preferences already supplied by the user or retained in the current parent-controlled record. Otherwise apply the defaults immediately: Root `balanced/milestone_only`; Worker `full`. The user may explicitly change any preference, and the parent records the effective values and whether they were explicit or default. Do not ask a mandatory first-use question. Do not start a timer, wait for a reply, or migrate older prompt-state values.

If the available record contains obsolete prompt/timing or migration fields, ignore those fields and preserve valid preference values. Do not infer a preference from obsolete prompt status. If current explicit values conflict or are invalid, request clarification only for the affected preference when appropriate; if it cannot be resolved, use the policy default and report the limitation rather than blocking unrelated work.

Worker-log visibility remains an evidence description. When a task depends on access to the complete safe Worker conversation record, report `available`, `unverified`, or `unavailable` only from actual access evidence; no Worker means `Not applicable` with a reason. If that evidence is required and unavailable or unverified, block only the dependent audit judgment. A returned final body or tool discovery alone does not prove full log access.

## Failure boundary

Preference collection is optional and never grants authorization. Continue using effective defaults if no preference was supplied. Preserve required progress reports and confidentiality rules. Block only a judgment that depends on required but missing audit evidence; report unavailable preference or Worker-log evidence without treating it as proof of completion.
