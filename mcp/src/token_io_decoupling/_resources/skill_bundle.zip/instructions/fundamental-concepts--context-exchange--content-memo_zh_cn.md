# Worker Content Memo

[English](fundamental-concepts--context-exchange--content-memo.md) | [简体中文](fundamental-concepts--context-exchange--content-memo_zh_cn.md)

下列直接给出当前动作、守卫、证据和失败边界。应用独立政策前，先按明确的指令继续入口取得对应单元；同一构建中已持有的单元直接复用，并保留受影响动作的准确恢复位置。不读取作者文件或推测缺失政策。执行副作用前核实当前事实与授权；指令内容可用不表示检查通过。

## 硬约束

- 采取行动前记录用户、运行环境、仓库、权限、安全和 Session 硬约束。
- “不要创建子代理”“不要使用浏览器”等任务级禁止条件在整个任务中持续有效。
- 绝对禁止 Computer Use：不得通过图形界面控制计算机、浏览器或桌面应用——包括以操纵控件为目的的截图、鼠标／键盘模拟、点击、辅助功能 API、窗口自动化、远程桌面控制或 GUI 脚本——也不得把此类交互包装为 API、CLI、MCP Server、辅助程序或其他 Agent 调用来绕过。本节是黑名单而非允许渠道清单：当前 Session 实际暴露且已获授权的其他工具、命令或能力仍然允许。若必需步骤需要借助被禁止的操作，应停止并报告阻塞，而不是尝试、委派或跳过。
- 路线选择或任何委派/Session 拓扑工作前，模式检查点必须组合并验证委派 references；这些 references 在各自的原子边界内规定会话级模式选择及默认多代理路线和单个子代理预算、子代理数量、条件创建、分配、复用、替换、例外和限制。预留预算本身不会初始化或授权创建子代理。
- 不得虚构授权、能力、证据、产品支持，或为未维护场景推导可执行路线。
- Core 规则不依赖具体产品；受支持的运行环境分支和模型绑定见[运行环境与模型厂商支持](../instructions/fundamental-concepts--session-runtime--runtime-provider-support_zh_cn.md)。
- 按需读取 reference。不要仅因为可能以后有用，就预加载整个 Skill、`references/` 或原始项目状态。

# Worker Content Memo

## 通用规范

### 用途与内容

使用 Memory 名称 `context-exchange/workers/<worker-context-id>/content-memo`；Serena 在默认项目数据目录下将其映射为 `.serena/memories/context-exchange/workers/<worker-context-id>/content-memo.md`。Serena 配置可以更改该目录。名称只表示逻辑归属：Serena 不强制 Worker 级可见性、只读访问或文件系统隔离；拥有相关工具的 Session 可能看到或修改该 Memory。遵守已放行任务中的归属指令，不得声称存在技术隔离。

Worker 编写的 prose 使用中文。路径、文件名、命令、symbol、key、hash、准确错误和日志片段保留原文。只记录稳定且可复用的执行状态：完成结果、发现、变更路径/symbol、验证证据、失败方案、剩余工作、阻塞和 handoff 需求。保留指向权威来源的准确指针，不把来源全文作为权威副本存入 Memory。

### 禁止材料和能力不可用

不得写逐命令日志、完整日志/diff、大段源码副本、秘密、私有推理、完整 transcript、无关历史或父级实时 mode/count/allocation/epoch 状态。Serena Memory 读写不可用时，报告限制并阻塞依赖该记录的工作；不得回退到文件写入该记录。独立工作可以继续。

## Codex CLI / ChatGPT Desktop 特别优化指令

只使用当前 Session 实际暴露且获准的 Serena Memory 工具。Codex 本地 memories 和 `/compact` 不能代替具名 Serena Memory。确认写入成功；当前工作流要求时，使用 `read_memory` 核验存储条目。

## Claude Code CLI / Claude Desktop 特别优化指令

仅当当前 Session 暴露且授权相关 Serena MCP 工具时，才使用 Serena Memory。Claude auto memory 和 compaction 不能代替该具名项目 Memory。核实实际工具可用性和写入结果；不得假设 Serena Memory 已共享或隔离。
