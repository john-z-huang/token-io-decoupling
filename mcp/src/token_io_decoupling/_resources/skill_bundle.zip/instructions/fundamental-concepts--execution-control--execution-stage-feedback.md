# Coding Execution Stage Feedback

[English](fundamental-concepts--execution-control--execution-stage-feedback.md) | [简体中文](fundamental-concepts--execution-control--execution-stage-feedback_zh_cn.md)

Apply the current instruction and its included policy sections below. The current actions, guards, evidence and failure boundary are given directly. Before applying a named independent policy, obtain its exact instruction continuation; reuse any already held unit from this build and retain the affected action's return position. Do not retrieve author files or infer omitted policy. Check current facts and authorization before effects; an instruction is not a pass.

## Hard constraints

- Record hard user, runtime environment, repository, permission, safety, and Session constraints before acting.
- A task-level prohibition, such as “do not create subagents” or “do not use a browser,” remains active for the whole task.
- Computer Use is categorically forbidden: never control a computer, browser, or desktop app through its graphical interface — no screenshots to locate controls, mouse or keyboard simulation, clicking, accessibility APIs, window automation, remote-desktop control, or GUI scripting — and do not route such interaction through an API, CLI, MCP server, helper, or another Agent. Treat this as a blacklist rather than a list of allowed channels: every other tool, command, or capability actually exposed to and authorized for the current Session remains permitted. If a required step needs a forbidden operation, stop and report the blocker instead of attempting, delegating, or skipping it.
- Before route selection or any delegation/Session-topology work, the Mode checkpoint must compose and validate the delegation references; those references own conversation-level mode selection with a default Multi-Agent route and one-child budget, child counts, conditional creation, allocation, reuse, replacement, exceptions, and limits at their respective atomic boundaries. A reserved budget never initializes or authorizes a child by itself.
- Never invent authorization, capability, evidence, product support, or an executable route for an unmaintained scenario.
- Keep Core rules independent of product details; read [Runtime and Model Provider Support](../instructions/fundamental-concepts--session-runtime--runtime-provider-support.md) for supported runtime branches and model bindings.
- Read references on demand. Do not preload the entire Skill, `references/`, or raw project state merely because it may become useful.

# Coding Execution Stage Feedback

## General rules

### Bounded stages

For high-uncertainty work, predeclare a short sequence of evidence-producing stages. Each stage ends at an observation or decision boundary, not a command list.

### Progress Signals and stage feedback

At a declared stage boundary, return only the compressed progress signals needed for the next decision: material status, findings, changed scope, verification, issue, and need. Update the parent record by delta when evidence or status changes; do not repeat unchanged progress or rewrite stable state. Keep ordinary reads, local edits, formatter/lint fixes, straightforward test repairs, and repeated compile/test cycles inside the approved stage. Do not add checkpoints or execution slices merely to report low-value mechanics. Apply [session audit visibility](../instructions/fundamental-concepts--session-runtime--session-audit-visibility.md) summary cadence while retaining required stage feedback.

When stage evidence shows that the next stage depends on high-value judgment, route the signal to the Decision Gate. The Decision Gate owns solution selection and Contract updates; this module does not restate those policies.

### Shared-plan evidence for feedback

Apply [Task Plan Memory Lifecycle](../instructions/fundamental-concepts--execution-planning--task-plan-memory-lifecycle.md) when feedback uses shared-plan evidence: record material progress and sourced facts at its applicable phase, handoff, pause, or completion boundaries, through the authorized current record writer or released contribution path. Ordinary progress reports and checks or repairs within a phase do not independently trigger persistence or full readback. Record and analyze facts affecting authorization, scope, acceptance, direction, or dependent actions before those actions. Feedback carries the exact plan identity, persistence confirmation, and any owner-required verification evidence; it does not duplicate the full plan or change release authority. A missing required access, failed persistence, or failed required verification pauses the dependent boundary; only a documented persistence restriction permits the owner's exception.

## Codex CLI / ChatGPT Desktop optimizations

A configured Codex `PostToolUse` or `SubagentStop` hook can supply observed tool or child results for the parent's compressed Progress Signal, while `PreCompact` can mark a pending context-loss boundary. These optional events never prove semantic acceptance and must not trigger a full tool-log or transcript dump. [OpenAI: tool and lifecycle hooks](https://learn.chatgpt.com/docs/hooks).

An exposed Codex `/diff`, file/diff tool, `/agent`, or child-result tool can locate changed files, lines, and the producing Worker at a stage boundary. Return a compact Progress Signal with changed paths, actual checks, blocker and source pointers. When available, `/review` produces **review findings of a diff**, but only a truly separate authorized verifier context can satisfy any required independent-agent verification. [OpenAI: diff and review](https://learn.chatgpt.com/docs/code-review), [OpenAI: CLI commands](https://learn.chatgpt.com/docs/developer-commands), [OpenAI: subagent threads](https://learn.chatgpt.com/docs/agent-configuration/subagents).

## Claude Code CLI / Claude Desktop optimizations

### Hook-assisted compact stage evidence

For a persistent Claude Code child, `SubagentStop` exposes `last_assistant_message`, allowing the parent to consume a short stage result without replaying the child transcript. When a tool execution itself fails, `PostToolUseFailure` can expose its error information for the executor to report at the *existing* stage boundary; do not convert every failed command into a new high-value decision checkpoint. Neither event substitutes for explicit progress evidence, final verification, or the parent Control choice. Use native Hooks only where installed in the current Claude Code runtime, not in an unrelated Desktop Chat conversation.

Official reference: [SubagentStop and PostToolUseFailure event data](https://code.claude.com/docs/en/hooks).

A configured `PostToolUse` can provide actual tool outcomes at a stage boundary but cannot replace the compressed Progress Signal. A diff tool result is evidence of changed lines, not proof of tests or independent verification. [Anthropic: hooks](https://code.claude.com/docs/en/hooks).
