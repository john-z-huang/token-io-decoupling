# checkpoint.acceptance

[English](checkpoint.acceptance.md) | [简体中文](checkpoint.acceptance_zh_cn.md)

Apply the current instruction and its included policy sections below. The current actions, guards, evidence and failure boundary are given directly. Before applying a named independent policy, obtain its exact instruction continuation; reuse any already held unit from this build and retain the affected action's return position. Do not retrieve author files or infer omitted policy. Check current facts and authorization before effects; an instruction is not a pass.

## Hard constraints

- Record hard user, runtime environment, repository, permission, safety, and Session constraints before acting.
- A task-level prohibition, such as “do not create subagents” or “do not use a browser,” remains active for the whole task.
- Computer Use is categorically forbidden: never control a computer, browser, or desktop app through its graphical interface — no screenshots to locate controls, mouse or keyboard simulation, clicking, accessibility APIs, window automation, remote-desktop control, or GUI scripting — and do not route such interaction through an API, CLI, MCP server, helper, or another Agent. Treat this as a blacklist rather than a list of allowed channels: every other tool, command, or capability actually exposed to and authorized for the current Session remains permitted. If a required step needs a forbidden operation, stop and report the blocker instead of attempting, delegating, or skipping it.
- Before route selection or any delegation/Session-topology work, the Mode checkpoint must compose and validate the delegation references; those references own conversation-level mode selection with a default Multi-Agent route and one-child budget, child counts, conditional creation, allocation, reuse, replacement, exceptions, and limits at their respective atomic boundaries. A reserved budget never initializes or authorizes a child by itself.
- Never invent authorization, capability, evidence, product support, or an executable route for an unmaintained scenario.
- Keep Core rules independent of product details; read Runtime and Model Provider Support (instruction continuation: [unit.081374cfbaa37b57](../instructions/unit.081374cfbaa37b57.md)) for supported runtime branches and model bindings.
- Read references on demand. Do not preload the entire Skill, `references/`, or raw project state merely because it may become useful.

# Acceptance Checkpoint


## Actions

1. Map every Contract acceptance condition to the latest evidence for each applicable implementation/content, documentation, and Git metadata epoch.
2. Check that the changed paths, effects, and documentation stay within the approved scope.
3. Report implementation/content, documentation, and Git metadata status separately, and separate passed, failed, not-run, unavailable, assumed, and user-authorized items.
4. Record residual risks and any follow-up that requires new authority or a new Contract.
5. Do not use evidence from an older epoch as current evidence after a related change. Report `COMPLETE` only when every applicable latest epoch has current evidence and no required item, capability, verification boundary, or authorization remains unresolved.

## Pass condition

The final report maps every acceptance condition to current evidence from the applicable latest epochs, reports the three status dimensions separately, and is scope-accurate and explicit about limitations and authorized effects.

## Boundary

This checkpoint does not hide failures, convert assumptions into facts, or authorize new implementation, documentation, or Git work.
