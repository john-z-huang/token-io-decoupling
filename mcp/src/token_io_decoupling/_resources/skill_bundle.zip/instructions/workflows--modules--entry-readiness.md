# Entry Readiness Module

[English](workflows--modules--entry-readiness.md) | [简体中文](workflows--modules--entry-readiness_zh_cn.md)

Apply the current instruction and its included policy sections below. The current actions, guards, evidence and failure boundary are given directly. Before applying a named independent policy, obtain its exact instruction continuation; reuse any already held unit from this build and retain the affected action's return position. Do not retrieve author files or infer omitted policy. Check current facts and authorization before effects; an instruction is not a pass.

## Hard constraints

- Record hard user, runtime environment, repository, permission, safety, and Session constraints before acting.
- A task-level prohibition, such as “do not create subagents” or “do not use a browser,” remains active for the whole task.
- Computer Use is categorically forbidden: never control a computer, browser, or desktop app through its graphical interface — no screenshots to locate controls, mouse or keyboard simulation, clicking, accessibility APIs, window automation, remote-desktop control, or GUI scripting — and do not route such interaction through an API, CLI, MCP server, helper, or another Agent. Treat this as a blacklist rather than a list of allowed channels: every other tool, command, or capability actually exposed to and authorized for the current Session remains permitted. If a required step needs a forbidden operation, stop and report the blocker instead of attempting, delegating, or skipping it.
- Before route selection or any delegation/Session-topology work, the Mode checkpoint must compose and validate the delegation references; those references own conversation-level mode selection with a default Multi-Agent route and one-child budget, child counts, conditional creation, allocation, reuse, replacement, exceptions, and limits at their respective atomic boundaries. A reserved budget never initializes or authorizes a child by itself.
- Never invent authorization, capability, evidence, product support, or an executable route for an unmaintained scenario.
- Keep Core rules independent of product details; read [Runtime and Model Provider Support](../instructions/fundamental-concepts--session-runtime--runtime-provider-support.md) for supported runtime branches and model bindings.
- Read references on demand. Do not preload the entire Skill, `references/`, or raw project state merely because it may become useful.

# Entry Readiness Module


This Layer-04 module composes the current task Contract, Environment/capability, and released Mode evidence needed to establish route readiness. It consumes the existing Layer-01 through Layer-03 owners; it does not select a route, reinterpret Mode, or authorize implementation or child effects.

## Entry declaration

| Field | Requirement |
| --- | --- |
| Required inputs | The Coding selector's current `Contract`, `Environment`, capability inventory, and `Mode` pass evidence; [Route Entry](../instructions/workflow-checkpoints--route-entry.md) result naming the selected route; current task scope and known effect state. |
| Permitted effects | Read and qualify declared evidence; choose bounded navigation or an available generated instruction surface. Do not mutate workflow state, reopen Mode, or create/dispatch an Agent. |
| Results | `complete` with current Contract, Environment/capability, released Mode/count, selected-route evidence, and navigation result or justified `not_applicable`; otherwise `needs_prerequisite` or `blocked` with the suspended position. |
| Freshness | Confirm evidence against the current task/Session and its source/revision. Any material scope, Environment, capability, or Mode change requires the relevant owner to be rechecked before returning `complete`. |

## Workflow map


## Ordered module checklist

1. **ER00 — Resolve entry.** Call [Module Entry Resolution](../instructions/workflow-checkpoints--module-entry-resolution.md) with this declaration and the caller's current task, authorization, Session, evidence, and effect status. Consume the Coding selector's passed Contract/Environment/capability/Mode evidence and the [Route Entry](../instructions/workflow-checkpoints--route-entry.md) result naming the selected route; do not select or reselect it here. `ready` permits these checks only; map missing evidence to `needs_prerequisite` with this suspended position, and map a conflict or unsafe state to `blocked`. A direct caller may establish the continuation record; no top-level route is required.
2. **ER01 — Confirm Contract and common protocol.** Apply [Contract](../instructions/workflow-concepts--entry-and-context--contract.md): confirm the goal, hard user/runtime/repository/permission/safety constraints, authorized effects, settled decisions, open questions, and acceptance conditions. Apply [Shared Protocols](../instructions/references--share--shared-protocols.md) to keep one current Semantic Contract, distinguish facts from assumptions, carry later changes as bounded amendments, and stop dependent work if required context or a return path is unavailable. An unresolved question is not implementation authority. Confirm that the released Contract records task intent and eligible output classification from direct authoritative sources, as required by Contract action 5; this step only checks those Contract records.
3. **ER02 — Confirm Environment and instruction delivery.** Apply [Environment](../instructions/workflow-concepts--entry-and-context--environment.md) and [Environment Capability Inventory](../instructions/workflow-concepts--entry-and-context--environment-capability-inventory.md) to confirm current capabilities. Call [Workflow Navigation Selection](../instructions/workflow-checkpoints--workflow-navigation-selection.md). When optional navigation is unnecessary, record `Not applicable` and consume current delivered instructions directly. Otherwise review the complete current instruction text and explicit continuations; they do not establish identity, permission, state or checkpoint completion. An available, authorized same-build generated document-only surface may provide the unit when optional navigation is unavailable. Missing, incomplete or incompatible required instruction resources block dependent work; never use author-source fallback.
4. **ER03 — Confirm released Mode against the selected route.** Apply [Mode](../instructions/workflow-concepts--entry-and-context--mode.md), [Mode Confirmation](../instructions/fundamental-concepts--delegation--delegation-mode-confirmation.md), [Delegation Count Gate](../instructions/fundamental-concepts--delegation--delegation-mode-count-gate.md), [Delegation State Record](../instructions/fundamental-concepts--delegation--delegation-state-record.md), and [Mode Re-entry](../instructions/fundamental-concepts--delegation--delegation-mode-reentry.md). Verify the exact released mode and locked count/state; Single-Agent requires `child_count: 0` and no allocations. Multi-Agent requires a positive locked count and valid current allocations consistent with the record; occupied/created and unassigned slots are both valid states, so do not require every slot to remain unbound. Missing or stale release evidence returns `needs_prerequisite`; a mode/count that conflicts with the already selected route returns `blocked`. A later directive reuses locked topology. This confirms route eligibility only: it does not release a concrete Slice or authorize child creation. Return `complete` with current gate evidence.
