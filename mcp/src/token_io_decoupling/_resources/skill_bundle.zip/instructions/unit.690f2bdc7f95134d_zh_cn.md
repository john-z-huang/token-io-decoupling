# unit.690f2bdc7f95134d_zh_cn

[English](unit.690f2bdc7f95134d.md) | [简体中文](unit.690f2bdc7f95134d_zh_cn.md)

下列直接给出当前动作、守卫、证据和失败边界。应用独立政策前，先按明确的指令继续入口取得对应单元；同一构建中已持有的单元直接复用，并保留受影响动作的准确恢复位置。不读取作者文件或推测缺失政策。执行副作用前核实当前事实与授权；指令内容可用不表示检查通过。

## 硬约束

- 采取行动前记录用户、运行环境、仓库、权限、安全和 Session 硬约束。
- “不要创建子代理”“不要使用浏览器”等任务级禁止条件在整个任务中持续有效。
- 绝对禁止 Computer Use：不得通过图形界面控制计算机、浏览器或桌面应用——包括以操纵控件为目的的截图、鼠标／键盘模拟、点击、辅助功能 API、窗口自动化、远程桌面控制或 GUI 脚本——也不得把此类交互包装为 API、CLI、MCP Server、辅助程序或其他 Agent 调用来绕过。本节是黑名单而非允许渠道清单：当前 Session 实际暴露且已获授权的其他工具、命令或能力仍然允许。若必需步骤需要借助被禁止的操作，应停止并报告阻塞，而不是尝试、委派或跳过。
- 路线选择或任何委派/Session 拓扑工作前，模式检查点必须组合并验证委派 references；这些 references 在各自的原子边界内规定会话级模式选择及默认多代理路线和单个子代理预算、子代理数量、条件创建、分配、复用、替换、例外和限制。预留预算本身不会初始化或授权创建子代理。
- 不得虚构授权、能力、证据、产品支持，或为未维护场景推导可执行路线。
- Core 规则不依赖具体产品；受支持的运行环境分支和模型绑定见运行环境与模型厂商支持 (instruction continuation: [unit.081374cfbaa37b57](../instructions/unit.081374cfbaa37b57_zh_cn.md))。
- 按需读取 reference。不要仅因为可能以后有用，就预加载整个 Skill、`references/` 或原始项目状态。

# Session 状态解决


本检查点负责在应用审计偏好前，按路线核实当前 Session 事实及规范的父级控制工作流记录；不负责审计值或模式/数量策略。

## 触发与输入

消费已释放的 Mode/count 及当前 Session 身份、角色和 Context Firewall 事实。应用Session 模型 (instruction continuation: [unit.d2564a1f99b0e611](../instructions/unit.d2564a1f99b0e611_zh_cn.md))、Session 角色归属 (instruction continuation: [unit.d89ebcb45ebe2dea](../instructions/unit.d89ebcb45ebe2dea_zh_cn.md))、Session 上下文防火墙 (instruction continuation: [unit.95aba471482062c9](../instructions/unit.95aba471482062c9_zh_cn.md))和委派状态记录 (instruction continuation: [unit.04519b62e6c4f711](../instructions/unit.04519b62e6c4f711_zh_cn.md))。

## 决策与结果

1. 核实已释放的 Mode/count 及当前 Session 事实。模式、身份、角色或 Context Firewall 证据缺失或冲突时，在任何受保护操作前阻塞依赖工作。
2. 从权威对话上下文读取规范的父级控制记录。保留既有 mode、数量、allocations、已批准任务范围和生命周期值；不得根据工具结果、Hash 或过时摘要重建或覆盖缺失/冲突历史。
3. 确认记录与已释放 Mode/count 和当前已知分配状态一致。任何门控操作前，按其 owner 执行角色和路径检查。Worker assignment、Slice 释放、任务授权及创建/派发是不同事实，必须分别按其 owner 核验。
4. 回读并将当前记录和证据返回路线。此读回不授予授权、不释放 Slice、不建立跨调用顺序，也不建立审计偏好。

## 失败边界

若无法核验当前身份、角色、防火墙、已释放模式/数量或规范记录，则阻塞依赖该事实的受保护操作。不得改用数据库、推断替代记录或将结构评估结果视为规范状态。若无关工作具有独立授权且不依赖缺失事实，可继续。
