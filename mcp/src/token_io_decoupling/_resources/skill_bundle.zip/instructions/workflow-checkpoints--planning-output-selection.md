# Planning output selection

[English](workflow-checkpoints--planning-output-selection.md) | [简体中文](workflow-checkpoints--planning-output-selection_zh_cn.md)

Apply the current instruction and its included policy sections below. The current actions, guards, evidence and failure boundary are given directly. Before applying a named independent policy, obtain its exact instruction continuation; reuse any already held unit from this build and retain the affected action's return position. Do not retrieve author files or infer omitted policy. Check current facts and authorization before effects; an instruction is not a pass.

## Hard constraints

- Record hard user, runtime environment, repository, permission, safety, and Session constraints before acting.
- A task-level prohibition, such as “do not create subagents” or “do not use a browser,” remains active for the whole task.
- Computer Use is categorically forbidden: never control a computer, browser, or desktop app through its graphical interface — no screenshots to locate controls, mouse or keyboard simulation, clicking, accessibility APIs, window automation, remote-desktop control, or GUI scripting — and do not route such interaction through an API, CLI, MCP server, helper, or another Agent. Treat this as a blacklist rather than a list of allowed channels: every other tool, command, or capability actually exposed to and authorized for the current Session remains permitted. If a required step needs a forbidden operation, stop and report the blocker instead of attempting, delegating, or skipping it.
- Before route selection or any delegation/Session-topology work, the Mode checkpoint must compose and validate the delegation references; those references own conversation-level mode selection with a default Multi-Agent route and one-child budget, child counts, conditional creation, allocation, reuse, replacement, exceptions, and limits at their respective atomic boundaries. A reserved budget never initializes or authorizes a child by itself.
- Never invent authorization, capability, evidence, product support, or an executable route for an unmaintained scenario.
- Keep Core rules independent of product details; read [Runtime and Model Provider Support](../instructions/fundamental-concepts--session-runtime--runtime-provider-support.md) for supported runtime branches and model bindings.
- Read references on demand. Do not preload the entire Skill, `references/`, or raw project state merely because it may become useful.

# Planning output selection


This checkpoint determines the current task's default shared-plan output and its persistence/verification evidence under the lifecycle owner.

## Trigger and inputs

For every Coding task, consume the current user goal, Issue/discussion when present, verified project facts, Decision, and any explicit persistence restriction. Apply [Execution Planning](../instructions/fundamental-concepts--execution-planning--execution-planning.md) and [Task Plan Memory Lifecycle](../instructions/fundamental-concepts--execution-planning--task-plan-memory-lifecycle.md).

## Decision and result

1. Preserve the task goal, sources, current facts and proposed solution. With or without an Issue, select a shared plan by default; lack of an explicit planning request is not a skip condition.
2. Confirm the exact project, selected repository storage scope, paired active/archive namespaces, active plan identity, allowed contributions and required access. For shared storage, verify that workspaces of one repository reuse the same plan mapping and other repositories remain separate. Missing or conflicting identity/mapping blocks without silent scope fallback. Create or update the concise plan, confirm the authorized persistence operation, and perform content verification only when the lifecycle owner requires it. Return its identity, storage mapping, persistence confirmation, and any required verification evidence to the caller.
3. Only an explicit user prohibition or higher-priority persistence restriction permits `Not applicable`, with the exact restriction, source and authorized in-context planning alternative. A conflicting explicit requirement to persist blocks; missing tools, unknown permission, or failed persistence are not skip conditions.
4. Record material updates at the lifecycle owner's applicable phase, handoff, pause, or completion boundaries. Record and analyze changes affecting authorization, scope, acceptance, direction, or dependent actions before those actions. Ordinary progress reports do not independently trigger a plan write. Archive remains conditional on completed Acceptance.

## Failure boundary

Unavailable required access, failed persistence, or failed owner-required verification blocks dependent work. Bounded content evidence covers only its inspected window and does not replace owner-required complete-content checks. This selection does not authorize implementation, change the user's goal, or weaken naming, update coordination, role boundaries, archive or immutability rules.
