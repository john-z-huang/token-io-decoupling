# fundamental-concepts / delegation / delegation-mode-confirmation / section-session-mode-selection_zh_cn

[English](fundamental-concepts--delegation--delegation-mode-confirmation--section-session-mode-selection.md) | [简体中文](fundamental-concepts--delegation--delegation-mode-confirmation--section-session-mode-selection_zh_cn.md)

下列直接给出当前动作、守卫、证据和失败边界。应用独立政策前，先按明确的指令继续入口取得对应单元；同一构建中已持有的单元直接复用，并保留受影响动作的准确恢复位置。不读取作者文件或推测缺失政策。执行副作用前核实当前事实与授权；指令内容可用不表示检查通过。

## 硬约束

- 采取行动前记录用户、运行环境、仓库、权限、安全和 Session 硬约束。
- “不要创建子代理”“不要使用浏览器”等任务级禁止条件在整个任务中持续有效。
- 绝对禁止 Computer Use：不得通过图形界面控制计算机、浏览器或桌面应用——包括以操纵控件为目的的截图、鼠标／键盘模拟、点击、辅助功能 API、窗口自动化、远程桌面控制或 GUI 脚本——也不得把此类交互包装为 API、CLI、MCP Server、辅助程序或其他 Agent 调用来绕过。本节是黑名单而非允许渠道清单：当前 Session 实际暴露且已获授权的其他工具、命令或能力仍然允许。若必需步骤需要借助被禁止的操作，应停止并报告阻塞，而不是尝试、委派或跳过。
- 路线选择或任何委派/Session 拓扑工作前，模式检查点必须组合并验证委派 references；这些 references 在各自的原子边界内规定会话级模式选择及默认多代理路线和单个子代理预算、子代理数量、条件创建、分配、复用、替换、例外和限制。预留预算本身不会初始化或授权创建子代理。
- 不得虚构授权、能力、证据、产品支持，或为未维护场景推导可执行路线。
- Core 规则不依赖具体产品；受支持的运行环境分支和模型绑定见[运行环境与模型厂商支持](../instructions/fundamental-concepts--session-runtime--runtime-provider-support_zh_cn.md)。
- 按需读取 reference。不要仅因为可能以后有用，就预加载整个 Skill、`references/` 或原始项目状态。

### 会话模式选择

宿主识别的 Session 生命周期中，第一次 Coding 指令到达后，根父级必须：

1. 直接遵循指令中明确给出的有效模式/数量选择，不再询问。
2. 若没有有效选择，呈现以下编号菜单。只有必须放行 Mode gate 且仍没有有效用户选择时，才采用所示缺省值；仅仅尚未收到对提问的回复，并不要求放行门禁。用户明确表示无偏好时也选择缺省值：
   1. Multi-Agent Coding，1 个子代理（推荐且缺省）。
   2. Single-Agent Coding，0 个子代理。
   3. Multi-Agent Coding，自定义正整数子代理数（通过自由文本填写整数）。
   4. 自定义指令（通过自由文本填写完整指令，并映射到受维护的模式和有效数量）。
3. 选项 3 必须提供明确正整数。若缺失或无效，只提出一个聚焦的补充问题，并保持 Mode gate 未放行；不得替换为 1。选项 4 的文本只用于推导受维护的 Single-Agent 或 Multi-Agent 路线及有效数量，同时记录其他任务约束。若文本缺失、无效、有歧义、冲突或要求未维护的路线，提出一个聚焦澄清并保持门禁未放行。自定义文本不得覆盖更高优先级的权限、安全、仓库、用户授权或能力边界，也不能创建路线或能力。
4. 将有效用户选择记录为 `mode_source: explicit`。将无回复或明确无偏好时的缺省选择记录为 `mode_source: default`、`mode: Multi-Agent Coding`、`child_count: 1`。路线放行前应用数量 owner。模式在完整宿主 Session 生命周期内固定，而非只对一次用户/助手交互生效。后续指令、compact 和同一 Session 的恢复均沿用它。初始数量也保持固定，唯一例外是数量门禁在用户实际明确批准为不同且未占用职责增加一个名额后，恰好增加一。该流程不重新打开模式选择。具有新 Session 身份的 Fork 必须按 Re-entry owner 重新完成模式/数量选择，不继承来源 Session 的选择。
5. 将已放行的 Multi-Agent 数量视为仅预留容量。展示菜单、选择模式或锁定数量均不会创建或初始化子代理；创建仍受职责、输出类型和已放行切片门禁约束。

默认值只选择工作模式和预留数量，不绕过任务级禁止事项，也不创造能力。更高优先级规则禁止子代理时，必须遵循该规则。缺少所需记录能力时，阻塞依赖路线，不得假装记录存在。

只有数量门禁放行有效正整数数量、相关职责和具体切片均已放行，且输出属于代码/配置实现或本 Skill 指令/参考文档的编写编辑时，才可创建子代理。普通非 Skill 文档由根父级编写，即使任务同时包含代码修改也一样。如果本次会话已经锁定为单代理 Coding，遇到冲突的后续指令时先遵循模式重新进入 owner。
