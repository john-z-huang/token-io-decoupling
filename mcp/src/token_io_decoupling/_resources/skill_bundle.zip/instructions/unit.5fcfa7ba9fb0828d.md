# unit.5fcfa7ba9fb0828d

[English](unit.5fcfa7ba9fb0828d.md) | [简体中文](unit.5fcfa7ba9fb0828d_zh_cn.md)

Apply the current instruction and its included policy sections below. The current actions, guards, evidence and failure boundary are given directly. Before applying a named independent policy, obtain its exact instruction continuation; reuse any already held unit from this build and retain the affected action's return position. Do not retrieve author files or infer omitted policy. Check current facts and authorization before effects; an instruction is not a pass.

## Hard constraints

- Record hard user, runtime environment, repository, permission, safety, and Session constraints before acting.
- A task-level prohibition, such as “do not create subagents” or “do not use a browser,” remains active for the whole task.
- Computer Use is categorically forbidden: never control a computer, browser, or desktop app through its graphical interface — no screenshots to locate controls, mouse or keyboard simulation, clicking, accessibility APIs, window automation, remote-desktop control, or GUI scripting — and do not route such interaction through an API, CLI, MCP server, helper, or another Agent. Treat this as a blacklist rather than a list of allowed channels: every other tool, command, or capability actually exposed to and authorized for the current Session remains permitted. If a required step needs a forbidden operation, stop and report the blocker instead of attempting, delegating, or skipping it.
- Before route selection or any delegation/Session-topology work, the Mode checkpoint must compose and validate the delegation references; those references own conversation-level mode selection with a default Multi-Agent route and one-child budget, child counts, conditional creation, allocation, reuse, replacement, exceptions, and limits at their respective atomic boundaries. A reserved budget never initializes or authorizes a child by itself.
- Never invent authorization, capability, evidence, product support, or an executable route for an unmaintained scenario.
- Keep Core rules independent of product details; read Runtime and Model Provider Support (instruction continuation: [unit.081374cfbaa37b57](../instructions/unit.081374cfbaa37b57.md)) for supported runtime branches and model bindings.
- Read references on demand. Do not preload the entire Skill, `references/`, or raw project state merely because it may become useful.

# Coding Child Message Visibility

## General rules

### Configured display; complete body before reliance

Apply the configured session audit visibility (instruction continuation: [unit.6063588dfa2ee6c4](../instructions/unit.6063588dfa2ee6c4.md)) preset. The Worker must keep the complete safe inbound and outbound bodies visible in its own conversation. For Root messages, show the configured preview, summary, or full body; when full display is required, show the complete safe body before sending and confirm it exactly matches the payload. A Worker final result already visible in full is its outbound copy and must not be duplicated.

After a message arrives, Root must obtain and read the complete actual returned body before relying on it. Root displays the full safe body or configured summary in the primary conversation according to the preset. Tool-call cards, activity events, delivery receipts, task status, or notices such as “message sent” are not the message body and cannot replace it.

When full display is required by role or preset, a long body may be displayed in consecutively numbered parts without summarizing or truncating it; clearly mark any redactions. If the actual body is not exposed and cannot be reproduced from the conversation record, do not use the message for dependent work.

### Preserve direction and evidence

Identify each message's direction and, when the runtime exposes identity, its intended or source child. Keep the body distinguishable from commentary. A paraphrase, summary, or claim that content was sent or received is not evidence of the message body.

## Codex CLI / ChatGPT Desktop optimizations

### Use the message tool exposed to the current Session

When `collaboration.send_message` is exposed and authorized, apply the configured preset. A Worker keeps complete safe inbound and outbound bodies visible; a full Root outbound display must match the payload. Root always reads the complete actual return before reliance, while its visible copy follows the preset. If the actual body cannot be reproduced from the conversation record, block dependent work. A visible copy is not proof of original transport bytes.

## Claude Code CLI / Claude Desktop optimizations

### Use the exposed SendMessage tool

Anthropic's [Agent Teams documentation](https://code.claude.com/docs/en/agent-teams) describes `SendMessage` as the tool for sending messages between agents. When the current Session exposes and authorizes it, follow the general configured preset. A Worker retains complete safe inbound and outbound visibility; Root reads the full actual return before reliance, with display governed by the preset. A visible copy does not prove original transport bytes. If `SendMessage` is unavailable, do not assume it exists; the general evidence requirement still applies.
