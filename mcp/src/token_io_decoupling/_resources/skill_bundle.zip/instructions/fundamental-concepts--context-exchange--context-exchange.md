# Coding Context Exchange

[English](fundamental-concepts--context-exchange--context-exchange.md) | [简体中文](fundamental-concepts--context-exchange--context-exchange_zh_cn.md)

Apply the current instruction and its included policy sections below. The current actions, guards, evidence and failure boundary are given directly. Before applying a named independent policy, obtain its exact instruction continuation; reuse any already held unit from this build and retain the affected action's return position. Do not retrieve author files or infer omitted policy. Check current facts and authorization before effects; an instruction is not a pass.

## Hard constraints

- Record hard user, runtime environment, repository, permission, safety, and Session constraints before acting.
- A task-level prohibition, such as “do not create subagents” or “do not use a browser,” remains active for the whole task.
- Computer Use is categorically forbidden: never control a computer, browser, or desktop app through its graphical interface — no screenshots to locate controls, mouse or keyboard simulation, clicking, accessibility APIs, window automation, remote-desktop control, or GUI scripting — and do not route such interaction through an API, CLI, MCP server, helper, or another Agent. Treat this as a blacklist rather than a list of allowed channels: every other tool, command, or capability actually exposed to and authorized for the current Session remains permitted. If a required step needs a forbidden operation, stop and report the blocker instead of attempting, delegating, or skipping it.
- Before route selection or any delegation/Session-topology work, the Mode checkpoint must compose and validate the delegation references; those references own conversation-level mode selection with a default Multi-Agent route and one-child budget, child counts, conditional creation, allocation, reuse, replacement, exceptions, and limits at their respective atomic boundaries. A reserved budget never initializes or authorizes a child by itself.
- Never invent authorization, capability, evidence, product support, or an executable route for an unmaintained scenario.
- Keep Core rules independent of product details; read [Runtime and Model Provider Support](../instructions/fundamental-concepts--session-runtime--runtime-provider-support.md) for supported runtime branches and model bindings.
- Read references on demand. Do not preload the entire Skill, `references/`, or raw project state merely because it may become useful.

# Coding Context Exchange

## General rules

### Capsule content and authoritative sources

Persist a capsule only when an authorized handoff or context bootstrap needs a durable record. Use concise neutral facts, exact pointers to authoritative sources, hashes, freshness/invalidation data, and narrow evidence pointers. Do not copy the full source documents into Memory; authoritative repository files remain binding. Receiving Workers read only capsule memories named in their released task, then verify needed facts against named approved sources.

Use these bootstrap Memory names, preserving former filenames: `context-exchange/context-bootstrap/MANIFEST`, `context-exchange/context-bootstrap/project-context`, and `context-exchange/context-bootstrap/policy-context`. `MANIFEST` records snapshot identity, hashes, and freshness rules; the other memories hold neutral project facts/pointers and policy-routing pointers. Other exchange/import records use their existing basename and subdirectory intent under `context-exchange/`.

Check freshness against `HEAD`/tree, tracked-delta fingerprint, listed source hashes, relevant untracked state, and active task/scope. Refresh only affected entries when material fields change; otherwise read named authoritative sources directly. A capsule never replaces Contract or independent final-state verification. Memory listing/read/write capability unavailable means report the limitation and block dependent work; do not use file-backed fallback.

## Codex CLI / ChatGPT Desktop optimizations

Use only exposed, authorized Serena Memory tools. Name the exact capsule Memory in the released task, read it before use, verify source pointers/freshness, and confirm writes. Do not broaden source or tool access just to make a capsule available.

## Claude Code CLI / Claude Desktop optimizations

Use Serena Memory only when the current Agent Session exposes and authorizes its MCP tools. Claude Code MCP Tool Search may defer definitions; discover and verify the tools before relying on them. Claude auto memory or compaction is not a replacement for a named exchange capsule.
