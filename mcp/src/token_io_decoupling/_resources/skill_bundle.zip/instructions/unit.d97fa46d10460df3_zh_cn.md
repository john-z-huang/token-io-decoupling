# unit.d97fa46d10460df3_zh_cn

[English](unit.d97fa46d10460df3.md) | [简体中文](unit.d97fa46d10460df3_zh_cn.md)

下列直接给出当前动作、守卫、证据和失败边界。应用独立政策前，先按明确的指令继续入口取得对应单元；同一构建中已持有的单元直接复用，并保留受影响动作的准确恢复位置。不读取作者文件或推测缺失政策。执行副作用前核实当前事实与授权；指令内容可用不表示检查通过。

## 硬约束

- 采取行动前记录用户、运行环境、仓库、权限、安全和 Session 硬约束。
- “不要创建子代理”“不要使用浏览器”等任务级禁止条件在整个任务中持续有效。
- 绝对禁止 Computer Use：不得通过图形界面控制计算机、浏览器或桌面应用——包括以操纵控件为目的的截图、鼠标／键盘模拟、点击、辅助功能 API、窗口自动化、远程桌面控制或 GUI 脚本——也不得把此类交互包装为 API、CLI、MCP Server、辅助程序或其他 Agent 调用来绕过。本节是黑名单而非允许渠道清单：当前 Session 实际暴露且已获授权的其他工具、命令或能力仍然允许。若必需步骤需要借助被禁止的操作，应停止并报告阻塞，而不是尝试、委派或跳过。
- 路线选择或任何委派/Session 拓扑工作前，模式检查点必须组合并验证委派 references；这些 references 在各自的原子边界内规定会话级模式选择及默认多代理路线和单个子代理预算、子代理数量、条件创建、分配、复用、替换、例外和限制。预留预算本身不会初始化或授权创建子代理。
- 不得虚构授权、能力、证据、产品支持，或为未维护场景推导可执行路线。
- Core 规则不依赖具体产品；受支持的运行环境分支和模型绑定见运行环境与模型厂商支持 (instruction continuation: [unit.081374cfbaa37b57](../instructions/unit.081374cfbaa37b57_zh_cn.md))。
- 按需读取 reference。不要仅因为可能以后有用，就预加载整个 Skill、`references/` 或原始项目状态。

# Coding Agent 推理摘要可见性

## 通用规范

### 摘要边界与内容

“已完成的 Agent 推理回合”指 Agent 即将向用户或父级返回、暂停、让出控制或交接工作的可见会话边界。同一回合内的内部工具调用及继续处理无需逐项输出摘要。

在此类边界按会话审计可见性 (instruction continuation: [unit.6063588dfa2ee6c4](../instructions/unit.6063588dfa2ee6c4_zh_cn.md))配置的频率执行。`full` 在每个已完成边界使用下文格式；`milestone_only` 仅在实质决策、授权变化、验证失败、阻塞和阶段验收时使用，普通无变化等待和机械步骤不重复生成摘要块；`off` 不输出此可选摘要。必需的 Progress Signal、证据、控制增量、验证报告和更高层周期更新仍须执行。

### 固定可见格式

摘要必须使用以下精确 ASCII 标记包围，并让每个标记各自独占一行：`[[REASONING_SUMMARY_BEGIN]]` 和 `[[REASONING_SUMMARY_END]]`。普通答复、状态说明及其他非摘要内容均放在标记之外；不得在标记外输出未标记的推理摘要。使用会话语言，并按固定顺序完整填写以下字段：结论/进展；关键证据及来源；简短依据；重要假设/不确定性/阻塞；下一步。

需要输出摘要且没有实质变化时，仍保留两个标记及所有字段。写明“无实质变化”、无新增证据、决定或假设，并给出下一步；不得输出空块。推理回合尚未结束时，不输出空标记块。

英文示例：

```text
[[REASONING_SUMMARY_BEGIN]]
Conclusion / progress: No material change.
Key evidence and source: No new evidence.
Brief rationale: No new decision.
Material assumptions / uncertainty / blockers: No new assumptions or blockers.
Next step: Continue the released task.
[[REASONING_SUMMARY_END]]
```

简体中文示例：

```text
[[REASONING_SUMMARY_BEGIN]]
结论/进展：无实质变化。
关键证据及来源：无新增证据。
简短依据：无新增决定。
重要假设/不确定性/阻塞：无新增假设或阻塞。
下一步：继续已放行的任务。
[[REASONING_SUMMARY_END]]
```

标记只标识安全摘要，不允许输出私有逐步内部推理、隐藏思维链或原始 scratchpad。

不得包含私有逐步内部推理、隐藏思维链、原始 scratchpad、穷尽式内部过程、秘密或未核实断言。不得将摘要描述为完整的内部推理记录。

### 与其他证据的关系

摘要不能替代 Decision Brief、声明的阶段边界所需的 Progress Signal、验证证据或消息正文证据。推理回合结束与阶段边界重合时，将两者所需信息合并为一个简洁可见摘要，避免重复。Worker 已在自身会话完整可见的最终结果就是出站副本，不重复打印。Root 仍须完整读取实际返回正文后再依赖；Root 的可见副本遵循配置的消息预设。必需证据不可用时，报告限制并阻塞依赖动作。

## Codex CLI / ChatGPT Desktop 特别优化指令

应用会话审计可见性 (instruction continuation: [unit.6063588dfa2ee6c4](../instructions/unit.6063588dfa2ee6c4_zh_cn.md))中的 Root 或 Worker 配置频率。该 Skill 设置不是产品原生参数，也不允许披露私有推理。

## Claude Code CLI / Claude Desktop 特别优化指令

目前没有厂商专用优化；仅使用当前 Session 可见的会话输出遵循上述通用规范。
