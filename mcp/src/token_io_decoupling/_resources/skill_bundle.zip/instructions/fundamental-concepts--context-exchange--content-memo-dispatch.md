# Worker Content Memo Dispatch

[English](fundamental-concepts--context-exchange--content-memo-dispatch.md) | [简体中文](fundamental-concepts--context-exchange--content-memo-dispatch_zh_cn.md)

Apply the current instruction and its included policy sections below. The current actions, guards, evidence and failure boundary are given directly. Before applying a named independent policy, obtain its exact instruction continuation; reuse any already held unit from this build and retain the affected action's return position. Do not retrieve author files or infer omitted policy. Check current facts and authorization before effects; an instruction is not a pass.

## Hard constraints

- Record hard user, runtime environment, repository, permission, safety, and Session constraints before acting.
- A task-level prohibition, such as “do not create subagents” or “do not use a browser,” remains active for the whole task.
- Computer Use is categorically forbidden: never control a computer, browser, or desktop app through its graphical interface — no screenshots to locate controls, mouse or keyboard simulation, clicking, accessibility APIs, window automation, remote-desktop control, or GUI scripting — and do not route such interaction through an API, CLI, MCP server, helper, or another Agent. Treat this as a blacklist rather than a list of allowed channels: every other tool, command, or capability actually exposed to and authorized for the current Session remains permitted. If a required step needs a forbidden operation, stop and report the blocker instead of attempting, delegating, or skipping it.
- Before route selection or any delegation/Session-topology work, the Mode checkpoint must compose and validate the delegation references; those references own conversation-level mode selection with a default Multi-Agent route and one-child budget, child counts, conditional creation, allocation, reuse, replacement, exceptions, and limits at their respective atomic boundaries. A reserved budget never initializes or authorizes a child by itself.
- Never invent authorization, capability, evidence, product support, or an executable route for an unmaintained scenario.
- Keep Core rules independent of product details; read [Runtime and Model Provider Support](../instructions/fundamental-concepts--session-runtime--runtime-provider-support.md) for supported runtime branches and model bindings.
- Read references on demand. Do not preload the entire Skill, `references/`, or raw project state merely because it may become useful.

# Worker Content Memo Dispatch

## General rules

### Dispatch switch

Every released bundle explicitly includes `write_content_memo: true` or `false`; a Worker never infers a default. `true` enables writes to `context-exchange/workers/<worker-context-id>/content-memo`; `false` disables that memo only. Include the exact memory name in the released bundle. The parent controls the switch and name, but this is logical ownership only: Serena does not enforce per-Worker access or read-only ACLs.

If Memory tools are not exposed and authorized, report the limitation and block the memo-dependent slice; do not materialize the memo as a file. Other independent work may continue.

## Codex CLI / ChatGPT Desktop optimizations

Serialize the switch and exact memory name in the actual released child-task prompt. Use only exposed, authorized Serena Memory tools and confirm the write result. Codex configuration, hooks, local memory, or compaction do not themselves implement this switch.

## Claude Code CLI / Claude Desktop optimizations

When the current Agent Session exposes and authorizes Serena MCP Memory tools, include the switch and name in the released bundle and confirm the write result. Claude auto memory, hooks, or compaction do not replace the named project Memory. If tools are unavailable, follow the general block/report rule.
