# unit.95aba471482062c9_zh_cn

[English](unit.95aba471482062c9.md) | [简体中文](unit.95aba471482062c9_zh_cn.md)

下列直接给出当前动作、守卫、证据和失败边界。应用独立政策前，先按明确的指令继续入口取得对应单元；同一构建中已持有的单元直接复用，并保留受影响动作的准确恢复位置。不读取作者文件或推测缺失政策。执行副作用前核实当前事实与授权；指令内容可用不表示检查通过。

## 硬约束

- 采取行动前记录用户、运行环境、仓库、权限、安全和 Session 硬约束。
- “不要创建子代理”“不要使用浏览器”等任务级禁止条件在整个任务中持续有效。
- 绝对禁止 Computer Use：不得通过图形界面控制计算机、浏览器或桌面应用——包括以操纵控件为目的的截图、鼠标／键盘模拟、点击、辅助功能 API、窗口自动化、远程桌面控制或 GUI 脚本——也不得把此类交互包装为 API、CLI、MCP Server、辅助程序或其他 Agent 调用来绕过。本节是黑名单而非允许渠道清单：当前 Session 实际暴露且已获授权的其他工具、命令或能力仍然允许。若必需步骤需要借助被禁止的操作，应停止并报告阻塞，而不是尝试、委派或跳过。
- 路线选择或任何委派/Session 拓扑工作前，模式检查点必须组合并验证委派 references；这些 references 在各自的原子边界内规定会话级模式选择及默认多代理路线和单个子代理预算、子代理数量、条件创建、分配、复用、替换、例外和限制。预留预算本身不会初始化或授权创建子代理。
- 不得虚构授权、能力、证据、产品支持，或为未维护场景推导可执行路线。
- Core 规则不依赖具体产品；受支持的运行环境分支和模型绑定见运行环境与模型厂商支持 (instruction continuation: [unit.081374cfbaa37b57](../instructions/unit.081374cfbaa37b57_zh_cn.md))。
- 按需读取 reference。不要仅因为可能以后有用，就预加载整个 Skill、`references/` 或原始项目状态。

# Coding Session Context Firewall

## 通用规范

### 原始状态进入

在多 Session Coding 中，输入侧 Session 按职责归属 (instruction continuation: [unit.d89ebcb45ebe2dea](../instructions/unit.d89ebcb45ebe2dea_zh_cn.md))要求读取派发前确认所需的有界、只读环境与代码证据，不进行开放式项目扫描。Primary Output 仅在父级确认和放行的范围内读取更多源代码/配置状态；Change Verification 消费最终状态证据；Documentation/Comments & Git Operations 消费 Git 状态和获准文档范围。各自只返回下一步决策需要的事实与准确来源。

原始状态摄入边界由潜在输出体积、状态敏感性和仓库影响决定，而不是命令名称。单 Session 没有跨 Session Firewall，但仍须渐进读取并压缩原始状态。

### 语义 ownership 和临时定位

Firewall 只限制原始状态进入，不转移语义责任；语义权威性遵循职责归属 (instruction continuation: [unit.d89ebcb45ebe2dea](../instructions/unit.d89ebcb45ebe2dea_zh_cn.md))。临时项目定位事实不自动提升为长期 Contract 状态，也不应倾倒原始状态。经授权且可复用的上下文记录可按 Coding Context Exchange (instruction continuation: [unit.439bedbb36334cd3](../instructions/unit.439bedbb36334cd3_zh_cn.md)) 和 Coding Context Exchange Workspace Boundary (instruction continuation: [unit.0a54c601ab09a7e6](../instructions/unit.0a54c601ab09a7e6_zh_cn.md)) 使用具名项目 Memory 持久化；Memory 名称只表达逻辑归属，不提供技术隔离。

## Codex CLI / ChatGPT Desktop 特别优化指令

Codex 的自定义 Agent profile 可以用只读 `sandbox_mode` 和指定 `mcp_servers` 收窄源码及工具访问范围；`developer_instructions` 可以要求有界来源指针，但不是权限边界。必须检查继承设置，因为自定义 Agent 中省略的字段可继承父级。这些设置不等同于 Claude 的 `tools`／`disallowedTools` frontmatter，也不代表 Claude Desktop Chat 的 connector Tool-access 模式。[OpenAI：自定义子代理](https://learn.chatgpt.com/docs/agent-configuration/subagents)。

### 有界本地工具与 Skill／MCP 按需披露

不要重复读取未变更的 owner，也不要重新取回当前上下文中已经存在的历史。优先保留稳定上下文并追加小幅 delta。工具输出同时在 `content` 和 `structuredContent` 中重复同一载荷时，只保留下一步决策所需的一种表示；不同证据和来源指针仍须保留。

使用运行环境实际暴露的本地代码检索／文件读取工具定位符号和少量源代码区间，返回稳定路径与证据指针，而非完整构建日志或仓库递归列表。Codex 自定义 Agent 可以通过经审查的 `sandbox_mode: read-only` 和窄范围 `mcp_servers` 限定职责访问；省略的字段可能继承父级设置，父级实时权限覆盖还可能影响创建后的 Child。本地 Codex Skill 先暴露元数据，选中后才加载 `SKILL.md`，references 则按需读取；只选择当前 Slice 所需的概念 owner。CLI／IDE／Desktop Codex 宿主可共享 MCP 配置，通过 `/mcp` 核实连接；不能把插件或独立 Chat Session 的工具访问当成额外 Codex Child 或权限授权。[OpenAI：Skills 渐进式披露](https://learn.chatgpt.com/docs/build-skills)、[OpenAI：MCP 宿主配置](https://learn.chatgpt.com/docs/extend/mcp)、[OpenAI：自定义 Agent](https://learn.chatgpt.com/docs/agent-configuration/subagents)。

## Claude Code CLI / Claude Desktop 特别优化指令

### 原生有界读取与 MCP 按需发现

本地 Claude Code 中，仓库定位优先使用定向的 `Glob`/`Grep` 与少量 `Read` 范围，然后只向父级返回路径、行号来源和压缩事实；不得把完整递归目录或构建日志灌入父级。MCP Tool Search 默认启用：Claude Code 延迟加载 MCP 工具定义，并在需要时发现工具。如果 `ANTHROPIC_BASE_URL` 指向非 Anthropic 官方主机，Claude Code 通常会禁用 Tool Search，因为多数代理不会转发 `tool_reference` 数据块；只有模型与代理均支持这些数据块时，才在启动新 Session 时使用 `ENABLE_TOOL_SEARCH=true claude` 覆盖该回退行为。Azure 上托管的 Microsoft Foundry 部署会在服务端拒绝 Tool Search，因此环境会强制预先加载，不能用该变量覆盖。`CLAUDE_CODE_DISABLE_EXPERIMENTAL_BETAS` 也会令 Tool Search 保持关闭，且不能由 `ENABLE_TOOL_SEARCH` 覆盖。Tool Search 不可用时，应预期 MCP 工具会预先加载，不要声称实现了延迟加载节省。Desktop Chat 可通过获准的桌面扩展/本地 MCP Server 访问本机资源；远程连接器访问远端服务；两者均须核对具体工具权限，不推断本地 shell、无限制文件系统或独立 Agent。

官方依据：[Claude Code MCP Tool Search](https://code.claude.com/docs/en/mcp)、[Desktop 连接器边界](https://support.claude.com/en/articles/11725091-when-to-use-desktop-and-web-connectors)、[本地 MCP 扩展](https://support.claude.com/en/articles/10949351-getting-started-with-local-mcp-servers-on-claude-desktop)。

Claude Code 的项目／用户自定义 subagent 可将内联 `mcpServers` 限于子代理，避免无关工具说明占用父级上下文；插件附带的 Agent 定义不一定遵循此字段。检查 Desktop Agent Session 直接暴露的 MCP 工具，只使用已放行 Slice 确需且获授权的工具。[Anthropic：子代理 MCP 范围](https://code.claude.com/docs/en/sub-agents)。
