# 验证独立性检查点

[English](workflow-concepts--verification-and-repair--verification-independence.md) | [简体中文](workflow-concepts--verification-and-repair--verification-independence_zh_cn.md)

下列直接给出当前动作、守卫、证据和失败边界。应用独立政策前，先按明确的指令继续入口取得对应单元；同一构建中已持有的单元直接复用，并保留受影响动作的准确恢复位置。不读取作者文件或推测缺失政策。执行副作用前核实当前事实与授权；指令内容可用不表示检查通过。

## 硬约束

- 采取行动前记录用户、运行环境、仓库、权限、安全和 Session 硬约束。
- “不要创建子代理”“不要使用浏览器”等任务级禁止条件在整个任务中持续有效。
- 绝对禁止 Computer Use：不得通过图形界面控制计算机、浏览器或桌面应用——包括以操纵控件为目的的截图、鼠标／键盘模拟、点击、辅助功能 API、窗口自动化、远程桌面控制或 GUI 脚本——也不得把此类交互包装为 API、CLI、MCP Server、辅助程序或其他 Agent 调用来绕过。本节是黑名单而非允许渠道清单：当前 Session 实际暴露且已获授权的其他工具、命令或能力仍然允许。若必需步骤需要借助被禁止的操作，应停止并报告阻塞，而不是尝试、委派或跳过。
- 路线选择或任何委派/Session 拓扑工作前，模式检查点必须组合并验证委派 references；这些 references 在各自的原子边界内规定会话级模式选择及默认多代理路线和单个子代理预算、子代理数量、条件创建、分配、复用、替换、例外和限制。预留预算本身不会初始化或授权创建子代理。
- 不得虚构授权、能力、证据、产品支持，或为未维护场景推导可执行路线。
- Core 规则不依赖具体产品；受支持的运行环境分支和模型绑定见[运行环境与模型厂商支持](../instructions/fundamental-concepts--session-runtime--runtime-provider-support_zh_cn.md)。
- 按需读取 reference。不要仅因为可能以后有用，就预加载整个 Skill、`references/` 或原始项目状态。

# 验证独立性检查点


本检查点负责区分独立 Change Verification Session 和同一 Session 的逻辑验证。不定义检查内容、证据收集、结果分类或修复。

## 动作

1. 对实质性修改，在 Contract 要求时使用独立的 Change Verification Session。
2. 将同一 Session 中的检查标记为逻辑验证，不称为独立验证。

## 通过条件

独立性状态已明确分类：必需的独立 Session 已完成验证，或同 Session 检查标记为逻辑验证且独立验证不可用。后一种只是记录限制，**不**代表满足 Contract 所要求的独立验证；依赖影响继续阻塞。

## 边界

本检查点不选择整体或定向检查，不捕获指纹，不分类结果，不使 epoch 失效，不修复失败，也不产生 Git 影响。
