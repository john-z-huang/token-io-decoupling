# 文档影响

[English](workflow-checkpoints--documentation-impact.md) | [简体中文](workflow-checkpoints--documentation-impact_zh_cn.md)

下列直接给出当前动作、守卫、证据和失败边界。应用独立政策前，先按明确的指令继续入口取得对应单元；同一构建中已持有的单元直接复用，并保留受影响动作的准确恢复位置。不读取作者文件或推测缺失政策。执行副作用前核实当前事实与授权；指令内容可用不表示检查通过。

## 硬约束

- 采取行动前记录用户、运行环境、仓库、权限、安全和 Session 硬约束。
- “不要创建子代理”“不要使用浏览器”等任务级禁止条件在整个任务中持续有效。
- 绝对禁止 Computer Use：不得通过图形界面控制计算机、浏览器或桌面应用——包括以操纵控件为目的的截图、鼠标／键盘模拟、点击、辅助功能 API、窗口自动化、远程桌面控制或 GUI 脚本——也不得把此类交互包装为 API、CLI、MCP Server、辅助程序或其他 Agent 调用来绕过。本节是黑名单而非允许渠道清单：当前 Session 实际暴露且已获授权的其他工具、命令或能力仍然允许。若必需步骤需要借助被禁止的操作，应停止并报告阻塞，而不是尝试、委派或跳过。
- 路线选择或任何委派/Session 拓扑工作前，模式检查点必须组合并验证委派 references；这些 references 在各自的原子边界内规定会话级模式选择及默认多代理路线和单个子代理预算、子代理数量、条件创建、分配、复用、替换、例外和限制。预留预算本身不会初始化或授权创建子代理。
- 不得虚构授权、能力、证据、产品支持，或为未维护场景推导可执行路线。
- Core 规则不依赖具体产品；受支持的运行环境分支和模型绑定见[运行环境与模型厂商支持](../instructions/fundamental-concepts--session-runtime--runtime-provider-support_zh_cn.md)。
- 按需读取 reference。不要仅因为可能以后有用，就预加载整个 Skill、`references/` 或原始项目状态。

# 文档影响


本检查点负责文档/内容变更后的路线级影响分类和返回路由。


## 触发与输入

Documentation 或获批内容变更后，判断 implementation/content、documentation 或 Contract 证据是否改变。应用[Documentation](../instructions/workflow-concepts--completion-and-effects--documentation_zh_cn.md)和[Verification Epoch](../instructions/workflow-concepts--verification-and-repair--verification-epoch_zh_cn.md)。

## 决策与结果

1. 记录变更前后指纹，并分类每个受影响维度：实现/内容、文档、Git 元数据或多个维度。为每项分类附上证据。
2. 列出必需检查、仍可复用的证据，以及每个未变维度未变化的理由。无变化结果应带指纹证据并记录为 `Not applicable`。
3. 重新核验变更维度。若内容改变行为、Contract 或验收，将证据返回实现/内容 Verification；若仅文档变化，返回文档检查及未变维度理由。
4. 向路线调度返回分类、指纹、检查、复用理由和 Verification 处置结果。

## 失败边界

影响未知、必需检查缺失或证据过期时阻塞 Acceptance。保留受影响/不受影响维度判断及输出授权范围；变更 epoch 后不得复用旧证据。
