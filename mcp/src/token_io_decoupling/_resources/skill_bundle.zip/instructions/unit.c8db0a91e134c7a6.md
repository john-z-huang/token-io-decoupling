# unit.c8db0a91e134c7a6

[English](unit.c8db0a91e134c7a6.md) | [简体中文](unit.c8db0a91e134c7a6_zh_cn.md)

Apply the current instruction and its included policy sections below. The current actions, guards, evidence and failure boundary are given directly. Before applying a named independent policy, obtain its exact instruction continuation; reuse any already held unit from this build and retain the affected action's return position. Do not retrieve author files or infer omitted policy. Check current facts and authorization before effects; an instruction is not a pass.

## Hard constraints

- Record hard user, runtime environment, repository, permission, safety, and Session constraints before acting.
- A task-level prohibition, such as “do not create subagents” or “do not use a browser,” remains active for the whole task.
- Computer Use is categorically forbidden: never control a computer, browser, or desktop app through its graphical interface — no screenshots to locate controls, mouse or keyboard simulation, clicking, accessibility APIs, window automation, remote-desktop control, or GUI scripting — and do not route such interaction through an API, CLI, MCP server, helper, or another Agent. Treat this as a blacklist rather than a list of allowed channels: every other tool, command, or capability actually exposed to and authorized for the current Session remains permitted. If a required step needs a forbidden operation, stop and report the blocker instead of attempting, delegating, or skipping it.
- Before route selection or any delegation/Session-topology work, the Mode checkpoint must compose and validate the delegation references; those references own conversation-level mode selection with a default Multi-Agent route and one-child budget, child counts, conditional creation, allocation, reuse, replacement, exceptions, and limits at their respective atomic boundaries. A reserved budget never initializes or authorizes a child by itself.
- Never invent authorization, capability, evidence, product support, or an executable route for an unmaintained scenario.
- Keep Core rules independent of product details; read Runtime and Model Provider Support (instruction continuation: [unit.081374cfbaa37b57](../instructions/unit.081374cfbaa37b57.md)) for supported runtime branches and model bindings.
- Read references on demand. Do not preload the entire Skill, `references/`, or raw project state merely because it may become useful.

# Workflow Routing Advice

## General rules

### Advice stays advisory

Use this concept only to suggest the current stage or module from reviewed task facts and the locked route. The Coding workflow and selected route remain authoritative for stage order, checkpoint actions, evidence, branches, and acceptance. A suggestion never passes a checkpoint, changes the locked mode or child count, grants permission, creates or dispatches an agent, or calls another tool.

An explicit stage may be mapped locally when the current route and rules are available. Automatic stage selection is optional and may use a semantic decision only when the necessary source facts, current rule context, capability, and outbound-data authorization are available. If facts or rules are missing, stale, over budget, or contradictory, return to direct judgment using the current route owner. Do not turn missing evidence into an assumed stage.

Review the suggested stage against the current route and task state before acting. Treat hashes as change detectors, not source authentication or permission evidence. Refresh advice after relevant facts, route, or rules change. When the optional advice capability is unavailable, record that result. Continue only if an independently authorized Native/direct path applies; if a capability required by the selected path is missing, stop at its owner-defined boundary rather than silently falling back.

### Route boundary

The stage-to-module correspondence is owned by the current Single-Agent or Multi-Agent route. Advice may identify the matching module only after the mode/count is locked. Multi-Agent execution reminders do not replace role, task authorization, memo, Slice, and child lifecycle owners. Verification, repair, documentation, Git, and acceptance remain governed by their direct owners.

## Codex CLI / ChatGPT Desktop optimizations

When the capability is exposed and authorized, `decide_decoupling_workflow` accepts a bounded request under `payload.request`. The schema requires `mode_locked: true` and the canonical `mode_count`, along with all other required fields and bounded caller-supplied evidence; `stage` is `auto` or an explicit supported stage. `source_facts_hash` must match the supplied facts. Populate the complete current schema, including task identifiers and summary, language, capability and constraint records, source-fact references, and outbound-data assertion where applicable; this summary is not an exhaustive payload field list. Explicit stages are resolved locally after bounded rule checks. `auto` may make one Decisions request only when source facts are present, outbound data is permitted, and the configured capability allows it. The tool reloads relevant context and rechecks hashes before returning compact advice.

Only an `available` result is a suggestion; `insufficient_evidence`, `blocked`, and `stale` require review or refreshed facts/instructions. Consume the returned `instructions` for the selected stage together with its compiled outer-route scheduling context, prerequisite return map and exact suspended-position rules. Review their build identity and hashes against current task facts; they bind delivered compiled content, not source authentication, permission or checkpoint completion. Do not read original route files or interpret the next-stage label as permission to bypass repair, changed-epoch verification or a required return to the suspended documentation substep. Obtain any explicit compiled-unit continuation before its dependent action. The call is stateless and does not perform workflow actions. API failures are bounded and do not expose credentials or raw provider errors. Runtime/model and effort bindings remain in Runtime and Model Provider Support (instruction continuation: [unit.081374cfbaa37b57](../instructions/unit.081374cfbaa37b57.md)).

## Claude Code CLI / Claude Desktop optimizations

This repository's MCP Server supports local Codex CLI only. Claude's general MCP support does not make this server a supported direct client, and there is no Claude-specific direct-tool optimization for this owner. Mark that MCP optimization `Not applicable` and use the same-build generated document-only route page and instruction units through actually available, authorized document capabilities. Preserve its outer-route scheduling, prerequisite return and changed-epoch boundaries; do not fall back to original route files.
