# unit.94f2949c056b899f

[English](unit.94f2949c056b899f.md) | [简体中文](unit.94f2949c056b899f_zh_cn.md)

Apply the current instruction and its included policy sections below. The current actions, guards, evidence and failure boundary are given directly. Before applying a named independent policy, obtain its exact instruction continuation; reuse any already held unit from this build and retain the affected action's return position. Do not retrieve author files or infer omitted policy. Check current facts and authorization before effects; an instruction is not a pass.

## Hard constraints

- Record hard user, runtime environment, repository, permission, safety, and Session constraints before acting.
- A task-level prohibition, such as “do not create subagents” or “do not use a browser,” remains active for the whole task.
- Computer Use is categorically forbidden: never control a computer, browser, or desktop app through its graphical interface — no screenshots to locate controls, mouse or keyboard simulation, clicking, accessibility APIs, window automation, remote-desktop control, or GUI scripting — and do not route such interaction through an API, CLI, MCP server, helper, or another Agent. Treat this as a blacklist rather than a list of allowed channels: every other tool, command, or capability actually exposed to and authorized for the current Session remains permitted. If a required step needs a forbidden operation, stop and report the blocker instead of attempting, delegating, or skipping it.
- Before route selection or any delegation/Session-topology work, the Mode checkpoint must compose and validate the delegation references; those references own conversation-level mode selection with a default Multi-Agent route and one-child budget, child counts, conditional creation, allocation, reuse, replacement, exceptions, and limits at their respective atomic boundaries. A reserved budget never initializes or authorizes a child by itself.
- Never invent authorization, capability, evidence, product support, or an executable route for an unmaintained scenario.
- Keep Core rules independent of product details; read Runtime and Model Provider Support (instruction continuation: [unit.081374cfbaa37b57](../instructions/unit.081374cfbaa37b57.md)) for supported runtime branches and model bindings.
- Read references on demand. Do not preload the entire Skill, `references/`, or raw project state merely because it may become useful.

# Bootstrap selection


This checkpoint owns whether the current Multi-Agent task consumes Bootstrap/Refresh.


## Trigger and inputs

After current facts are established and Root has authorized the current task scope, consider whether that task triggers Bootstrap/Refresh. Use this authorized scope as the evaluation input. If Bootstrap/Refresh proposes a specific auxiliary task, Root must separately review and authorize that task before Executor Selection or role reservation. Read Child Role Allocation (instruction continuation: [unit.4706ccaa5a523c17](../instructions/unit.4706ccaa5a523c17.md)) for its existing trigger, threshold, skip conditions, and role/slot authorization.

## Decision and result

1. List the Root-authorized current task scope, proposed role, role occupancy/slot, and relevant Memory facts with their sources.
2. Apply the original Child Role Allocation trigger, threshold, and skip conditions item by item; record the matched condition or missing fact and explicit `Not applicable` reason.
3. When triggered, return the proposed Bootstrap/Refresh task and basis to later Executor Selection and Role Reservation; otherwise return `Not applicable`.
4. Return the decision evidence to the caller for the subsequent task and role decisions. This step does not reserve role/capacity, create a child, or release an Interaction Slice.

## Failure boundary

Unclear trigger facts or authorization block this branch. Do not copy/redefine the owner’s thresholds, infer a new role, reserve capacity early, or bypass the later Slice and creation gates.
