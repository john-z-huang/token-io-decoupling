# Environment Checkpoint

[English](workflow-concepts--entry-and-context--environment.md) | [简体中文](workflow-concepts--entry-and-context--environment_zh_cn.md)

Apply the current instruction and its included policy sections below. The current actions, guards, evidence and failure boundary are given directly. Before applying a named independent policy, obtain its exact instruction continuation; reuse any already held unit from this build and retain the affected action's return position. Do not retrieve author files or infer omitted policy. Check current facts and authorization before effects; an instruction is not a pass.

## Hard constraints

- Record hard user, runtime environment, repository, permission, safety, and Session constraints before acting.
- A task-level prohibition, such as “do not create subagents” or “do not use a browser,” remains active for the whole task.
- Computer Use is categorically forbidden: never control a computer, browser, or desktop app through its graphical interface — no screenshots to locate controls, mouse or keyboard simulation, clicking, accessibility APIs, window automation, remote-desktop control, or GUI scripting — and do not route such interaction through an API, CLI, MCP server, helper, or another Agent. Treat this as a blacklist rather than a list of allowed channels: every other tool, command, or capability actually exposed to and authorized for the current Session remains permitted. If a required step needs a forbidden operation, stop and report the blocker instead of attempting, delegating, or skipping it.
- Before route selection or any delegation/Session-topology work, the Mode checkpoint must compose and validate the delegation references; those references own conversation-level mode selection with a default Multi-Agent route and one-child budget, child counts, conditional creation, allocation, reuse, replacement, exceptions, and limits at their respective atomic boundaries. A reserved budget never initializes or authorizes a child by itself.
- Never invent authorization, capability, evidence, product support, or an executable route for an unmaintained scenario.
- Keep Core rules independent of product details; read [Runtime and Model Provider Support](../instructions/fundamental-concepts--session-runtime--runtime-provider-support.md) for supported runtime branches and model bindings.
- Read references on demand. Do not preload the entire Skill, `references/`, or raw project state merely because it may become useful.

# Environment Checkpoint


## Actions

1. Read explicit runtime metadata in the current system, developer, and application context. Use a named supported runtime as the primary fact.
2. Use the callable tool inventory, workspace roots, permission profile, sandbox details, and other exposed task metadata as corroborating evidence. A local shell, worktree, model name, or tool pattern alone does not uniquely identify the runtime environment.
3. If authorized by the current task, inspect only non-sensitive runtime metadata exposed by local process or environment information; never print or persist credentials or tokens.
4. Do not use a browser, GUI navigation, screenshots, or visual page content to identify the runtime environment.
5. Classify the runtime environment into exactly one branch defined by [Runtime and Model Provider Support](../instructions/fundamental-concepts--session-runtime--runtime-provider-support.md).
6. If the runtime environment does not fit any branch, mark the environment unsupported and stop work that depends on it.
7. If the evidence still leaves the runtime environment ambiguous, stop the dependent work and return that reference's exact fallback question to the user.

## Pass condition

The actual runtime environment is uniquely classified from explicit metadata, or the user has supplied the fallback clarification. Runtime ambiguity is recorded for resolution before dependent work.

## Boundary

This checkpoint does not choose an execution mode, bind a model to a role, authorize delegation, implement changes, or claim that an unobserved operation was performed.
