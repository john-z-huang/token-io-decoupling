# unit.bba9c45137f16455_zh_cn

[English](unit.bba9c45137f16455.md) | [简体中文](unit.bba9c45137f16455_zh_cn.md)

下列直接给出当前动作、守卫、证据和失败边界。应用独立政策前，先按明确的指令继续入口取得对应单元；同一构建中已持有的单元直接复用，并保留受影响动作的准确恢复位置。不读取作者文件或推测缺失政策。执行副作用前核实当前事实与授权；指令内容可用不表示检查通过。

## 硬约束

- 采取行动前记录用户、运行环境、仓库、权限、安全和 Session 硬约束。
- “不要创建子代理”“不要使用浏览器”等任务级禁止条件在整个任务中持续有效。
- 绝对禁止 Computer Use：不得通过图形界面控制计算机、浏览器或桌面应用——包括以操纵控件为目的的截图、鼠标／键盘模拟、点击、辅助功能 API、窗口自动化、远程桌面控制或 GUI 脚本——也不得把此类交互包装为 API、CLI、MCP Server、辅助程序或其他 Agent 调用来绕过。本节是黑名单而非允许渠道清单：当前 Session 实际暴露且已获授权的其他工具、命令或能力仍然允许。若必需步骤需要借助被禁止的操作，应停止并报告阻塞，而不是尝试、委派或跳过。
- 路线选择或任何委派/Session 拓扑工作前，模式检查点必须组合并验证委派 references；这些 references 在各自的原子边界内规定会话级模式选择及默认多代理路线和单个子代理预算、子代理数量、条件创建、分配、复用、替换、例外和限制。预留预算本身不会初始化或授权创建子代理。
- 不得虚构授权、能力、证据、产品支持，或为未维护场景推导可执行路线。
- Core 规则不依赖具体产品；受支持的运行环境分支和模型绑定见运行环境与模型厂商支持 (instruction continuation: [unit.081374cfbaa37b57](../instructions/unit.081374cfbaa37b57_zh_cn.md))。
- 按需读取 reference。不要仅因为可能以后有用，就预加载整个 Skill、`references/` 或原始项目状态。

# 执行模式检查点


## 动作

1. 加载状态记录 (instruction continuation: [unit.04519b62e6c4f711](../instructions/unit.04519b62e6c4f711_zh_cn.md))、模式确认 (instruction continuation: [unit.afaf028a769ea19e](../instructions/unit.afaf028a769ea19e_zh_cn.md))、数量门禁 (instruction continuation: [unit.36a14d319d1b638c](../instructions/unit.36a14d319d1b638c_zh_cn.md))和重新进入 (instruction continuation: [unit.5b0e93701a6ef118](../instructions/unit.5b0e93701a6ef118_zh_cn.md)) owner。不得在实际执行步骤前预先加载子代理创建、派发、生命周期或复用的完整策略。
2. 核对父级记录：Single-Agent 使用 `child_count: 0`、`allocations: []`；Multi-Agent 数量已锁定，具有恰好 `child_count` 个初始未绑定、未分配、待放行的预留名额。如果 `mode_source: default`，核实模式为 Multi-Agent、`child_count: 1` 且恰好有一个预留名额。如果 `mode_source: timeout-default`，仅为兼容旧记录而接受，并核实 Single-Agent、`child_count: 0` 和 `allocations: []`；新会话不再使用此来源。本门禁放行**不**等于具体 Interaction Slice 已放行，也不授权创建子代理。
3. 后续指令沿用已锁定 mode/count，只更新任务专属证据，不重新打开模式/数量门禁。记录或必需能力证据缺失时阻塞依赖路线。职责分配和子代理操作在路线指定的执行阶段核验。

4. 核验已记录获授权的模式/数量及本门禁所需证据。建议输出不能改变已锁定模式/数量或重开本门禁；建议政策遵循Decisions 建议 (instruction continuation: [unit.4d827a8a683055da](../instructions/unit.4d827a8a683055da_zh_cn.md))。

## 通过条件

父级记录具有唯一有效的已放行模式、固定数量及适用时有效的预留 allocation 结构，并满足路线入口能力；不得推断已有具体子代理或 Slice 获准。

## 边界

本检查点负责组合并验证状态记录、模式/数量和按条件加载的子代理派发/生命周期 reference，不独立决定模式、拓扑、创建、分配、复用、例外、生命周期或数量。父级控制任务记录保存在其规范对话上下文中，并按其 owner 回读。
