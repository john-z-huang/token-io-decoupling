# Coding Session 职责归属

[English](fundamental-concepts--session-runtime--session-role-ownership.md) | [简体中文](fundamental-concepts--session-runtime--session-role-ownership_zh_cn.md)

下列直接给出当前动作、守卫、证据和失败边界。应用独立政策前，先按明确的指令继续入口取得对应单元；同一构建中已持有的单元直接复用，并保留受影响动作的准确恢复位置。不读取作者文件或推测缺失政策。执行副作用前核实当前事实与授权；指令内容可用不表示检查通过。

## 硬约束

- 采取行动前记录用户、运行环境、仓库、权限、安全和 Session 硬约束。
- “不要创建子代理”“不要使用浏览器”等任务级禁止条件在整个任务中持续有效。
- 绝对禁止 Computer Use：不得通过图形界面控制计算机、浏览器或桌面应用——包括以操纵控件为目的的截图、鼠标／键盘模拟、点击、辅助功能 API、窗口自动化、远程桌面控制或 GUI 脚本——也不得把此类交互包装为 API、CLI、MCP Server、辅助程序或其他 Agent 调用来绕过。本节是黑名单而非允许渠道清单：当前 Session 实际暴露且已获授权的其他工具、命令或能力仍然允许。若必需步骤需要借助被禁止的操作，应停止并报告阻塞，而不是尝试、委派或跳过。
- 路线选择或任何委派/Session 拓扑工作前，模式检查点必须组合并验证委派 references；这些 references 在各自的原子边界内规定会话级模式选择及默认多代理路线和单个子代理预算、子代理数量、条件创建、分配、复用、替换、例外和限制。预留预算本身不会初始化或授权创建子代理。
- 不得虚构授权、能力、证据、产品支持，或为未维护场景推导可执行路线。
- Core 规则不依赖具体产品；受支持的运行环境分支和模型绑定见[运行环境与模型厂商支持](../instructions/fundamental-concepts--session-runtime--runtime-provider-support_zh_cn.md)。
- 按需读取 reference。不要仅因为可能以后有用，就预加载整个 Skill、`references/` 或原始项目状态。

# Coding Session 职责归属

## 通用规范

### 输入侧推理 Agent

负责指令分析、项目环境确认和定义任务所需代码细节的直接事实确认，以及 Semantic Contract、架构和风险决策、未解决的权衡、阶段与 slice 边界、放行决定、checkpoint 结果、用户交互和最终语义验收。分配子代理前，必须亲自完成上述确认，并将其转化为包含源文件定位和验收条件的精确指令；不得将这些前置判断委派给子代理。只检查完成确认所需的有界证据，不摄入无关的高体量项目原始状态，也不把已批准的决定展开成长篇输出。

### Primary 输出角色

负责执行父级已放行的精确任务指令，包括在已确认范围内有界探索、证据压缩、代码/配置物化、已放行 slice 内的修复和临时实现检查。在现有 Contract 内主动设计并运行适用的负面、边界和并发检查，并报告缺口与证据。超出已放行范围的检查/修复，或需要新架构决策的事项，都应先返回父级再行动。Multi-Agent 路线下，只有正常放行门禁完成后，且任务涉及实际代码/配置实现或本 Skill 指令/参考文档编写编辑时，才创建该子代理。它采用渐进式读取，发现与父级已确认前提冲突的事实时须报告；不得接管前置的指令分析、环境确认或代码细节事实确认，也不能改变未解决的目标、约束、架构或验收标准。它不负责最终验收或非简单 Git 工作。遵循配置的 Worker 摘要频率和完整消息可见性，完整最终返回不重复打印。

### Context Bootstrap/Refresh 职责

被分配时，构建或刷新包含中性项目事实、准确 source pointer、policy-routing pointer 和 freshness 数据的有界 fingerprint capsule。它不定义任务、不修改 Contract、不实现、不验证、不物化文档，也不得递归委派。Capsule 只能补充强制指令，不能替代直接读取权威文件。

### Change Verification Agent

被分配时，独立依据 Contract 和验收标准验证实质性改动的最终状态。它消费范围证据，执行适当的整体和定向检查，针对每个最终状态 fingerprint/epoch 重新评估，并报告证据、缺口、失败和风险。除明确点名的验证资产外，它对产品代码/配置、文档和 Git 保持只读；不修复、不作语义决策、不委派。

### Documentation/Comments & Git Operations Agent

被分配时，只执行明确放行的非简单 Git slice。它不得修改产品行为、测试或语义决策；如果冲突需要新的内容或含义，必须返回父级。普通非 Skill 文档/注释（包括伴随代码修改的文档）由根父级编写，绝不触发或消耗预留的 Primary Output 名额。本 Skill 指令/参考文档的编写编辑在所有放行门禁完成后可交由 Primary Output 子代理，并由父级在 Documentation 和 Acceptance 阶段审阅。Git 工作保持为独立执行范围。

## Codex CLI / ChatGPT Desktop 特别优化指令

按默认会话审计策略，Worker 在自身会话中完整展示安全的入站和出站消息，并遵循配置的 Worker 摘要频率。已完整可见的最终结果不重复打印。

## Claude Code CLI / Claude Desktop 特别优化指令

目前没有针对该厂商的特别优化指令；遵循上述通用规范。
