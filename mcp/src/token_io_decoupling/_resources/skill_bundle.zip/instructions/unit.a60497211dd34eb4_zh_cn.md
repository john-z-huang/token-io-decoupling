# unit.a60497211dd34eb4_zh_cn

[English](unit.a60497211dd34eb4.md) | [简体中文](unit.a60497211dd34eb4_zh_cn.md)

下列直接给出当前动作、守卫、证据和失败边界。应用独立政策前，先按明确的指令继续入口取得对应单元；同一构建中已持有的单元直接复用，并保留受影响动作的准确恢复位置。不读取作者文件或推测缺失政策。执行副作用前核实当前事实与授权；指令内容可用不表示检查通过。

## 硬约束

- 采取行动前记录用户、运行环境、仓库、权限、安全和 Session 硬约束。
- “不要创建子代理”“不要使用浏览器”等任务级禁止条件在整个任务中持续有效。
- 绝对禁止 Computer Use：不得通过图形界面控制计算机、浏览器或桌面应用——包括以操纵控件为目的的截图、鼠标／键盘模拟、点击、辅助功能 API、窗口自动化、远程桌面控制或 GUI 脚本——也不得把此类交互包装为 API、CLI、MCP Server、辅助程序或其他 Agent 调用来绕过。本节是黑名单而非允许渠道清单：当前 Session 实际暴露且已获授权的其他工具、命令或能力仍然允许。若必需步骤需要借助被禁止的操作，应停止并报告阻塞，而不是尝试、委派或跳过。
- 路线选择或任何委派/Session 拓扑工作前，模式检查点必须组合并验证委派 references；这些 references 在各自的原子边界内规定会话级模式选择及默认多代理路线和单个子代理预算、子代理数量、条件创建、分配、复用、替换、例外和限制。预留预算本身不会初始化或授权创建子代理。
- 不得虚构授权、能力、证据、产品支持，或为未维护场景推导可执行路线。
- Core 规则不依赖具体产品；受支持的运行环境分支和模型绑定见运行环境与模型厂商支持 (instruction continuation: [unit.081374cfbaa37b57](../instructions/unit.081374cfbaa37b57_zh_cn.md))。
- 按需读取 reference。不要仅因为可能以后有用，就预加载整个 Skill、`references/` 或原始项目状态。

# 建议选择


本检查点负责可选建议在各阶段的适用性路由。


## 触发与输入

Mode 和 Session 通过且存在获授权 Root 上下文前，建议记为 `Not applicable`；任务意图/输出分类使用直接权威来源。建议不能选择或改变路线选择结果，不能重开 Mode gate 或改变已锁定 mode/count。存在获授权 Root 上下文后，Decision、Control 和 Verification/Epoch 阶段分别只消费与自身相关的建议。应用Decisions Advisory (instruction continuation: [unit.4d827a8a683055da](../instructions/unit.4d827a8a683055da_zh_cn.md))和当前直接检查点 owner；将每条建议返回指定阶段进行基于证据的审阅。

## 决策与结果

1. Mode、Session 和已授权 Root 上下文通过前，记录 `Not applicable`；任务意图和输出分类使用直接权威来源。
2. 在 Decision、Control 和 Verification/Epoch 阶段，仅当建议已启用、符合条件、相关，且当前阶段绑定和 Root 授权已核实时，才评估可选建议。
3. 记录类型化建议、当前政策/输入/上下文 Hash、新鲜度结果及与直接 owner 的比较。将建议返回该阶段，并依据权威 owner 和当前证据决策。
4. Task Assignment、Output Token Routing 和角色预留建议不属于这五节点 opt-in 门禁；其 owner 独立控制这些决策。
5. 向路线调度返回已审阅建议或附理由的 `Not applicable`；建议不授权工作，也不替代通过条件。

## 失败边界

建议过期、不可用、格式错误或调用失败时，仅当必需事实仍充分时才回退到直接 owner 审查，否则阻塞。不得把外部建议调用变成强制要求，也不得绕过 opt-in/授权限制重试。
