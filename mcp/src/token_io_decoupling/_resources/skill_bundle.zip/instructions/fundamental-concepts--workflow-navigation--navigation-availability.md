# Workflow Navigation Availability

[English](fundamental-concepts--workflow-navigation--navigation-availability.md) | [简体中文](fundamental-concepts--workflow-navigation--navigation-availability_zh_cn.md)

Apply the current instruction and its included policy sections below. The current actions, guards, evidence and failure boundary are given directly. Before applying a named independent policy, obtain its exact instruction continuation; reuse any already held unit from this build and retain the affected action's return position. Do not retrieve author files or infer omitted policy. Check current facts and authorization before effects; an instruction is not a pass.

## Hard constraints

- Record hard user, runtime environment, repository, permission, safety, and Session constraints before acting.
- A task-level prohibition, such as “do not create subagents” or “do not use a browser,” remains active for the whole task.
- Computer Use is categorically forbidden: never control a computer, browser, or desktop app through its graphical interface — no screenshots to locate controls, mouse or keyboard simulation, clicking, accessibility APIs, window automation, remote-desktop control, or GUI scripting — and do not route such interaction through an API, CLI, MCP server, helper, or another Agent. Treat this as a blacklist rather than a list of allowed channels: every other tool, command, or capability actually exposed to and authorized for the current Session remains permitted. If a required step needs a forbidden operation, stop and report the blocker instead of attempting, delegating, or skipping it.
- Before route selection or any delegation/Session-topology work, the Mode checkpoint must compose and validate the delegation references; those references own conversation-level mode selection with a default Multi-Agent route and one-child budget, child counts, conditional creation, allocation, reuse, replacement, exceptions, and limits at their respective atomic boundaries. A reserved budget never initializes or authorizes a child by itself.
- Never invent authorization, capability, evidence, product support, or an executable route for an unmaintained scenario.
- Keep Core rules independent of product details; read [Runtime and Model Provider Support](../instructions/fundamental-concepts--session-runtime--runtime-provider-support.md) for supported runtime branches and model bindings.
- Read references on demand. Do not preload the entire Skill, `references/`, or raw project state merely because it may become useful.

# Workflow Navigation Availability

## General rules

Author owners remain the development-time policy authority; execution consumes their approved compiled instructions. Optional navigation selects bounded instruction units and structural checks inspect supplied input. Their availability does not establish runtime identity, protected-operation capability, permission, or workflow state.

When optional navigation is unavailable, an already available, authorized same-build generated document-only instruction surface may supply the explicit current unit. This is an alternative delivery surface, not author-source fallback. Missing, incomplete, corrupt or incompatible required instruction resources block dependent work; do not search author documents, infer policy or skip requirements. When optional navigation is unnecessary, record `Not applicable` with the reason and consume the corresponding delivered instruction directly.

Stateless structural checks cannot substitute for compiled-instruction review, evidence interpretation, authorization, Slice release, Control, verification, or acceptance. They do not retain canonical workflow state, establish cross-call order, or turn supplied hashes into proof.

## Codex CLI / ChatGPT Desktop optimizations

When `rules_get_context` is unavailable, use only an actually available and authorized same-build generated document-only Skill, retaining explicit unit identity and continuation position. Resource errors block the affected path instead of enabling source fallback. Structural evaluation remains optional unless independently required. Do not invent an alternate persisted workflow backend or treat an unavailable result as a pass.

## Claude Code CLI / Claude Desktop optimizations

There is no supported direct Claude client for this project's MCP server. Use the generated document-only Skill through actually available, authorized document capabilities and follow the general same-build and failure checks; the MCP optimization is `Not applicable`.
