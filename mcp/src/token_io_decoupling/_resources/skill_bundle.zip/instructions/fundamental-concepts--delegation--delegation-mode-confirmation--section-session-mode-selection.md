# fundamental-concepts / delegation / delegation-mode-confirmation / section-session-mode-selection

[English](fundamental-concepts--delegation--delegation-mode-confirmation--section-session-mode-selection.md) | [简体中文](fundamental-concepts--delegation--delegation-mode-confirmation--section-session-mode-selection_zh_cn.md)

Apply the current instruction and its included policy sections below. The current actions, guards, evidence and failure boundary are given directly. Before applying a named independent policy, obtain its exact instruction continuation; reuse any already held unit from this build and retain the affected action's return position. Do not retrieve author files or infer omitted policy. Check current facts and authorization before effects; an instruction is not a pass.

## Hard constraints

- Record hard user, runtime environment, repository, permission, safety, and Session constraints before acting.
- A task-level prohibition, such as “do not create subagents” or “do not use a browser,” remains active for the whole task.
- Computer Use is categorically forbidden: never control a computer, browser, or desktop app through its graphical interface — no screenshots to locate controls, mouse or keyboard simulation, clicking, accessibility APIs, window automation, remote-desktop control, or GUI scripting — and do not route such interaction through an API, CLI, MCP server, helper, or another Agent. Treat this as a blacklist rather than a list of allowed channels: every other tool, command, or capability actually exposed to and authorized for the current Session remains permitted. If a required step needs a forbidden operation, stop and report the blocker instead of attempting, delegating, or skipping it.
- Before route selection or any delegation/Session-topology work, the Mode checkpoint must compose and validate the delegation references; those references own conversation-level mode selection with a default Multi-Agent route and one-child budget, child counts, conditional creation, allocation, reuse, replacement, exceptions, and limits at their respective atomic boundaries. A reserved budget never initializes or authorizes a child by itself.
- Never invent authorization, capability, evidence, product support, or an executable route for an unmaintained scenario.
- Keep Core rules independent of product details; read [Runtime and Model Provider Support](../instructions/fundamental-concepts--session-runtime--runtime-provider-support.md) for supported runtime branches and model bindings.
- Read references on demand. Do not preload the entire Skill, `references/`, or raw project state merely because it may become useful.

### Session mode selection

On the first Coding directive in a host-identified Session lifetime, the root parent must:

1. Honor an explicit valid mode/count choice in the directive without asking again.
2. If no valid choice is present, present this numbered menu. Only when the Mode gate must be released and there is still no valid user choice, use the stated default; an unanswered prompt by itself does not require releasing the gate. Explicit no-preference also selects the default:
   1. Multi-Agent Coding, 1 child (recommended and default).
   2. Single-Agent Coding, 0 children.
   3. Multi-Agent Coding, custom positive child count (enter the integer as free text).
   4. Custom instruction (enter it as free text; map it to a maintained mode and valid count).
3. For option 3, require an explicit positive integer. If it is missing or invalid, ask one focused follow-up and keep the Mode gate unreleased; never substitute one. For option 4, use the text only to derive a maintained Single-Agent or Multi-Agent route and valid count, while recording other task constraints. If it is missing, invalid, ambiguous, conflicting, or requests an unmaintained route, ask one focused clarification and keep the gate unreleased. Custom text cannot override higher-priority permissions, safety, repository, authorization, or capability boundaries, and cannot create a route or capability.
4. Record a valid user selection as `mode_source: explicit`. Record the no-reply or explicit no-preference default as `mode_source: default`, `mode: Multi-Agent Coding`, and `child_count: 1`. Apply the count owner before route release. Keep the mode fixed for the full host Session lifetime, not one user/assistant exchange. Later directives, compaction, and same-Session resume reuse it. The initial count remains fixed except for the Count Gate's exact one-slot increase after actual explicit user approval for a different unoccupied role; this does not reopen mode selection. A Fork with a new Session identity must complete fresh mode/count selection under the Re-entry owner rather than inherit the source Session's choice.
5. Treat the released Multi-Agent count as reserved capacity only. Displaying the menu, selecting a mode, or locking the count never creates or initializes a child. Creation remains subject to the role, output-type, and released-slice gates.

The default selects a workflow mode and reserved count only; it does not bypass a task-level prohibition or create a capability. If a higher-priority restriction forbids children, it controls. If the required record capability is absent, block the dependent route rather than pretending it exists.

No child may be created until the count gate has released a valid positive count, the relevant role and concrete slice are released, and the output is code/configuration implementation or authorship/editing of this Skill's instructions or reference documents. Ordinary non-Skill documentation is authored by the root parent, including in tasks that also contain code changes. If the conversation is already locked to Single-Agent Coding, apply the Re-entry owner before considering any conflicting later instruction.
