# 工作定义模块

[English](workflows--modules--work-definition.md) | [简体中文](workflows--modules--work-definition_zh_cn.md)

下列直接给出当前动作、守卫、证据和失败边界。应用独立政策前，先按明确的指令继续入口取得对应单元；同一构建中已持有的单元直接复用，并保留受影响动作的准确恢复位置。不读取作者文件或推测缺失政策。执行副作用前核实当前事实与授权；指令内容可用不表示检查通过。

## 硬约束

- 采取行动前记录用户、运行环境、仓库、权限、安全和 Session 硬约束。
- “不要创建子代理”“不要使用浏览器”等任务级禁止条件在整个任务中持续有效。
- 绝对禁止 Computer Use：不得通过图形界面控制计算机、浏览器或桌面应用——包括以操纵控件为目的的截图、鼠标／键盘模拟、点击、辅助功能 API、窗口自动化、远程桌面控制或 GUI 脚本——也不得把此类交互包装为 API、CLI、MCP Server、辅助程序或其他 Agent 调用来绕过。本节是黑名单而非允许渠道清单：当前 Session 实际暴露且已获授权的其他工具、命令或能力仍然允许。若必需步骤需要借助被禁止的操作，应停止并报告阻塞，而不是尝试、委派或跳过。
- 路线选择或任何委派/Session 拓扑工作前，模式检查点必须组合并验证委派 references；这些 references 在各自的原子边界内规定会话级模式选择及默认多代理路线和单个子代理预算、子代理数量、条件创建、分配、复用、替换、例外和限制。预留预算本身不会初始化或授权创建子代理。
- 不得虚构授权、能力、证据、产品支持，或为未维护场景推导可执行路线。
- Core 规则不依赖具体产品；受支持的运行环境分支和模型绑定见[运行环境与模型厂商支持](../instructions/fundamental-concepts--session-runtime--runtime-provider-support_zh_cn.md)。
- 按需读取 reference。不要仅因为可能以后有用，就预加载整个 Skill、`references/` 或原始项目状态。

# 工作定义模块


本 Layer-04 模块用当前事实建立任务上下文，并产出符合 Contract 的决策及默认共享任务计划。它不选择执行者、不评估输出路由、不预留角色、不释放 Slice，也不执行 Bootstrap。

## 入口声明

| 字段 | 要求 |
| --- | --- |
| 必需输入 | 当前已授权 Contract 和任务范围、已释放路线/模式证据、当前规范 Session state 和已完成的审计读回、已知任务事实/来源指针、取得所需 Context 的已授权可用方式，以及调用方 continuation/效果状态。WD01 建立当前 Context；它不是入口前置条件。 |
| 允许效果 | 有界且已授权的只读 Context 检索；仅在已有授权的当前 Root Session 下请求符合条件的语义建议；在既有授权内默认持久化任务计划，并遵守明确持久化限制。不得执行 executor/output 路由、角色预留、Slice 释放、Bootstrap、实施或子代理派发。 |
| 结果 | 本模块以当前有来源的 Context、符合 Contract 的 Decision/未释放边界，以及计划证据或有依据的子步骤 `not_applicable` 返回 `complete`；否则返回带暂停位置的 `needs_prerequisite` 或 `blocked`。Context/建议/计划子步骤可根据触发证据标为 `not_applicable`，但不得整体跳过必需的工作定义模块。建议是待审证据，不是授权。 |
| 新鲜度 | 保留来源/出处/新鲜度及相关 input/policy hash 和 epoch。建议或依赖决策前重新确认；实质变化会使受影响证据失效，并要求调用方从受影响子步骤重新进入。 |

## 工作流路线图


## 有序模块清单

1. **WD00 — 解析入口。** 提供本声明、当前已授权 Contract 和任务范围、已释放路线/模式证据、当前规范 Session state 和已完成的审计读回、已知任务事实/来源指针、取得所需 Context 的已授权可用方式，以及 continuation/效果状态，调用[模块入口解析](../instructions/workflow-checkpoints--module-entry-resolution_zh_cn.md)。规范 state 和已完成审计读回是必需输入；当前任务 Context 在 WD01 建立。从记录的子步骤恢复。缺少前置条件时，连同语义 owner 一起返回；冲突或无法恢复的状态则阻塞。没有已授权的当前 Session 时，不请求建议。
2. **WD01 — 建立有界当前 Context。** 应用[Context](../instructions/workflow-concepts--entry-and-context--context_zh_cn.md)、[上下文来源选择](../instructions/workflow-checkpoints--context-source-selection_zh_cn.md)和[Session Context Firewall](../instructions/fundamental-concepts--session-runtime--session-context-firewall_zh_cn.md)。定义下一项任务所需的最小问题，只检查必需来源。计划内容在当前上下文中有效时直接复用；否则按需获取匹配的 active plan Memory。当前指令优先，plan 不授予授权。仅在所需内容缺失或过期时读取相关可复用 Memory，并核验来源指针/新鲜度；如果没有或不可用，返回经批准的权威项目来源，只有必需事实仍无法核实时才阻塞。仅在触发有界规则查询时使用[Workflow Rule Context](../instructions/fundamental-concepts--workflow-navigation--rule-context_zh_cn.md)，确认 owner/语言/来源/hash，并读取被摘录省略的直接 owner。仅在需要项目/代码结构证据时应用[LSP MCP Tools](../instructions/fundamental-concepts--session-runtime--lsp-mcp-tools_zh_cn.md)；否则记录 `not_applicable` 及原因。返回有来源的当前事实、来源链、新鲜度/epoch 和限制；过期、冲突或缺失的关键事实会阻塞依赖决策。
   - 若下游 Decision 建议需要审阅背景，应用[决策上下文选择](../instructions/workflow-checkpoints--decision-context-selection_zh_cn.md)和[Decision Context Generation](../instructions/fundamental-concepts--execution-planning--decision-context-generation_zh_cn.md)：只提供有界事实和具体目标，审查忠实度/相关性/来源，并核验准确的输入/政策绑定。拒绝过期或不匹配背景；若建议不需要生成背景，记录 `not_applicable` 及原因。
   - 仅在 Multi-Agent 模式下，若上下文来源选择 owner 确认触发了持久化交换或 memo 前置条件，则只按该触发检查相应的[Context Exchange](../instructions/fundamental-concepts--context-exchange--context-exchange_zh_cn.md)、[工作区边界](../instructions/fundamental-concepts--context-exchange--context-exchange-workspace-boundary_zh_cn.md)、[交接](../instructions/fundamental-concepts--context-exchange--context-exchange-handoff_zh_cn.md)或[Content Memo Dispatch](../instructions/fundamental-concepts--context-exchange--content-memo-dispatch_zh_cn.md) owner。确认必需的当前记录和 Memory 证据；不得仅为收集 Context 创建交换记录，也不得在此派发 memo。未触发时记录 `not_applicable` 及原因。Single-Agent 模式下，这些子代理专属交换和 memo owners 均为 `not_applicable`；不得加载这些 owner。
3. **WD02 — 在 Contract 范围内决策。** 应用[Decision](../instructions/workflow-concepts--decision-and-execution--decision_zh_cn.md)、[执行决策门禁](../instructions/fundamental-concepts--execution-planning--execution-decision-gate_zh_cn.md)和[执行规划](../instructions/fundamental-concepts--execution-planning--execution-planning_zh_cn.md)。说明实质问题、已核实事实、未知项、选项、所选方向、拒绝的替代方案、授权范围/效果、返回条件和未释放边界。对于仍开放的实质选择，准备必需的 Decision Brief，且只释放侦察；确认 Contract 允许所选方向后再进入后续释放。Session 实质恢复后，仅在调用方要求时于此重评当前 Decision/Contract 证据；不得重开 Mode 或重复已完成的审计提问。
   - 建议是可选的。仅当已有授权的当前 Root Session 存在，且 Decision 阶段符合资格、已启用并且相关时，应用[建议选择](../instructions/workflow-checkpoints--advisory-selection_zh_cn.md)和[Decisions Advisory](../instructions/fundamental-concepts--execution-planning--decisions-advisory_zh_cn.md)。否则依赖直接 owner 并将建议记录为带原因的 `not_applicable`。根据当前直接 owner 证据和 hash 审查任何建议；建议不会选择或授权工作。
   - 任务阶段建议是独立的可选输入。仅当 WD01 事实当前有效、锁定的 mode/count 与所选路线已直接确认，且建议路径符合条件、已启用并获授权时，才应用[工作流路由建议](../instructions/fundamental-concepts--execution-planning--workflow-routing-advice_zh_cn.md)。它可以建议恢复时的当前阶段/模块；任何可用建议都须根据当前所选路线及来源/政策哈希审阅。它不会改变路线或 mode/count、通过门禁、选择执行者/输出或释放工作。未选择或不符合条件时，记录有原因的 `not_applicable` 并按当前路线继续。如果所选路径必需能力不可用或证据过期/不足，返回以取得当前证据或阻塞该依赖路径；不得静默回退。此项与上方现有 Decision 建议保持分离。
   - 执行者选择和输出路由不属于本模块范围，仍由之后另行授权的执行路径处理。
4. **WD03 — 解决默认共享任务计划。** 调用[规划输出选择](../instructions/workflow-checkpoints--planning-output-selection_zh_cn.md)，应用[任务计划 Memory 生命周期](../instructions/fundamental-concepts--execution-planning--task-plan-memory-lifecycle_zh_cn.md)。无论有无 Issue 或明确规划请求，均综合当前事实与拟议方案，持久化具体计划，并在实施或依赖派发前确认操作成功；owner 要求时才核验内容。确认所选存储范围、仓库身份和对应活动/归档命名空间；共享存储中，同仓库各工作区复用规划，其他仓库保持隔离。按生命周期 owner 解析映射；映射未知或冲突时阻塞，不静默回退。返回准确项目/计划身份、存储映射、允许贡献、持久化确认及 owner 要求的核验证据。仅已记录的明确持久化限制允许使用 owner 的例外；与明确持久化要求冲突、必需访问缺失、写入失败或必需核验失败时阻塞。需求变化先记录，再分析并持久化修订提议，然后才处理受影响工作。只有当前事实、符合 Contract 的 Decision/未释放边界，以及当前计划证据或有依据的限制例外齐备时，才返回 `complete`。这不释放 Slice、不选择执行者，也不授权实施；必需模块不能整体跳过为 `not_applicable`。
