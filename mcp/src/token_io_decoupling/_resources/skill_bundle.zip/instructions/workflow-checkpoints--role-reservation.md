# Role reservation

[English](workflow-checkpoints--role-reservation.md) | [简体中文](workflow-checkpoints--role-reservation_zh_cn.md)

Apply the current instruction and its included policy sections below. The current actions, guards, evidence and failure boundary are given directly. Before applying a named independent policy, obtain its exact instruction continuation; reuse any already held unit from this build and retain the affected action's return position. Do not retrieve author files or infer omitted policy. Check current facts and authorization before effects; an instruction is not a pass.

## Hard constraints

- Record hard user, runtime environment, repository, permission, safety, and Session constraints before acting.
- A task-level prohibition, such as “do not create subagents” or “do not use a browser,” remains active for the whole task.
- Computer Use is categorically forbidden: never control a computer, browser, or desktop app through its graphical interface — no screenshots to locate controls, mouse or keyboard simulation, clicking, accessibility APIs, window automation, remote-desktop control, or GUI scripting — and do not route such interaction through an API, CLI, MCP server, helper, or another Agent. Treat this as a blacklist rather than a list of allowed channels: every other tool, command, or capability actually exposed to and authorized for the current Session remains permitted. If a required step needs a forbidden operation, stop and report the blocker instead of attempting, delegating, or skipping it.
- Before route selection or any delegation/Session-topology work, the Mode checkpoint must compose and validate the delegation references; those references own conversation-level mode selection with a default Multi-Agent route and one-child budget, child counts, conditional creation, allocation, reuse, replacement, exceptions, and limits at their respective atomic boundaries. A reserved budget never initializes or authorizes a child by itself.
- Never invent authorization, capability, evidence, product support, or an executable route for an unmaintained scenario.
- Keep Core rules independent of product details; read [Runtime and Model Provider Support](../instructions/fundamental-concepts--session-runtime--runtime-provider-support.md) for supported runtime branches and model bindings.
- Read references on demand. Do not preload the entire Skill, `references/`, or raw project state merely because it may become useful.

# Role reservation


This checkpoint owns role-reservation decisions for an authorized Multi-Agent task. [Child Role Selection](../instructions/fundamental-concepts--delegation--child-role-selection.md), the [Count Gate](../instructions/fundamental-concepts--delegation--delegation-mode-count-gate.md), the [State Record](../instructions/fundamental-concepts--delegation--delegation-state-record.md), and [Child Role Allocation](../instructions/fundamental-concepts--delegation--delegation-child-role-allocation.md) remain authoritative for role choice, capacity, identity/state, and reservation.

## Trigger and inputs

Run only after Executor Selection returns `new-executor-needed` for an authorized proposed task and Output Route Selection has independently dispositioned direct Root output. Read the four linked L1 owners and current Session role/allocation/capacity facts.

## Decision and result

1. Apply Child Role Selection to match the actual authorized proposed task to one maintained role. Honor explicit user role direction; use its conditional Primary fallback only when the owner’s trigger is met. Suggestions or a Primary preference do not authorize creation.
2. Read the entire current-Session role ledger from the State Record and Role Allocation owner. Any role already reserved or created by any Session member is occupied. Do not count inherited agents from another Session.
3. If a different unoccupied role fits, record its unique reservation in the current allocation within locked capacity. If capacity alone is insufficient, and only if that role remains unoccupied, request explicit approval for exactly `+1` through the Count Gate. Never increase automatically.
4. If all four roles are occupied, block without requesting more capacity. Return the reservation, `Not applicable` with evidence/reason, or block to the caller for task orchestration. Slice release and child creation remain later, separate gates.

## Failure boundary

Missing authorized task, stale or uncertain Session state, role conflict, unavailable role, insufficient capacity without exact approval, or unresolved role fit blocks Slice release. This checkpoint does not release a Slice, create, or dispatch.
