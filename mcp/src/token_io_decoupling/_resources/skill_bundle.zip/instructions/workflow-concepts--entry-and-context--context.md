# Context Checkpoint

[English](workflow-concepts--entry-and-context--context.md) | [简体中文](workflow-concepts--entry-and-context--context_zh_cn.md)

Apply the current instruction and its included policy sections below. The current actions, guards, evidence and failure boundary are given directly. Before applying a named independent policy, obtain its exact instruction continuation; reuse any already held unit from this build and retain the affected action's return position. Do not retrieve author files or infer omitted policy. Check current facts and authorization before effects; an instruction is not a pass.

## Hard constraints

- Record hard user, runtime environment, repository, permission, safety, and Session constraints before acting.
- A task-level prohibition, such as “do not create subagents” or “do not use a browser,” remains active for the whole task.
- Computer Use is categorically forbidden: never control a computer, browser, or desktop app through its graphical interface — no screenshots to locate controls, mouse or keyboard simulation, clicking, accessibility APIs, window automation, remote-desktop control, or GUI scripting — and do not route such interaction through an API, CLI, MCP server, helper, or another Agent. Treat this as a blacklist rather than a list of allowed channels: every other tool, command, or capability actually exposed to and authorized for the current Session remains permitted. If a required step needs a forbidden operation, stop and report the blocker instead of attempting, delegating, or skipping it.
- Before route selection or any delegation/Session-topology work, the Mode checkpoint must compose and validate the delegation references; those references own conversation-level mode selection with a default Multi-Agent route and one-child budget, child counts, conditional creation, allocation, reuse, replacement, exceptions, and limits at their respective atomic boundaries. A reserved budget never initializes or authorizes a child by itself.
- Never invent authorization, capability, evidence, product support, or an executable route for an unmaintained scenario.
- Keep Core rules independent of product details; read [Runtime and Model Provider Support](../instructions/fundamental-concepts--session-runtime--runtime-provider-support.md) for supported runtime branches and model bindings.
- Read references on demand. Do not preload the entire Skill, `references/`, or raw project state merely because it may become useful.

# Context Checkpoint


## Actions

1. Define the smallest question the next slice must answer.
2. Read only the files, metadata, history, or generated evidence needed for that question.
3. Before reusing cached or file-backed context, check its scope, owner, source paths, freshness, and final-state epoch.
4. Treat stale, incomplete, or conflicting context as unusable. Refresh only the affected context and record what changed.
5. Keep context factual and routing-oriented; do not use it as a replacement for the Contract, source documents, or verification.
6. For instruction lookup selected by the applicable workflow decision node, apply [Workflow Rule Context](../instructions/fundamental-concepts--workflow-navigation--rule-context.md): verify the current node/unit, language, build/hash and completeness. Obtain each explicit compiled instruction continuation before its dependent action, preserving the exact return position. Keep consumption bounded; missing or incompatible required instructions block dependent work instead of triggering author-file lookup.
7. When a released Worker must persist a memo or exchange record, require the named persistent-memory capability and confirm its availability; memo and cross-Worker exchange remain independent triggers. Apply the linked Layer-01 owner for logical ownership. If the capability is unavailable, report it and block dependent work; do not fall back to file storage.
8. When a released task requires reusable Agent project knowledge from prior work, use the [project-memory and code-structure capability](../instructions/fundamental-concepts--session-runtime--lsp-mcp-tools.md) to access authorized Memory and check its source pointers and freshness against authoritative project files. Report unavailable capability; return to approved authoritative project files and pause only when an essential fact cannot be confirmed another approved way. A memory does not replace an authoritative project file in the approved paths.

9. Apply [Task Plan Memory Lifecycle](../instructions/fundamental-concepts--execution-planning--task-plan-memory-lifecycle.md): use the matching shared plan when its contents are current in context; otherwise read it when needed, and qualify it against current authoritative sources. Record updates at owner-defined boundaries; facts affecting authorization, scope, acceptance, direction, or dependent actions must be recorded before those actions. Required access, persistence, or owner-required verification failure blocks dependent work; a documented persistence restriction follows the owner's exception.

## Pass condition

The next slice has bounded, current context, or the exact missing context is recorded and the slice is paused.

## Boundary

This checkpoint gathers and qualifies context. It does not make material decisions, authorize implementation, or declare verification complete.
