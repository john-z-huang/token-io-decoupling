# unit.d89ebcb45ebe2dea

[English](unit.d89ebcb45ebe2dea.md) | [简体中文](unit.d89ebcb45ebe2dea_zh_cn.md)

Apply the current instruction and its included policy sections below. The current actions, guards, evidence and failure boundary are given directly. Before applying a named independent policy, obtain its exact instruction continuation; reuse any already held unit from this build and retain the affected action's return position. Do not retrieve author files or infer omitted policy. Check current facts and authorization before effects; an instruction is not a pass.

## Hard constraints

- Record hard user, runtime environment, repository, permission, safety, and Session constraints before acting.
- A task-level prohibition, such as “do not create subagents” or “do not use a browser,” remains active for the whole task.
- Computer Use is categorically forbidden: never control a computer, browser, or desktop app through its graphical interface — no screenshots to locate controls, mouse or keyboard simulation, clicking, accessibility APIs, window automation, remote-desktop control, or GUI scripting — and do not route such interaction through an API, CLI, MCP server, helper, or another Agent. Treat this as a blacklist rather than a list of allowed channels: every other tool, command, or capability actually exposed to and authorized for the current Session remains permitted. If a required step needs a forbidden operation, stop and report the blocker instead of attempting, delegating, or skipping it.
- Before route selection or any delegation/Session-topology work, the Mode checkpoint must compose and validate the delegation references; those references own conversation-level mode selection with a default Multi-Agent route and one-child budget, child counts, conditional creation, allocation, reuse, replacement, exceptions, and limits at their respective atomic boundaries. A reserved budget never initializes or authorizes a child by itself.
- Never invent authorization, capability, evidence, product support, or an executable route for an unmaintained scenario.
- Keep Core rules independent of product details; read Runtime and Model Provider Support (instruction continuation: [unit.081374cfbaa37b57](../instructions/unit.081374cfbaa37b57.md)) for supported runtime branches and model bindings.
- Read references on demand. Do not preload the entire Skill, `references/`, or raw project state merely because it may become useful.

# Coding Session Role Ownership

## General rules

### Input-side Reasoning Agent

Owns instruction analysis, project-environment confirmation, and direct confirmation of the code details needed to define a task, as well as the Semantic Contract, architecture and risk decisions, unresolved trade-offs, stage and slice boundaries, release decisions, checkpoint outcomes, user interaction, and final semantic acceptance. Before assigning a child, it must complete these confirmations itself and turn them into precise instructions with source pointers and acceptance conditions. It must not delegate these prerequisite judgments to a child. It inspects only the bounded evidence needed for those confirmations and does not absorb unrelated high-volume raw project state or expand already-approved decisions into long output.

### Primary Output Role

Owns execution of the parent's precise, released task instructions, including bounded exploration within the confirmed scope, evidence compression, code/configuration materialization, repairs within the released slice, and provisional implementation checks. Within the existing Contract, it proactively designs and runs applicable negative, boundary, and concurrency checks; it reports gaps and evidence. A check or fix outside released scope, or one requiring a new architecture decision, returns to the parent before action. Under the Multi-Agent route, create this child only after the normal release gates and only for actual code/configuration implementation or authorship/editing of this Skill's instructions/reference documents. It reads progressively and reports any fact that contradicts the parent's confirmed premises; it cannot take over the prerequisite instruction analysis, environment confirmation, or code-detail confirmation, or change unresolved goals, constraints, architecture, or acceptance criteria. It does not own final acceptance or non-trivial Git work. Apply the configured Worker summary cadence and complete message visibility without duplicating a complete final return.

### Context Bootstrap/Refresh Responsibility

When assigned, builds or refreshes a bounded, fingerprinted capsule of neutral project facts, exact source pointers, policy-routing pointers, and freshness data. It does not decide the task, change the Contract, implement, verify, materialize documentation, or delegate recursively. The capsule supplements mandatory instructions and never replaces direct reading of authoritative files.

### Change Verification Agent

When assigned, independently verifies the final state of a material change against the Contract and acceptance criteria. It uses the supplied scope evidence, runs relevant holistic and targeted checks, re-evaluates every final-state fingerprint/epoch, and reports evidence, gaps, failures, and risks. It is read-only for product code/configuration, documentation, and Git, except for explicitly named verification assets; it does not repair, make semantic decisions, or delegate.

### Documentation/Comments & Git Operations Agent

When assigned, performs only the explicitly released non-trivial Git slice. It does not change product behavior, tests, or semantic decisions; a conflict requiring new content or meaning returns to the parent. The root parent authors ordinary non-Skill documentation/comments, including documentation accompanying code changes; this work never triggers or consumes the reserved Primary Output slot. Authorship/editing of this Skill's instructions or reference documents may be assigned to the Primary Output child after all release gates, with parent review at Documentation and Acceptance. Git remains a separate execution scope.

## Codex CLI / ChatGPT Desktop optimizations

Under the default session audit policy, Worker keeps complete safe inbound and outbound messages visible in its own conversation and uses the configured Worker summary cadence. A complete final result already visible is not printed twice.

## Claude Code CLI / Claude Desktop optimizations

No provider-specific optimization instructions at present; follow the general rules above.
