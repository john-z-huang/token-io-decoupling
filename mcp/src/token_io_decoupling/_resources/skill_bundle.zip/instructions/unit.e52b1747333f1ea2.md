# unit.e52b1747333f1ea2

[English](unit.e52b1747333f1ea2.md) | [简体中文](unit.e52b1747333f1ea2_zh_cn.md)

Apply the current instruction and its included policy sections below. The current actions, guards, evidence and failure boundary are given directly. Before applying a named independent policy, obtain its exact instruction continuation; reuse any already held unit from this build and retain the affected action's return position. Do not retrieve author files or infer omitted policy. Check current facts and authorization before effects; an instruction is not a pass.

## Hard constraints

- Record hard user, runtime environment, repository, permission, safety, and Session constraints before acting.
- A task-level prohibition, such as “do not create subagents” or “do not use a browser,” remains active for the whole task.
- Computer Use is categorically forbidden: never control a computer, browser, or desktop app through its graphical interface — no screenshots to locate controls, mouse or keyboard simulation, clicking, accessibility APIs, window automation, remote-desktop control, or GUI scripting — and do not route such interaction through an API, CLI, MCP server, helper, or another Agent. Treat this as a blacklist rather than a list of allowed channels: every other tool, command, or capability actually exposed to and authorized for the current Session remains permitted. If a required step needs a forbidden operation, stop and report the blocker instead of attempting, delegating, or skipping it.
- Before route selection or any delegation/Session-topology work, the Mode checkpoint must compose and validate the delegation references; those references own conversation-level mode selection with a default Multi-Agent route and one-child budget, child counts, conditional creation, allocation, reuse, replacement, exceptions, and limits at their respective atomic boundaries. A reserved budget never initializes or authorizes a child by itself.
- Never invent authorization, capability, evidence, product support, or an executable route for an unmaintained scenario.
- Keep Core rules independent of product details; read Runtime and Model Provider Support (instruction continuation: [unit.081374cfbaa37b57](../instructions/unit.081374cfbaa37b57.md)) for supported runtime branches and model bindings.
- Read references on demand. Do not preload the entire Skill, `references/`, or raw project state merely because it may become useful.

## Entry

1. Complete the Contract checkpoint before route selection.
2. Identify the actual runtime environment, complete the Environment checkpoint, and establish or load the Environment capability inventory (instruction continuation: [unit.552ba8ac1f0543db](../instructions/unit.552ba8ac1f0543db.md)) for capability checks.
3. Pass the Mode checkpoint, which consumes the already established Environment capability inventory and composes the delegation references needed for the root-directive mode gate.
4. Call Route Entry (instruction continuation: [unit.8e91c00a9ae84af0](../instructions/unit.8e91c00a9ae84af0.md)) with current evidence that Contract, Environment, capability inventory, and Mode passed. Select exactly its authorized complete route, then pass released mode/count evidence to its first module checkpoint SM01/MM01. Each route composes Entry Readiness (instruction continuation: [unit.91c3169fc7104fb9](../instructions/unit.91c3169fc7104fb9.md)), Session Readiness (instruction continuation: [unit.33ed6b6bb3ad7509](../instructions/unit.33ed6b6bb3ad7509.md)), Work Definition (instruction continuation: [unit.ac408452f867a32d](../instructions/unit.ac408452f867a32d.md)), its mode-specific execution module, Verification and Repair (instruction continuation: [unit.5a2b2e6816a9f932](../instructions/unit.5a2b2e6816a9f932.md)), Documentation (instruction continuation: [unit.462150334fa7091a](../instructions/unit.462150334fa7091a.md)), and Delivery and Acceptance (instruction continuation: [unit.ebd34b94f9099296](../instructions/unit.ebd34b94f9099296.md)) in order. Load only the selected route and modules as reached.

All current and future routes consume Task Plan Memory Lifecycle (instruction continuation: [unit.c3c732f022fc8a5e](../instructions/unit.c3c732f022fc8a5e.md)) through Work Definition and their execution checkpoints. Pass the shared plan identity, current plan evidence and persistence confirmation, or documented restriction exception into execution; complete any content verification the owner requires. Record updates at owner-defined phase, handoff, pause, and completion boundaries, and record changes affecting authorization, scope, acceptance, direction, or dependent actions before those actions. Complete only after the matching plan lifecycle is resolved. An explicit planning request is unnecessary.

## Routes

- Single-Agent Coding (instruction continuation: [unit.607a3312e9d33c09](../instructions/unit.607a3312e9d33c09.md)): use when the released Mode selects `mode: Single-Agent Coding`; directive-related work stays in the current Session.
- Multi-Agent Coding (instruction continuation: [unit.c5de7d99acee1c66](../instructions/unit.c5de7d99acee1c66.md)): use when the released Mode selects Multi-Agent Coding with a locked positive `child_count`. The Mode checkpoint owns the four-option menu, default, and invalid-input handling; locking the budget does not initialize a child.

Do not load both routes. If a later material fact invalidates the selected route, stop the current slice, amend the Contract as needed, and return to Route Entry.

## Completion

Return `COMPLETE` only after the selected route reaches Acceptance with current evidence. Report unavailable checks, assumptions, residual risks, authorized effects, and the recorded delegation state. Do not cause external effects without explicit authorization.
