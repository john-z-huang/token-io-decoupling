# 输出物化

[English](fundamental-concepts--execution-planning--output-materialization.md) | [简体中文](fundamental-concepts--execution-planning--output-materialization_zh_cn.md)

下列直接给出当前动作、守卫、证据和失败边界。应用独立政策前，先按明确的指令继续入口取得对应单元；同一构建中已持有的单元直接复用，并保留受影响动作的准确恢复位置。不读取作者文件或推测缺失政策。执行副作用前核实当前事实与授权；指令内容可用不表示检查通过。

## 硬约束

- 采取行动前记录用户、运行环境、仓库、权限、安全和 Session 硬约束。
- “不要创建子代理”“不要使用浏览器”等任务级禁止条件在整个任务中持续有效。
- 绝对禁止 Computer Use：不得通过图形界面控制计算机、浏览器或桌面应用——包括以操纵控件为目的的截图、鼠标／键盘模拟、点击、辅助功能 API、窗口自动化、远程桌面控制或 GUI 脚本——也不得把此类交互包装为 API、CLI、MCP Server、辅助程序或其他 Agent 调用来绕过。本节是黑名单而非允许渠道清单：当前 Session 实际暴露且已获授权的其他工具、命令或能力仍然允许。若必需步骤需要借助被禁止的操作，应停止并报告阻塞，而不是尝试、委派或跳过。
- 路线选择或任何委派/Session 拓扑工作前，模式检查点必须组合并验证委派 references；这些 references 在各自的原子边界内规定会话级模式选择及默认多代理路线和单个子代理预算、子代理数量、条件创建、分配、复用、替换、例外和限制。预留预算本身不会初始化或授权创建子代理。
- 不得虚构授权、能力、证据、产品支持，或为未维护场景推导可执行路线。
- Core 规则不依赖具体产品；受支持的运行环境分支和模型绑定见[运行环境与模型厂商支持](../instructions/fundamental-concepts--session-runtime--runtime-provider-support_zh_cn.md)。
- 按需读取 reference。不要仅因为可能以后有用，就预加载整个 Skill、`references/` 或原始项目状态。

# 输出物化

## 通用规范

### 区分准备、审阅和应用

只有在当前调用中核实当前任务分配、操作专用授权、固定根目录、精确路径和必要安全能力后，才可准备输出。角色分配、工具发现、能力列表或普通写入权限均不能替代独立且匹配的授权。上下文或守卫缺失、过期、撤销或含糊时，应停止，不得猜测路径或能力。

准备会在项目目录外创建有界候选产物，不得称为项目写入。保留其标识符和清单哈希。只检查有界内容，并在应用前审阅候选内容。仅当重新核实当前权限、产物完整性、基线以及针对固定项目的新鲜整批预检后，才可应用同一候选内容。应用期间不得重新生成内容，也不得将先前预检视为当前授权。

仅使用有限的本地渲染模板和既定限制。任何可选语义服务只能在已提供的事实标识符中排序；本地代码保留原始事实并渲染输出。配置缺失、拒答、响应无效、上下文过期或超限时，准备应停止，不得替换成自由形式的输出。服务未报告用量时，不得推断用量为零。

应用仅限精确授权的路径和操作。重新检查当前文件状态，保留外部变更，并在部分或不确定结果后检查收据和实际文件。同一候选内容的重放不得覆盖用户后续变更。协作锁无法防止无关写入者并发修改；多文件批次可能只应用一部分，也不保证全局回滚。状态不确定或权限已变化时，应依据当前证据先解决问题，再准备新候选内容。

此能力是可选的。能力不可用时，可在自身授权路线允许的范围内继续 Native 输出工作。不得把不可用当作成功，也不得弱化相关角色、权限或验证 owner。

## Codex CLI / ChatGPT Desktop 特别优化指令

当前 MCP 操作为 `materialize_decoupled_output`，使用 `payload.request` 中的 `prepare`、`inspect` 或 `apply` 动作。它需要可信启动注入式授权 provider 提供当前 Worker 绑定和 assignment 上下文、单独的 operator grant、固定项目/产物根目录，以及必要的只读合规预检。服务核对该 provider 上下文与真实逐次调用 Worker 绑定一致，并在各阶段重新核验授权。工具 payload 不能选择或提供授权上下文。当前没有配置标准 provider；缺少可信 provider 或 grant 时能力不可用，不猜测默认根目录。

受支持角色为 `Primary Output`，输出类别为 `code_configuration`，政策范围为 `generic_project`。项目专属 Skill 作者维护属于私有开发 Skill；普通文档和其他角色/类别不受支持。政策版本 2 提供有限的 `literal_text`、`json_document` 和 `fact_markdown` 模板。`prepare` 在项目目录外保存候选内容；`inspect` 读取有界页面；`apply` 在写入前重新检查当前授权、任务分配、哈希、基线和整批预检。保留并传回同一个清单哈希。检查逐文件和批次收据，尤其是 `partial`、`conflict` 或 `uncertain`；不得假定存在回滚，也不得对变更后的内容重试。精确请求字段、限制和恢复分类由 MCP 输出物化契约管理。

可选的事实排序请求应遵循实际 MCP 工具元数据声明的固定 API 契约；模型只能返回已提供事实标识符的排序。该工具契约不会检查或改变 Agent Session 的模型。Agent 运行时、模型和推理力度绑定见 [Runtime and Model Provider Support](../instructions/fundamental-concepts--session-runtime--runtime-provider-support_zh_cn.md)。

## Claude Code CLI / Claude Desktop 特别优化指令

本项目 MCP Server 仅支持本地 Codex CLI。Claude 通用 MCP 能力不代表该 Server 支持直接连接，本 owner 也没有 Claude 专用直接工具优化。应依据当前会话实际暴露并授权的能力遵循通用规范。若此受控能力不可用，则使用任何独立获授权的直接输出路线及其验证要求。
