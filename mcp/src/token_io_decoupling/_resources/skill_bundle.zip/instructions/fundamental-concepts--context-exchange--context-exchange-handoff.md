# Coding Context Exchange Handoff

[English](fundamental-concepts--context-exchange--context-exchange-handoff.md) | [简体中文](fundamental-concepts--context-exchange--context-exchange-handoff_zh_cn.md)

Apply the current instruction and its included policy sections below. The current actions, guards, evidence and failure boundary are given directly. Before applying a named independent policy, obtain its exact instruction continuation; reuse any already held unit from this build and retain the affected action's return position. Do not retrieve author files or infer omitted policy. Check current facts and authorization before effects; an instruction is not a pass.

## Hard constraints

- Record hard user, runtime environment, repository, permission, safety, and Session constraints before acting.
- A task-level prohibition, such as “do not create subagents” or “do not use a browser,” remains active for the whole task.
- Computer Use is categorically forbidden: never control a computer, browser, or desktop app through its graphical interface — no screenshots to locate controls, mouse or keyboard simulation, clicking, accessibility APIs, window automation, remote-desktop control, or GUI scripting — and do not route such interaction through an API, CLI, MCP server, helper, or another Agent. Treat this as a blacklist rather than a list of allowed channels: every other tool, command, or capability actually exposed to and authorized for the current Session remains permitted. If a required step needs a forbidden operation, stop and report the blocker instead of attempting, delegating, or skipping it.
- Before route selection or any delegation/Session-topology work, the Mode checkpoint must compose and validate the delegation references; those references own conversation-level mode selection with a default Multi-Agent route and one-child budget, child counts, conditional creation, allocation, reuse, replacement, exceptions, and limits at their respective atomic boundaries. A reserved budget never initializes or authorizes a child by itself.
- Never invent authorization, capability, evidence, product support, or an executable route for an unmaintained scenario.
- Keep Core rules independent of product details; read [Runtime and Model Provider Support](../instructions/fundamental-concepts--session-runtime--runtime-provider-support.md) for supported runtime branches and model bindings.
- Read references on demand. Do not preload the entire Skill, `references/`, or raw project state merely because it may become useful.

# Coding Context Exchange Handoff

## General rules

### Context index and handoff records

Use `context-exchange/INDEX` for the parent-owned routing index and `context-exchange/workers/<worker-context-id>/INDEX` for a Worker's task, scope, status, latest material update, record names, and blocker/handoff target. Handoff records preserve achieved state, failed approaches with evidence, current changes and verification, blockers, next action, and exact authoritative source pointers. Update at material state/evidence/handoff changes, not after every command.

Map former handoff/import names to the same basename and subdirectory intent under `context-exchange/`. A successor reads only Memory names explicitly exposed in its released task; it must not write another Worker's names unless explicitly authorized. This is logical instruction ownership only, not technical isolation; Serena may expose records to any authorized Session. Never reconstruct a full transcript. If Memory tools are unavailable, report and block dependent work; do not fall back to files.

### Authorization boundary

A Context ID or memory name never authorizes creating/replacing an Agent or changing parent live task state. Keep mode/count/allocation/epoch state in its existing owner.

## Codex CLI / ChatGPT Desktop optimizations

Use only exposed, authorized Serena tools. Name the exact records in the released handoff, read only those records, verify source freshness, and confirm any write result. Thread/worktree transfer alone does not create or deliver a Memory handoff.

## Claude Code CLI / Claude Desktop optimizations

Use Serena MCP Memory only when exposed and authorized in the active Session; discover deferred MCP tools before relying on them. Claude resume/branch and auto memory do not authorize or deliver this record. If unavailable, follow the report/block rule.
