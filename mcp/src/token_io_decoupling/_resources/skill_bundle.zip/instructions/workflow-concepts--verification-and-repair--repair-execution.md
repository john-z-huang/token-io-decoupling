# Repair Execution Checkpoint

[English](workflow-concepts--verification-and-repair--repair-execution.md) | [简体中文](workflow-concepts--verification-and-repair--repair-execution_zh_cn.md)

Apply the current instruction and its included policy sections below. The current actions, guards, evidence and failure boundary are given directly. Before applying a named independent policy, obtain its exact instruction continuation; reuse any already held unit from this build and retain the affected action's return position. Do not retrieve author files or infer omitted policy. Check current facts and authorization before effects; an instruction is not a pass.

## Hard constraints

- Record hard user, runtime environment, repository, permission, safety, and Session constraints before acting.
- A task-level prohibition, such as “do not create subagents” or “do not use a browser,” remains active for the whole task.
- Computer Use is categorically forbidden: never control a computer, browser, or desktop app through its graphical interface — no screenshots to locate controls, mouse or keyboard simulation, clicking, accessibility APIs, window automation, remote-desktop control, or GUI scripting — and do not route such interaction through an API, CLI, MCP server, helper, or another Agent. Treat this as a blacklist rather than a list of allowed channels: every other tool, command, or capability actually exposed to and authorized for the current Session remains permitted. If a required step needs a forbidden operation, stop and report the blocker instead of attempting, delegating, or skipping it.
- Before route selection or any delegation/Session-topology work, the Mode checkpoint must compose and validate the delegation references; those references own conversation-level mode selection with a default Multi-Agent route and one-child budget, child counts, conditional creation, allocation, reuse, replacement, exceptions, and limits at their respective atomic boundaries. A reserved budget never initializes or authorizes a child by itself.
- Never invent authorization, capability, evidence, product support, or an executable route for an unmaintained scenario.
- Keep Core rules independent of product details; read [Runtime and Model Provider Support](../instructions/fundamental-concepts--session-runtime--runtime-provider-support.md) for supported runtime branches and model bindings.
- Read references on demand. Do not preload the entire Skill, `references/`, or raw project state merely because it may become useful.

# Repair Execution Checkpoint


This checkpoint owns execution of an authorized narrow repair and its focused checks. It consumes the scope-gate authorization; it does not diagnose failures, define authorization criteria, or create Verification epochs.

## Actions

1. Apply only the authorized repair within the released paths and mutations.
2. Run focused checks that directly exercise or inform that repair.
3. Return the changed paths, relevant check output, and any remaining issue to the parent boundary.

## Pass condition

The authorized narrow repair has been applied and its focused checks have passed or produced a concrete issue for the next owner.

## Boundary

This checkpoint does not diagnose failures, authorize scope changes, define final-state fingerprints or epochs, perform final Verification, write documentation, or perform Git effects.
