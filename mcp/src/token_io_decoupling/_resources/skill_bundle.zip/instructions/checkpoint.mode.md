# checkpoint.mode

[English](checkpoint.mode.md) | [简体中文](checkpoint.mode_zh_cn.md)

Apply the current instruction and its included policy sections below. The current actions, guards, evidence and failure boundary are given directly. Before applying a named independent policy, obtain its exact instruction continuation; reuse any already held unit from this build and retain the affected action's return position. Do not retrieve author files or infer omitted policy. Check current facts and authorization before effects; an instruction is not a pass.

## Hard constraints

- Record hard user, runtime environment, repository, permission, safety, and Session constraints before acting.
- A task-level prohibition, such as “do not create subagents” or “do not use a browser,” remains active for the whole task.
- Computer Use is categorically forbidden: never control a computer, browser, or desktop app through its graphical interface — no screenshots to locate controls, mouse or keyboard simulation, clicking, accessibility APIs, window automation, remote-desktop control, or GUI scripting — and do not route such interaction through an API, CLI, MCP server, helper, or another Agent. Treat this as a blacklist rather than a list of allowed channels: every other tool, command, or capability actually exposed to and authorized for the current Session remains permitted. If a required step needs a forbidden operation, stop and report the blocker instead of attempting, delegating, or skipping it.
- Before route selection or any delegation/Session-topology work, the Mode checkpoint must compose and validate the delegation references; those references own conversation-level mode selection with a default Multi-Agent route and one-child budget, child counts, conditional creation, allocation, reuse, replacement, exceptions, and limits at their respective atomic boundaries. A reserved budget never initializes or authorizes a child by itself.
- Never invent authorization, capability, evidence, product support, or an executable route for an unmaintained scenario.
- Keep Core rules independent of product details; read Runtime and Model Provider Support (instruction continuation: [unit.081374cfbaa37b57](../instructions/unit.081374cfbaa37b57.md)) for supported runtime branches and model bindings.
- Read references on demand. Do not preload the entire Skill, `references/`, or raw project state merely because it may become useful.

# Execution Mode Checkpoint


## Actions

1. Load the state record (instruction continuation: [unit.04519b62e6c4f711](../instructions/unit.04519b62e6c4f711.md)), mode confirmation (instruction continuation: [unit.afaf028a769ea19e](../instructions/unit.afaf028a769ea19e.md)), count gate (instruction continuation: [unit.36a14d319d1b638c](../instructions/unit.36a14d319d1b638c.md)), and re-entry (instruction continuation: [unit.5b0e93701a6ef118](../instructions/unit.5b0e93701a6ef118.md)) owners. Do not eagerly load child creation, dispatch, lifecycle, or reuse policies before their actual route step.
2. Confirm the parent-controlled record contains a selected mode and locked count, with `child_count: 0` and `allocations: []` for Single-Agent or exactly `child_count` reserved, initially unbound/unassigned/pending slots for Multi-Agent. If `mode_source: default`, verify Multi-Agent with `child_count: 1` and exactly one reserved slot. If `mode_source: timeout-default`, accept it only as a legacy readback and verify Single-Agent with `child_count: 0` and `allocations: []`; new conversations never use this source. Releasing this gate does **not** release a concrete Interaction Slice or authorize child creation.
3. For a later directive, reuse the locked mode/count; refresh task-specific evidence without reopening the mode/count gate. If required record/capability evidence is missing, block the dependent route. Role allocation and child operations are performed and checked at their designated route steps.

4. Verify that the authorized mode/count and evidence required by this gate are recorded. Advisory output cannot alter locked mode/count or reopen this gate; apply Decisions Advisory (instruction continuation: [unit.4d827a8a683055da](../instructions/unit.4d827a8a683055da.md)) for advisory policy.

## Pass condition

The parent record has exactly one valid released mode, a fixed count, valid reserved allocation shape where applicable, and sufficient entry capabilities. No concrete child or slice is assumed to have been released.

## Boundary

This checkpoint composes and validates the state-record, mode/count, and conditional child-dispatch references. It does not independently decide mode, topology, creation, allocation, reuse, exceptions, lifecycle, or count. The parent-controlled task record remains in its canonical conversation context and is read back under its owner.
