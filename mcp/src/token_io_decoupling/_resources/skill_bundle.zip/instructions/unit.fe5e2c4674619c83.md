# unit.fe5e2c4674619c83

[English](unit.fe5e2c4674619c83.md) | [简体中文](unit.fe5e2c4674619c83_zh_cn.md)

Apply the current instruction and its included policy sections below. The current actions, guards, evidence and failure boundary are given directly. Before applying a named independent policy, obtain its exact instruction continuation; reuse any already held unit from this build and retain the affected action's return position. Do not retrieve author files or infer omitted policy. Check current facts and authorization before effects; an instruction is not a pass.

## Hard constraints

- Record hard user, runtime environment, repository, permission, safety, and Session constraints before acting.
- A task-level prohibition, such as “do not create subagents” or “do not use a browser,” remains active for the whole task.
- Computer Use is categorically forbidden: never control a computer, browser, or desktop app through its graphical interface — no screenshots to locate controls, mouse or keyboard simulation, clicking, accessibility APIs, window automation, remote-desktop control, or GUI scripting — and do not route such interaction through an API, CLI, MCP server, helper, or another Agent. Treat this as a blacklist rather than a list of allowed channels: every other tool, command, or capability actually exposed to and authorized for the current Session remains permitted. If a required step needs a forbidden operation, stop and report the blocker instead of attempting, delegating, or skipping it.
- Before route selection or any delegation/Session-topology work, the Mode checkpoint must compose and validate the delegation references; those references own conversation-level mode selection with a default Multi-Agent route and one-child budget, child counts, conditional creation, allocation, reuse, replacement, exceptions, and limits at their respective atomic boundaries. A reserved budget never initializes or authorizes a child by itself.
- Never invent authorization, capability, evidence, product support, or an executable route for an unmaintained scenario.
- Keep Core rules independent of product details; read Runtime and Model Provider Support (instruction continuation: [unit.081374cfbaa37b57](../instructions/unit.081374cfbaa37b57.md)) for supported runtime branches and model bindings.
- Read references on demand. Do not preload the entire Skill, `references/`, or raw project state merely because it may become useful.

# Candidate Compliance Preflight

## General rules

### Review candidates against trusted current state

When an authorized workflow needs early candidate feedback, assess the bounded paths, operations, content envelope and baseline facts against a trusted checkout. A baseline records the observed file state; it is not a lock, write grant, or guarantee that the state remains unchanged.

The product preflight provides generic candidate path and baseline checks only. It does not select a project-specific authoring policy from the task label. The candidate payload must not choose its own trusted root or policy source; missing required trusted-reader or baseline evidence remains unknown rather than passing. Static envelope validity cannot replace current disk evidence.

Interpret each result separately as pass, fail, unknown, or not applicable. Treat unknown, failed, omitted due to a limit, and stale-baseline results as unresolved. Correct the cause or supply the missing evidence and repeat against current candidates. A successful preflight covers only the checks actually returned for that overlay and reader observation.

Preflight does not validate language-mirror presence, Markdown links or layer structure, prove semantic equivalence, execute repository code, authorize applying files, or replace current-state Verification and Acceptance. Run the target repository's own required documentation, language and other checks through actually available authorized capabilities. This project's author-document validators belong to its private development workflow, not the installed product; using the product on another repository never requires access to that private directory. Complete applicable authoritative target checks after applying changes.

## Codex CLI / ChatGPT Desktop optimizations

When exposed and authorized, call `validate_decoupling_compliance` with `payload.request.policy_scope: generic_project` and the exact candidate paths, operations, content and baselines. This is the product's sole supported policy scope. The trusted root, enabled service scope and read-only baseline reader come from operator startup configuration; neither the request nor current directory chooses them. Inspect the returned `policy_scope` and `policy_version: 2`. The tool does not write files, run subprocesses, execute candidate code or call an API.

For every task, including Skill maintenance, inspect only the generic path/baseline findings actually returned and review `not_evaluated`. Do not expect this tool to perform bilingual, Markdown, layer or target-project semantic checks. Resolve `unknown`, `fail`, truncation or budget findings before proceeding. A passing result is not authorization; obtain write authority independently, recheck current state before applying, and retain the target repository's separate required checks.

## Claude Code CLI / Claude Desktop optimizations

This repository's MCP Server supports local Codex CLI only; generic Claude MCP support does not authorize direct use of this server. No Claude-specific direct-tool optimization is maintained here. Follow general rules using only capabilities actually exposed and authorized in the current Session; if a trusted reader is unavailable, mark disk-dependent checks unknown and use the applicable established verification route.
