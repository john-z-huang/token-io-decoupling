# unit.f56021d97f9b69f7

[English](unit.f56021d97f9b69f7.md) | [简体中文](unit.f56021d97f9b69f7_zh_cn.md)

Apply the current instruction and its included policy sections below. The current actions, guards, evidence and failure boundary are given directly. Before applying a named independent policy, obtain its exact instruction continuation; reuse any already held unit from this build and retain the affected action's return position. Do not retrieve author files or infer omitted policy. Check current facts and authorization before effects; an instruction is not a pass.

## Hard constraints

- Record hard user, runtime environment, repository, permission, safety, and Session constraints before acting.
- A task-level prohibition, such as “do not create subagents” or “do not use a browser,” remains active for the whole task.
- Computer Use is categorically forbidden: never control a computer, browser, or desktop app through its graphical interface — no screenshots to locate controls, mouse or keyboard simulation, clicking, accessibility APIs, window automation, remote-desktop control, or GUI scripting — and do not route such interaction through an API, CLI, MCP server, helper, or another Agent. Treat this as a blacklist rather than a list of allowed channels: every other tool, command, or capability actually exposed to and authorized for the current Session remains permitted. If a required step needs a forbidden operation, stop and report the blocker instead of attempting, delegating, or skipping it.
- Before route selection or any delegation/Session-topology work, the Mode checkpoint must compose and validate the delegation references; those references own conversation-level mode selection with a default Multi-Agent route and one-child budget, child counts, conditional creation, allocation, reuse, replacement, exceptions, and limits at their respective atomic boundaries. A reserved budget never initializes or authorizes a child by itself.
- Never invent authorization, capability, evidence, product support, or an executable route for an unmaintained scenario.
- Keep Core rules independent of product details; read Runtime and Model Provider Support (instruction continuation: [unit.081374cfbaa37b57](../instructions/unit.081374cfbaa37b57.md)) for supported runtime branches and model bindings.
- Read references on demand. Do not preload the entire Skill, `references/`, or raw project state merely because it may become useful.

# Workflow module entry resolution


This checkpoint owns readiness resolution for an invocation of one bounded workflow module. It processes the caller's declared requirements; it does not select or enumerate modules, define Layer-04 module contracts, or schedule routes.

## Trigger and inputs

Use when a caller requests a module to begin or resume work. The caller supplies the task and authorized scope, the applicable released route/mode evidence, the module's declared prerequisite owners and evidence requirements, current Session state, relevant evidence and epochs, the suspended position if resuming, and the status of prior effects. A first direct invocation may have no continuation history or top-level route; the current caller can establish continuation in its available context. Apply Workflow Module Contract (instruction continuation: [unit.5f87a6226da5190b](../instructions/unit.5f87a6226da5190b.md)), plus the relevant Contract (instruction continuation: [unit.e452c36c913b5771](../instructions/unit.e452c36c913b5771.md)), Environment (instruction continuation: [unit.b92847af78d7f2a7](../instructions/unit.b92847af78d7f2a7.md)), capability inventory (instruction continuation: [unit.552ba8ac1f0543db](../instructions/unit.552ba8ac1f0543db.md)), Mode (instruction continuation: [unit.bba9c45137f16455](../instructions/unit.bba9c45137f16455.md)), and direct prerequisite owners.

## Decision and result

1. Confirm the requested scope and applicable mode are current and authorized. A released Mode is evidence to consume, not a reason to ask again or change the route. Do not repeat a completed prompt or effect.
2. Check only the declared prerequisites and the caller's suspended position. Verify evidence source, freshness, relevant epoch, required capability, and effect status against their direct owners. If an authorized read-only source can establish missing evidence, retrieve only that bounded evidence and record its provenance.
3. Return `ready` with the verified evidence, current epochs, and permitted-effect boundary when the module can safely start or resume. `ready` is only the entry preflight result; the module must still return its own `complete`, `not_applicable` with reason, `needs_prerequisite`, or `blocked` result. An unresolved pending owner result is not ready for dependent work and cannot be treated as complete. Readiness is not authorization beyond the caller's existing scope and does not imply module or route completion.
4. Return `needs_prerequisite` with the semantic owner, missing evidence, and suspended module/substep when required evidence is missing but no block condition applies. The caller, including a direct caller without a top-level route, decides where to resume; this checkpoint does not route to a module or restart unrelated gates.
5. Return `blocked` when authorization or mode conflicts, a required capability/evidence source is unavailable, a required continuation position cannot be preserved or recovered, caller state is contradictory, prerequisite resolution repeats without new evidence/relevant epoch progress/valid owner-state change, or prior effect status cannot be resolved by authorized readback. The absence of continuation history on first entry is not by itself a block. Preserve the current state and do not retry, replay, or infer a safe continuation. Owner-directed repair and re-verification may continue when their evidence or epochs advance.

## Failure boundary

This checkpoint may verify or obtain authorized read-only evidence. The current caller may establish a continuation record on first direct entry; this checkpoint does not require a route or external persistence mechanism. It does not create or mutate a prerequisite, expand scope, reselect Mode, issue prompts, create Agents, dispatch work, perform Git operations, or choose a later module. Any write needed to establish a prerequisite requires its existing authorization and must return through the caller's normal gate. Missing or stale evidence blocks only the dependent module work; it does not authorize skipping its declared owner.
