# Coding 子代理消息可见性

[English](fundamental-concepts--delegation--delegation-child-message-visibility.md) | [简体中文](fundamental-concepts--delegation--delegation-child-message-visibility_zh_cn.md)

下列直接给出当前动作、守卫、证据和失败边界。应用独立政策前，先按明确的指令继续入口取得对应单元；同一构建中已持有的单元直接复用，并保留受影响动作的准确恢复位置。不读取作者文件或推测缺失政策。执行副作用前核实当前事实与授权；指令内容可用不表示检查通过。

## 硬约束

- 采取行动前记录用户、运行环境、仓库、权限、安全和 Session 硬约束。
- “不要创建子代理”“不要使用浏览器”等任务级禁止条件在整个任务中持续有效。
- 绝对禁止 Computer Use：不得通过图形界面控制计算机、浏览器或桌面应用——包括以操纵控件为目的的截图、鼠标／键盘模拟、点击、辅助功能 API、窗口自动化、远程桌面控制或 GUI 脚本——也不得把此类交互包装为 API、CLI、MCP Server、辅助程序或其他 Agent 调用来绕过。本节是黑名单而非允许渠道清单：当前 Session 实际暴露且已获授权的其他工具、命令或能力仍然允许。若必需步骤需要借助被禁止的操作，应停止并报告阻塞，而不是尝试、委派或跳过。
- 路线选择或任何委派/Session 拓扑工作前，模式检查点必须组合并验证委派 references；这些 references 在各自的原子边界内规定会话级模式选择及默认多代理路线和单个子代理预算、子代理数量、条件创建、分配、复用、替换、例外和限制。预留预算本身不会初始化或授权创建子代理。
- 不得虚构授权、能力、证据、产品支持，或为未维护场景推导可执行路线。
- Core 规则不依赖具体产品；受支持的运行环境分支和模型绑定见[运行环境与模型厂商支持](../instructions/fundamental-concepts--session-runtime--runtime-provider-support_zh_cn.md)。
- 按需读取 reference。不要仅因为可能以后有用，就预加载整个 Skill、`references/` 或原始项目状态。

# Coding 子代理消息可见性

## 通用规范

### 按配置展示；依赖前取得完整正文

按[会话审计可见性](../instructions/fundamental-concepts--session-runtime--session-audit-visibility_zh_cn.md)预设执行。Worker 必须在自身会话中完整展示安全的入站和出站正文。Root 消息按预设展示预览、摘要或全文；要求全文时，发送前须完整展示安全正文并确认与载荷完全一致。Worker 已完整可见的最终结果就是出站副本，不得重复打印。

收到消息后，Root 在依赖前必须取得并完整阅读实际返回正文；再按预设在主要会话中展示完整安全正文或摘要。工具调用卡片、活动事件、送达回执、任务状态或“消息已发送”等通知不等同于消息正文，不能代替正文。

按职责或预设要求完整展示时，过长正文可拆分为连续编号的部分展示，不得概述或截断；如需遮蔽内容，应明确标记。若运行环境未显示实际正文，且无法从会话记录复现，则不得将该消息用于依赖工作。

### 保留方向与证据

注明每条消息的方向；运行环境提供身份时，同时注明目标或来源子代理。将正文与评论清楚区分。转述、摘要或声称内容已发送/收到，均不能作为消息正文的证据。

## Codex CLI / ChatGPT Desktop 特别优化指令

### 使用当前会话暴露的消息工具

当前 Session 暴露并授权使用 `collaboration.send_message` 时，按已配置预设执行。Worker 保持安全收发正文完整可见；Root 出站全文必须匹配载荷。Root 始终完整读取实际返回正文后再依赖，展示内容由预设决定。无法从会话记录复现实际正文时，阻塞依赖工作。可见副本不证明原始传输字节。

## Claude Code CLI / Claude Desktop 特别优化指令

### 使用已暴露的 SendMessage

Anthropic 的 [Agent Teams 文档](https://code.claude.com/docs/en/agent-teams)将 `SendMessage` 说明为代理间发送消息的工具。当前 Session 暴露并授权使用时，遵循通用配置预设。Worker 保留安全收发正文完整可见性；Root 在依赖前完整读取实际返回正文，展示方式按预设执行。可见副本不证明原始传输字节。若未暴露 `SendMessage`，不得假设其存在；仍须满足通用证据要求。
