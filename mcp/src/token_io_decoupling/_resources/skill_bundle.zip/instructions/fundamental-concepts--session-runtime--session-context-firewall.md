# Coding Session Context Firewall

[English](fundamental-concepts--session-runtime--session-context-firewall.md) | [简体中文](fundamental-concepts--session-runtime--session-context-firewall_zh_cn.md)

Apply the current instruction and its included policy sections below. The current actions, guards, evidence and failure boundary are given directly. Before applying a named independent policy, obtain its exact instruction continuation; reuse any already held unit from this build and retain the affected action's return position. Do not retrieve author files or infer omitted policy. Check current facts and authorization before effects; an instruction is not a pass.

## Hard constraints

- Record hard user, runtime environment, repository, permission, safety, and Session constraints before acting.
- A task-level prohibition, such as “do not create subagents” or “do not use a browser,” remains active for the whole task.
- Computer Use is categorically forbidden: never control a computer, browser, or desktop app through its graphical interface — no screenshots to locate controls, mouse or keyboard simulation, clicking, accessibility APIs, window automation, remote-desktop control, or GUI scripting — and do not route such interaction through an API, CLI, MCP server, helper, or another Agent. Treat this as a blacklist rather than a list of allowed channels: every other tool, command, or capability actually exposed to and authorized for the current Session remains permitted. If a required step needs a forbidden operation, stop and report the blocker instead of attempting, delegating, or skipping it.
- Before route selection or any delegation/Session-topology work, the Mode checkpoint must compose and validate the delegation references; those references own conversation-level mode selection with a default Multi-Agent route and one-child budget, child counts, conditional creation, allocation, reuse, replacement, exceptions, and limits at their respective atomic boundaries. A reserved budget never initializes or authorizes a child by itself.
- Never invent authorization, capability, evidence, product support, or an executable route for an unmaintained scenario.
- Keep Core rules independent of product details; read [Runtime and Model Provider Support](../instructions/fundamental-concepts--session-runtime--runtime-provider-support.md) for supported runtime branches and model bindings.
- Read references on demand. Do not preload the entire Skill, `references/`, or raw project state merely because it may become useful.

# Coding Session Context Firewall

## General rules

### Raw-state ingress

In a multi-Session Coding run, the input-side Session reads only bounded, read-only environment and code evidence needed for the prerequisite confirmations owned by [session role ownership](../instructions/fundamental-concepts--session-runtime--session-role-ownership.md), not an open-ended repository scan. Primary Output consumes further source/configuration state only within released scope; Change Verification consumes final-state evidence; Documentation/Comments & Git Operations consumes Git state and approved documentation scope. Each returns only next-decision facts and exact source pointers.

Raw-state ingress is bounded by potential output volume, state sensitivity, and repository impact, not the command name. A single Session has no cross-Session firewall but still reads progressively and compresses raw state.

### Semantic ownership and ephemeral localization

The firewall limits raw-state ingress without transferring semantic authority; follow [session role ownership](../instructions/fundamental-concepts--session-runtime--session-role-ownership.md). Temporary project-localization facts are not automatically promoted to long-lived Contract state, and raw state must not be dumped. Authorized reusable context records may be persisted as named project Memories under [Coding Context Exchange](../instructions/fundamental-concepts--context-exchange--context-exchange.md) and [Coding Context Exchange Workspace Boundary](../instructions/fundamental-concepts--context-exchange--context-exchange-workspace-boundary.md); memory names express logical ownership only and provide no technical isolation.

## Codex CLI / ChatGPT Desktop optimizations

Codex custom agent profiles may narrow source/tool exposure with `sandbox_mode: read-only` and selected `mcp_servers`; `developer_instructions` can request bounded source pointers but is not a permission boundary. Inspect inherited settings because omitted custom-agent fields inherit the parent. These settings are not Claude's `tools`/`disallowedTools` frontmatter and do not imply Claude Desktop Chat's connector Tool-access mode. [OpenAI: custom subagents](https://learn.chatgpt.com/docs/agent-configuration/subagents).

### Local bounded tools and Skill/MCP disclosure

Do not reread unchanged owners or retrieve history already present in the active context. Prefer stable context plus a small delta. When tool output repeats the same payload in `content` and `structuredContent`, retain only the representation needed for the next decision; preserve distinct evidence and source pointers.

Use the runtime's exposed local code-search/file-reading tools for targeted symbols and small source ranges, returning stable paths and evidence pointers instead of complete build logs or recursive repository dumps. For Codex role-specific access, a reviewed custom agent may set `sandbox_mode: read-only` and narrow `mcp_servers`; an omitted key can inherit parent settings and a live permission override can affect the spawned child. Local Codex skills reveal metadata first, load `SKILL.md` when selected and references only on demand; select only concept owners needed by the current slice. The CLI/IDE/Desktop Codex host can share MCP configuration; `/mcp` verifies available connections. Do not treat a plugin or a separate Chat Session's tool access as a separate Codex child or a permission grant. [OpenAI: skills progressive disclosure](https://learn.chatgpt.com/docs/build-skills), [OpenAI: MCP host configuration](https://learn.chatgpt.com/docs/extend/mcp), [OpenAI: custom agents](https://learn.chatgpt.com/docs/agent-configuration/subagents).

## Claude Code CLI / Claude Desktop optimizations

### Native bounded reads and deferred MCP discovery

On local Claude Code, start repository localization with targeted `Glob`/`Grep` and small `Read` ranges, then return paths, line pointers, and compressed facts; do not route an entire recursive listing or build log through the parent. MCP Tool Search is enabled by default: Claude Code defers MCP tool definitions and loads them when needed. If `ANTHROPIC_BASE_URL` points to a non-first-party host, Claude Code normally disables Tool Search because most proxies do not forward `tool_reference` blocks; for a new session, launch with `ENABLE_TOOL_SEARCH=true claude` only when the model and proxy support those blocks. Microsoft Foundry deployments hosted on Azure reject Tool Search server-side, so the environment forces upfront loading and the variable cannot override it. `CLAUDE_CODE_DISABLE_EXPERIMENTAL_BETAS` also keeps Tool Search disabled and cannot be overridden with `ENABLE_TOOL_SEARCH`. When Tool Search is unavailable, expect MCP tools to load upfront and do not claim deferred-loading savings. An authorized desktop extension/local MCP server may expose local resources in Desktop Chat, whereas a remote connector accesses its remote service; in both cases inspect the actual tool scope and avoid assuming local shell, unrestricted filesystem, or an independent Agent.

Official references: [MCP Tool Search in Claude Code](https://code.claude.com/docs/en/mcp), [Desktop connector boundary](https://support.claude.com/en/articles/11725091-when-to-use-desktop-and-web-connectors), [local MCP extension](https://support.claude.com/en/articles/10949351-getting-started-with-local-mcp-servers-on-claude-desktop).

A Claude Code project/user custom subagent can scope an inline `mcpServers` definition to the child, keeping unneeded tool descriptions out of the parent context; plugin-shipped agent definitions do not necessarily honor that field. Inspect the MCP tools directly exposed to a Desktop Agent Session and use only those needed and authorized for its released slice. [Anthropic: subagent MCP scope](https://code.claude.com/docs/en/sub-agents).
