# unit.b0e2251c1172aa52

[English](unit.b0e2251c1172aa52.md) | [简体中文](unit.b0e2251c1172aa52_zh_cn.md)

Apply the current instruction and its included policy sections below. The current actions, guards, evidence and failure boundary are given directly. Before applying a named independent policy, obtain its exact instruction continuation; reuse any already held unit from this build and retain the affected action's return position. Do not retrieve author files or infer omitted policy. Check current facts and authorization before effects; an instruction is not a pass.

## Hard constraints

- Record hard user, runtime environment, repository, permission, safety, and Session constraints before acting.
- A task-level prohibition, such as “do not create subagents” or “do not use a browser,” remains active for the whole task.
- Computer Use is categorically forbidden: never control a computer, browser, or desktop app through its graphical interface — no screenshots to locate controls, mouse or keyboard simulation, clicking, accessibility APIs, window automation, remote-desktop control, or GUI scripting — and do not route such interaction through an API, CLI, MCP server, helper, or another Agent. Treat this as a blacklist rather than a list of allowed channels: every other tool, command, or capability actually exposed to and authorized for the current Session remains permitted. If a required step needs a forbidden operation, stop and report the blocker instead of attempting, delegating, or skipping it.
- Before route selection or any delegation/Session-topology work, the Mode checkpoint must compose and validate the delegation references; those references own conversation-level mode selection with a default Multi-Agent route and one-child budget, child counts, conditional creation, allocation, reuse, replacement, exceptions, and limits at their respective atomic boundaries. A reserved budget never initializes or authorizes a child by itself.
- Never invent authorization, capability, evidence, product support, or an executable route for an unmaintained scenario.
- Keep Core rules independent of product details; read Runtime and Model Provider Support (instruction continuation: [unit.081374cfbaa37b57](../instructions/unit.081374cfbaa37b57.md)) for supported runtime branches and model bindings.
- Read references on demand. Do not preload the entire Skill, `references/`, or raw project state merely because it may become useful.

# Coding Execution Control

## General rules

### Interaction Slice

Release one **Interaction Slice** at a time for non-simple work. Every slice states:

- `Objective`: the result it must produce;
- `Authorized scope/mutations`: paths, behavior, and writes allowed;
- `Return conditions`: the evidence or milestone that ends it;
- `Unreleased boundary`: the next subsystem, risk domain, semantic choice, or mutation that remains blocked.

A slice is a control unit, not a command-by-command script. The executor may continue through low-decision-density mechanics while the Contract and boundary remain unchanged. It must pause at the return conditions or before crossing the unreleased boundary. A simple fast-path task may remain one slice through implementation and focused checks.

### Slice ordering

Release slices in parallel only when they are independent and non-conflicting. Dependencies, shared write targets, or ordered results require sequential release. Context transport and parent-only feedback follow their respective owner protocols and are not defined here.

### Control Checkpoint

At a material boundary, consume the Progress Signal owned by execution stage feedback (instruction continuation: [unit.1199cd05bec7fedb](../instructions/unit.1199cd05bec7fedb.md)), append the current `Unreleased boundary`, and make one final control choice: `Continue`, `Amend`, or `Stop`. Focus Control on material deviation, new evidence, or an actual boundary; do not turn a released slice into per-command approvals or repeat unchanged status. `Continue` releases only the next bounded slice; `Amend` changes the Contract or boundary before work resumes. `Evidence-on-Demand` is an intermediate evidence request that pauses release and returns to this checkpoint; it is not a fourth final authorization outcome. In a Single-Agent route, this is an internal reasoning pause, not a simulated self-message.

## Codex CLI / ChatGPT Desktop optimizations

Where enabled, Codex `PreToolUse` can deny a supported `Bash`, edit, or MCP call before it executes; `PostToolUse` is observation **after** the call. Codex's plan/read-only or other permission modes are tool controls, not this Skill's `Continue` decision. Coverage has exceptions, so do not use a hook as the only proof of a filesystem or semantic authorization boundary. [OpenAI: hooks](https://learn.chatgpt.com/docs/hooks).

### Native approvals and focused review

Before relying on a non-managed Codex hook, inspect and trust its exact definition; in a CLI session that exposes it, run `/hooks` to review or trust configured hooks. A `PreToolUse` command hook denies a supported local call by writing this JSON to stdout:

```json
{
  "hookSpecificOutput": {
    "hookEventName": "PreToolUse",
    "permissionDecision": "deny",
    "permissionDecisionReason": "Explain the blocked operation."
  }
}
```

For this event, `continue: false` is unsupported and the tool call continues after the hook error; `PostToolUse` runs after the effect and cannot retroactively approve it. At a stage boundary, an Agent must inspect the actual working-tree diff with an authorized read-only diff tool, or invoke `/diff` in a Codex CLI session that exposes the command. `/diff` includes staged, unstaged, and untracked changes. The parent still makes the semantic `Continue`/`Amend`/`Stop` choice under the general rules. [OpenAI: PreToolUse output contract](https://learn.chatgpt.com/docs/hooks), [OpenAI: code review](https://learn.chatgpt.com/docs/code-review), [OpenAI: CLI diff](https://learn.chatgpt.com/docs/developer-commands).

## Claude Code CLI / Claude Desktop optimizations

### Tool-boundary guard versus semantic Control

An authorized Claude Code `PreToolUse` hook runs after tool parameters are formed and before the call. It receives JSON on stdin with `tool_name`, `tool_input`, and `tool_use_id`; the hook group's `matcher` filters `tool_name`. To deny a call, write this JSON to stdout:

```json
{
  "hookSpecificOutput": {
    "hookEventName": "PreToolUse",
    "permissionDecision": "deny",
    "permissionDecisionReason": "Explain the blocked operation."
  }
}
```

Exit code 0 with no output leaves the normal permission flow in place; it does not approve the call. A `Stop` hook can request a final evidence check before the current agent finishes. These are *guards*, not an alternate authority for deciding `Continue`, `Amend`, or `Stop`: the parent must still consume the Progress Signal and authorize each new slice under the general rules. Hook decisions or an MCP connector must not silently enlarge the Contract or child budget. Use native Hooks only in a Claude Code runtime where they are actually exposed and authorized.

Official reference: [Claude Code Hooks and decisions](https://code.claude.com/docs/en/hooks).

In Claude Code, `PostToolUse` reports observations after an action; it cannot authorize that action retroactively. [Anthropic: hooks](https://code.claude.com/docs/en/hooks).
