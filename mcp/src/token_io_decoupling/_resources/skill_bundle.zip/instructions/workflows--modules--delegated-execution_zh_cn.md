# Multi-Agent 委派执行模块

[English](workflows--modules--delegated-execution.md) | [简体中文](workflows--modules--delegated-execution_zh_cn.md)

下列直接给出当前动作、守卫、证据和失败边界。应用独立政策前，先按明确的指令继续入口取得对应单元；同一构建中已持有的单元直接复用，并保留受影响动作的准确恢复位置。不读取作者文件或推测缺失政策。执行副作用前核实当前事实与授权；指令内容可用不表示检查通过。

## 硬约束

- 采取行动前记录用户、运行环境、仓库、权限、安全和 Session 硬约束。
- “不要创建子代理”“不要使用浏览器”等任务级禁止条件在整个任务中持续有效。
- 绝对禁止 Computer Use：不得通过图形界面控制计算机、浏览器或桌面应用——包括以操纵控件为目的的截图、鼠标／键盘模拟、点击、辅助功能 API、窗口自动化、远程桌面控制或 GUI 脚本——也不得把此类交互包装为 API、CLI、MCP Server、辅助程序或其他 Agent 调用来绕过。本节是黑名单而非允许渠道清单：当前 Session 实际暴露且已获授权的其他工具、命令或能力仍然允许。若必需步骤需要借助被禁止的操作，应停止并报告阻塞，而不是尝试、委派或跳过。
- 路线选择或任何委派/Session 拓扑工作前，模式检查点必须组合并验证委派 references；这些 references 在各自的原子边界内规定会话级模式选择及默认多代理路线和单个子代理预算、子代理数量、条件创建、分配、复用、替换、例外和限制。预留预算本身不会初始化或授权创建子代理。
- 不得虚构授权、能力、证据、产品支持，或为未维护场景推导可执行路线。
- Core 规则不依赖具体产品；受支持的运行环境分支和模型绑定见[运行环境与模型厂商支持](../instructions/fundamental-concepts--session-runtime--runtime-provider-support_zh_cn.md)。
- 按需读取 reference。不要仅因为可能以后有用，就预加载整个 Skill、`references/` 或原始项目状态。

# Multi-Agent 委派执行模块


本 Layer-04 模块组合 Bootstrap 评估与 Root 任务授权、执行者/输出/角色决策、所有执行者共用的当前 Slice 门禁、有条件的子代理创建与派发、实施/结果处理、阶段反馈及 Control。它返回实施状态与初步证据；最终验证属于后续验证/修复工作流。

## 入口声明

| 字段 | 要求 |
| --- | --- |
| 必需输入 | 当前已授权 Contract/任务、已释放 Multi-Agent 模式和正数锁定数量、完整且当前的 Session/审计、有来源的 Context 和 Decision、当前 allocation/角色事实、continuation/效果状态、恢复底线/Control 证据；仅在恢复既有已释放 Worker bundle 时，还须提供该 bundle 记录的显式 `write_content_memo` 值。新 Worker bundle 的显式值在 DE04 确定。 |
| 允许效果 | 评估 Bootstrap 并授权实际任务；解析执行者/输出/角色；释放和持久化已授权 Slice；有条件地创建/复用子代理并只派发该任务；本地实施或接收子代理实际结果；提供阶段反馈并解决 Control。所有效果仍受直接 owners 和现有授权约束。 |
| 结果 | 仅在返回当前实施/结果状态、指纹、初步检查、Control 处置且无待处理恢复/下一 Slice 时返回 `complete`；否则以 continuation 返回 `needs_prerequisite` 或 `blocked`。条件子代理、角色、memo 及受控输出子步骤可根据观察到的原因标为 `not_applicable`。 |
| 新鲜度 | 将任务/Slice 指纹、Contract/Decision、当前父级控制任务记录和分配证据、子代理身份、显式 memo 值、Control 规则及相关 epoch 绑定到其来源。实质变化会使受影响证据失效，并要求从受影响检查点重新进入。 |

## 工作流路线图


## 有序模块清单

1. **DE00 — 解析入口。** 提供本声明、当前授权及已释放路线/模式/count 证据、完整 Session/审计与 Context/Decision 证据、allocation、先前效果、恢复状态及 continuation，调用[模块入口解析](../instructions/workflow-checkpoints--module-entry-resolution_zh_cn.md)。恢复既有已释放 Worker bundle 时，提供其记录的显式 memo 值；新 bundle 的值在 DE04 确定。`ready` 只允许模块核验。证据缺失时连同 owner/位置返回 `needs_prerequisite`；冲突、状态不安全或效果无法恢复时返回 `blocked`。
2. **DE01 — 评估 Bootstrap 并授权实际任务。** 根据当前任务、角色、名额和 Memory 事实应用[Bootstrap 选择](../instructions/workflow-checkpoints--bootstrap-selection_zh_cn.md)。建议不预留角色，也不释放 Slice。Root 重核当前 Context 和 Decision，然后明确授权实际任务：适用时采用有界 Bootstrap/Refresh 任务，否则采用原任务。独立辅助 Bootstrap 任务需要 Root 另行授权，并将原任务保留为 continuation；辅助任务完成后返回 DE01，单独授权并评估原任务，不得依据辅助结果将原任务标为完成。实际任务缺少授权时阻塞。
3. **DE02 — 分别解析执行者和输出。** 应用[任务分配](../instructions/fundamental-concepts--execution-planning--task-assignment_zh_cn.md)和[执行者选择](../instructions/workflow-checkpoints--executor-selection_zh_cn.md)，再应用[输出 Token 路由](../instructions/fundamental-concepts--execution-planning--output-token-routing_zh_cn.md)及[输出路由选择](../instructions/workflow-checkpoints--output-route-selection_zh_cn.md)。仅当执行者结果为 `new-executor-needed` 且 Root 输出已处置时进入 DE03。已确认 Root 执行者或已确认的现有执行者/子代理，必须先确认输出已处置，再根据该证据将角色预留记录为 `not_applicable` 并继续至 DE04。必需结果未知或未解决时返回 `needs_prerequisite`；冲突则阻塞。不得把未解决视为 `not_applicable`。
4. **DE03 — 仅为新执行者预留角色。** 仅在 DE02 的 `new-executor-needed` 且输出已处置分支，应用[角色预留](../instructions/workflow-checkpoints--role-reservation_zh_cn.md)、[子代理角色选择](../instructions/fundamental-concepts--delegation--child-role-selection_zh_cn.md)、[子代理职责分配](../instructions/fundamental-concepts--delegation--delegation-child-role-allocation_zh_cn.md)、[委派数量门禁](../instructions/fundamental-concepts--delegation--delegation-mode-count-gate_zh_cn.md)和[委派状态记录](../instructions/fundamental-concepts--delegation--delegation-state-record_zh_cn.md)。确认唯一且当前有效的预留，以及容量/allocation 证据。必需证据缺失时返回 `needs_prerequisite`；不一致或未授权时阻塞。不得为 Root 或现有执行者再次预留。
5. **DE04 — 应用共用 Control 门禁并释放当前 Slice。** 所有实际执行者分支都经过此检查点。应用[执行控制](../instructions/fundamental-concepts--execution-control--execution-control_zh_cn.md)、[执行规划](../instructions/fundamental-concepts--execution-planning--execution-planning_zh_cn.md)和[委派状态记录](../instructions/fundamental-concepts--delegation--delegation-state-record_zh_cn.md)。实质变化会使依赖它的 Control 证据失效；释放/恢复前返回 DE08 并重新评估当前事实。`Stop` 会阻塞。子代理执行时核验当前容量/allocation；Root 执行时记录附有理由的子代理容量 `not_applicable`。仅当 Context 和 Decision 当前有效，并明确目标、已授权执行者/角色、范围/修改、返回条件、未释放边界及新 Worker bundle 的显式 memo 值时，才释放具体 Slice。恢复既有 bundle 时保留并核验记录值。子代理行动前按 owner 更新并回读规范 parent-context 记录。若无实质 Control 变化，记录附有理由的 `not_applicable`。释放前应用[任务计划 Memory 生命周期](../instructions/fundamental-concepts--execution-planning--task-plan-memory-lifecycle_zh_cn.md)；必需证据、持久化或核验失败时阻塞依赖工作。
6. **DE05 — 创建新合格子代理并绑定身份。** 仅对新子代理应用[子代理创建](../instructions/fundamental-concepts--delegation--delegation-child-creation_zh_cn.md)和[运行环境与模型厂商支持](../instructions/fundamental-concepts--session-runtime--runtime-provider-support_zh_cn.md)。确认符合条件的已释放任务/Slice、唯一角色预留、当前容量、能力、权限、上下文、返回条件及必需运行环境/effort 证据；只创建已授权子代理。派发前按 owner 将其真实身份/allocation 写入并回读规范 parent-context 记录。复用现有子代理时，根据复用证据将创建和新 model-binding 检查记录为 `not_applicable`；保留相同身份，不重查模型选择，也绝不替换。已确认 Root 执行时，将子代理创建/身份记录为有原因的 `not_applicable`。所有分支进入 DE07；子代理分支先经过 DE06。
7. **DE06 — 仅在子代理分支派发。** 应用[子代理派发](../instructions/fundamental-concepts--delegation--delegation-child-dispatch_zh_cn.md)、[Worker 边界](../instructions/fundamental-concepts--delegation--delegation-worker-boundary_zh_cn.md)、[子代理生命周期](../instructions/fundamental-concepts--delegation--delegation-child-lifecycle_zh_cn.md)、[子代理复用与替代](../instructions/fundamental-concepts--delegation--delegation-child-reuse-replacement_zh_cn.md)、[子代理消息可见性](../instructions/fundamental-concepts--delegation--delegation-child-message-visibility_zh_cn.md)、[Content Memo Dispatch](../instructions/fundamental-concepts--context-exchange--content-memo-dispatch_zh_cn.md)及[Content Memo Lifecycle](../instructions/fundamental-concepts--context-exchange--content-memo-lifecycle_zh_cn.md)。实际已释放 bundle 必须包含完整任务与范围、来源指针、返回条件、适用时准确的授权 Memory 名称，以及显式 `write_content_memo: true` 或 `false`；不得推断默认值。只向已绑定的子代理派发已释放 Slice。为 true 时遵循 memo owner 生命周期并核验 memo 证据；为 false 时不得派发或写入该 memo。每次 follow-up 均保留实际派发正文证据和当前授权范围。派发或身份证据缺失/不完整时阻塞。确认派发及显式 memo 值后，立即进入 DE07，让子代理继续执行；不得等子代理结果返回后才开始 DE07。Root 执行时，将子代理派发/memo 记录为有原因的 `not_applicable` 并进入 DE07。派发同时按[任务计划 Memory 生命周期](../instructions/fundamental-concepts--execution-planning--task-plan-memory-lifecycle_zh_cn.md)携带准确共享任务计划项目/名称及允许贡献。判断子级需要当前计划读取、直接写入授权，还是仅需有界贡献返回通道；仅提供该角色实际需要的访问。父级协调唯一当前计划写者，并可合并明确授权且有来源的贡献。不得要求每个子级都具备 Memory 写入权限。新事实/进度在 owner 规定的边界纳入；影响授权、范围、验收、方向或依赖动作的变化仍须在该动作前记录。`write_content_memo: false` 不豁免共享计划生命周期。
8. **DE07 — 执行实际任务并返回结果。** 应用[实施](../instructions/workflow-concepts--decision-and-execution--implementation_zh_cn.md)。Root 执行时，作最小授权改动。子代理执行时，确认派发后立即进入 DE07，在子代理执行期间仅实施已释放任务；保留其实际正文/结果证据，结果待处理时不得声称完成，也不得依赖不完整消息。实际执行期间，仅当当前执行者、Slice、输出 class、capability、独立授权、固定 root、准确路径/操作和 baseline 符合[输出物料化](../instructions/fundamental-concepts--execution-planning--output-materialization_zh_cn.md)时，才按该 owner 处理候选输出。准备有界候选，保留其 manifest 身份/hash，并检查/审阅同一候选。应用前按[候选合规预检](../instructions/fundamental-concepts--execution-planning--candidate-compliance_zh_cn.md)在同一固定 root 和政策下进行新鲜 whole-batch 预检；然后重新核验授权、候选 artifact 完整性和 baseline，再应用准确候选。应用完成后，保留已准备候选 ID/hash、准确应用收据和实际当前状态证据。子代理结果待处理时，返回 `needs_prerequisite`，等待实际结果并从 DE07 的结果收集/审阅子步骤恢复，同时携带上述候选身份/hash、收据和当前状态证据。收集结果期间不得重启或重复准备、预检或应用。收到结果后，Root 将完整的子代理实际正文/结果与保留证据和当前文件一起审阅。子代理结果本身不授权应用。未选择可选路径时，记录有原因的 `not_applicable`，且仅在独立授权的直接路径下继续。已选路径缺少必需能力/守卫/预检，或返回失败、未知、遗漏、过期、不确定时，在依赖操作前返回 `needs_prerequisite` 或 `blocked`；不得静默回退。部分、冲突或不确定的应用必须先根据实际当前状态解决；不得覆盖已改变的内容进行重放。结果/状态冲突或不安全时阻塞。仅在需要代码结构证据且能力可用时应用[LSP MCP Tools](../instructions/fundamental-concepts--session-runtime--lsp-mcp-tools_zh_cn.md)。所需 LSP 语义不可用时，说明限制并回退到定向文本搜索和路径范围较小的读取；不得将这些发现称为 LSP 证据。只有不需要代码结构证据时才能记录 `not_applicable`。必需关系仍未知时阻塞。触发时应用[执行阶段反馈](../instructions/fundamental-concepts--execution-control--execution-stage-feedback_zh_cn.md)；否则记录有原因的 `not_applicable`。实际结果和当前状态当前有效并已审阅后，运行聚焦的初步检查并返回路径、效果、实际正文/结果证据、适用时的收据/当前状态证据、检查输出和未解决问题。预检、应用收据和初步检查都不是最终 Verification。Root、复用子代理及新建子代理路径都必须经过此步。
9. **DE08 — 对所有执行者解决当前 Control。** 应用[Control](../instructions/workflow-concepts--decision-and-execution--control_zh_cn.md)、[执行控制](../instructions/fundamental-concepts--execution-control--execution-control_zh_cn.md)、[建议选择](../instructions/workflow-checkpoints--advisory-selection_zh_cn.md)和[Decisions Advisory](../instructions/fundamental-concepts--execution-planning--decisions-advisory_zh_cn.md)。消费当前 Progress Signal 的 status、findings、change scope、verification、issue、need 和当前未释放边界证据。只消费当前可信、符合条件、已启用且已授权的建议；否则记录建议 `not_applicable` 和原因，并基于直接证据决策。保留各 continuation：
   - post-floor `Continue` 缺失/过期时，进入或恢复此 Control 检查。recovery `Continue` 返回 DE04；不得为复用的子代理重新选择或创建替代者。
   - `Evidence-on-Demand` 暂停释放并返回 `needs_prerequisite`；保留同一 Control continuation，证据到达后在此恢复。
   - `Amend` 返回 `needs_prerequisite`；按 owners 更新 Contract 和 Decision，并在需要时更新 Context，然后恢复同一 Control 检查并取得新的明确 `Continue`，再返回 DE04。先前结果不释放工作。
   - `Stop` 返回 `blocked`。
   - 普通 `Continue` 后若有下一 Slice，则返回 `needs_prerequisite`，解析当前 Context/Decision，并确认先前 `Continue` 仍覆盖新的有界 Slice 且状态/epoch 当前。若范围、Contract、授权、未释放边界或相关 epoch 变化使其失效，则恢复此 Control 检查并取得新的明确 `Continue`。若实际任务或授权变化，在 DE01 仅重核受影响决策；若执行者/输出证据变化，在 DE02 重核这些决策，且仅当仍需要新执行者时才在 DE03重核角色预留；若仅新执行者的角色证据变化，则在 DE03 重核。检查完成后从 DE04 恢复，不重放已完成效果。否则在 Context/Decision 当前后直接从 DE04 恢复，适用时复用现有子代理。若没有下一 Slice 且没有待处理恢复结果，只有当前 post-implementation/result 证据确认任务已完成后才进入 DE09。
10. **DE09 — 返回实施/结果状态。** 返回证据证明当前任务实施/结果已完成、实际任务授权、执行者/输出/角色处置、已释放 Slice 与当前指纹、Root 实施或完整的子代理实际派发/结果证据、memo 字段/值及证据或有依据的 `not_applicable`、初步检查、当前 Control 结果/continuation 和限制。不得执行或声称最终验证；调用方后续验证/修复工作流负责最终验证。Root、现有子代理及新建子代理执行路径在返回前都必须经过 DE04、DE07 和 DE08。
