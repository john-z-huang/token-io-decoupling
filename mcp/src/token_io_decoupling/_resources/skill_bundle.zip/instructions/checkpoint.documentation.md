# checkpoint.documentation

[English](checkpoint.documentation.md) | [简体中文](checkpoint.documentation_zh_cn.md)

Apply the current instruction and its included policy sections below. The current actions, guards, evidence and failure boundary are given directly. Before applying a named independent policy, obtain its exact instruction continuation; reuse any already held unit from this build and retain the affected action's return position. Do not retrieve author files or infer omitted policy. Check current facts and authorization before effects; an instruction is not a pass.

## Hard constraints

- Record hard user, runtime environment, repository, permission, safety, and Session constraints before acting.
- A task-level prohibition, such as “do not create subagents” or “do not use a browser,” remains active for the whole task.
- Computer Use is categorically forbidden: never control a computer, browser, or desktop app through its graphical interface — no screenshots to locate controls, mouse or keyboard simulation, clicking, accessibility APIs, window automation, remote-desktop control, or GUI scripting — and do not route such interaction through an API, CLI, MCP server, helper, or another Agent. Treat this as a blacklist rather than a list of allowed channels: every other tool, command, or capability actually exposed to and authorized for the current Session remains permitted. If a required step needs a forbidden operation, stop and report the blocker instead of attempting, delegating, or skipping it.
- Before route selection or any delegation/Session-topology work, the Mode checkpoint must compose and validate the delegation references; those references own conversation-level mode selection with a default Multi-Agent route and one-child budget, child counts, conditional creation, allocation, reuse, replacement, exceptions, and limits at their respective atomic boundaries. A reserved budget never initializes or authorizes a child by itself.
- Never invent authorization, capability, evidence, product support, or an executable route for an unmaintained scenario.
- Keep Core rules independent of product details; read Runtime and Model Provider Support (instruction continuation: [unit.081374cfbaa37b57](../instructions/unit.081374cfbaa37b57.md)) for supported runtime branches and model bindings.
- Read references on demand. Do not preload the entire Skill, `references/`, or raw project state merely because it may become useful.

# Documentation Checkpoint


## Actions

1. Confirm the approved documentation paths, audience, purpose, and source evidence.
   - When an authorized route selects pre-write candidate feedback, apply Candidate Compliance Preflight (instruction continuation: [unit.fe5e2c4674619c83](../instructions/unit.fe5e2c4674619c83.md)) to the exact candidate and current trusted baseline. Resolve every selected failed, unknown, omitted, or stale result before applying the candidate. A passing preflight is limited candidate evidence and does not replace the current post-write checks below. If no preflight branch applies, record `Not applicable` with the reason.
2. Change only the approved Markdown or comment scope. Keep English and Simplified Chinese mirrors synchronized when both are maintained.
3. When repository documentation, a code comment, or a project-memory note changes, advance the documentation epoch and run the checks applicable to that changed output, including Markdown, link, whitespace, multilingual, and scope checks where relevant.
4. Record whether changed documentation affects executable content, the Contract, or acceptance conditions. Reverify affected dimensions as required by the current epoch; do not rerun unrelated product behavior tests solely because the documentation epoch changed.
5. Do not add new behavior, policy, scope, or Git effects under the label of documentation, and report checks that could not run.
6. If approved output includes reusable Agent project knowledge or a cross-session note the user explicitly requested, write it through the project-memory and code-structure capability (instruction continuation: [unit.eb35e270023c9aac](../instructions/unit.eb35e270023c9aac.md)), preserving the existing name and subdirectory intent, and confirm the successful write result. Perform stored-content verification only when the applicable Layer-01 owner requires it; any owner-required verification must pass before completion. If no such output was requested, record `Not applicable` with the reason. If the capability is unavailable or the write or required verification fails, report the failure and keep that requested output incomplete. Authoritative repository documents and code comments remain in their approved repository file paths and follow the existing mirror, epoch, check, and return rules above.

## Pass condition

Approved documentation is accurate for the applicable verified state, its current documentation epoch is explicit, its applicable checks pass or have explicit unavailable results, all reusable Agent project knowledge included in approved output and every cross-session note explicitly requested by the user have been successfully saved with their write results confirmed and any owner-required content verification passed, and the current workflow route has resolved any required content-affecting re-verification.

## Boundary

This checkpoint does not replace implementation verification, authorize product decisions, or authorize Git effects.
