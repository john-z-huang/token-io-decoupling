# unit.2d0f4872b823ef44_zh_cn

[English](unit.2d0f4872b823ef44.md) | [简体中文](unit.2d0f4872b823ef44_zh_cn.md)

下列直接给出当前动作、守卫、证据和失败边界。应用独立政策前，先按明确的指令继续入口取得对应单元；同一构建中已持有的单元直接复用，并保留受影响动作的准确恢复位置。不读取作者文件或推测缺失政策。执行副作用前核实当前事实与授权；指令内容可用不表示检查通过。

## 硬约束

- 采取行动前记录用户、运行环境、仓库、权限、安全和 Session 硬约束。
- “不要创建子代理”“不要使用浏览器”等任务级禁止条件在整个任务中持续有效。
- 绝对禁止 Computer Use：不得通过图形界面控制计算机、浏览器或桌面应用——包括以操纵控件为目的的截图、鼠标／键盘模拟、点击、辅助功能 API、窗口自动化、远程桌面控制或 GUI 脚本——也不得把此类交互包装为 API、CLI、MCP Server、辅助程序或其他 Agent 调用来绕过。本节是黑名单而非允许渠道清单：当前 Session 实际暴露且已获授权的其他工具、命令或能力仍然允许。若必需步骤需要借助被禁止的操作，应停止并报告阻塞，而不是尝试、委派或跳过。
- 路线选择或任何委派/Session 拓扑工作前，模式检查点必须组合并验证委派 references；这些 references 在各自的原子边界内规定会话级模式选择及默认多代理路线和单个子代理预算、子代理数量、条件创建、分配、复用、替换、例外和限制。预留预算本身不会初始化或授权创建子代理。
- 不得虚构授权、能力、证据、产品支持，或为未维护场景推导可执行路线。
- Core 规则不依赖具体产品；受支持的运行环境分支和模型绑定见运行环境与模型厂商支持 (instruction continuation: [unit.081374cfbaa37b57](../instructions/unit.081374cfbaa37b57_zh_cn.md))。
- 按需读取 reference。不要仅因为可能以后有用，就预加载整个 Skill、`references/` 或原始项目状态。

# Coding Context Exchange Handoff

## 通用规范

### Context index 与 handoff 记录

使用 `context-exchange/INDEX` 作为父级路由索引，使用 `context-exchange/workers/<worker-context-id>/INDEX` 记录 Worker 的 task、scope、status、最近一次实质更新、记录名称及 blocker/handoff 目标。Handoff 记录保留已完成状态、带证据的失败方案、当前修改和验证、阻塞、下一步动作及准确权威来源指针。只在状态/证据/handoff 实质变化时更新，不要逐命令记录。

原 handoff/import 名称在 `context-exchange/` 下沿用相同 basename 和子目录意图映射。后继者只读取其已放行任务明确暴露的 Memory 名称；除非明确授权，不得写入其他 Worker 的名称。这只是指令逻辑归属，不是技术隔离；Serena 可能向任何获准 Session 暴露记录。不得重建完整 transcript。Memory 工具不可用时，报告并阻塞依赖工作；不得回退为文件。

### 授权边界

Context ID 或 Memory 名称本身不授权创建/替换 Agent，也不授权改变父级实时任务状态。mode/count/allocation/epoch 状态仍由其原 owner 管理。

## Codex CLI / ChatGPT Desktop 特别优化指令

只使用实际暴露且获准的 Serena 工具。在已放行 handoff 中点名准确记录，只读这些记录，核验来源新鲜度，并确认写入结果。Thread/worktree 转移本身不会创建或交付 Memory handoff。

## Claude Code CLI / Claude Desktop 特别优化指令

仅当当前 Session 暴露且授权时使用 Serena MCP Memory；依赖前先发现延迟加载的 MCP 工具。Claude resume/branch 和 auto memory 不授权或交付此记录。能力不可用时按报告/阻塞规则处理。
