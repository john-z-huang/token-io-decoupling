# Single-Agent 执行模块

[English](workflows--modules--single-execution.md) | [简体中文](workflows--modules--single-execution_zh_cn.md)

下列直接给出当前动作、守卫、证据和失败边界。应用独立政策前，先按明确的指令继续入口取得对应单元；同一构建中已持有的单元直接复用，并保留受影响动作的准确恢复位置。不读取作者文件或推测缺失政策。执行副作用前核实当前事实与授权；指令内容可用不表示检查通过。

## 硬约束

- 采取行动前记录用户、运行环境、仓库、权限、安全和 Session 硬约束。
- “不要创建子代理”“不要使用浏览器”等任务级禁止条件在整个任务中持续有效。
- 绝对禁止 Computer Use：不得通过图形界面控制计算机、浏览器或桌面应用——包括以操纵控件为目的的截图、鼠标／键盘模拟、点击、辅助功能 API、窗口自动化、远程桌面控制或 GUI 脚本——也不得把此类交互包装为 API、CLI、MCP Server、辅助程序或其他 Agent 调用来绕过。本节是黑名单而非允许渠道清单：当前 Session 实际暴露且已获授权的其他工具、命令或能力仍然允许。若必需步骤需要借助被禁止的操作，应停止并报告阻塞，而不是尝试、委派或跳过。
- 路线选择或任何委派/Session 拓扑工作前，模式检查点必须组合并验证委派 references；这些 references 在各自的原子边界内规定会话级模式选择及默认多代理路线和单个子代理预算、子代理数量、条件创建、分配、复用、替换、例外和限制。预留预算本身不会初始化或授权创建子代理。
- 不得虚构授权、能力、证据、产品支持，或为未维护场景推导可执行路线。
- Core 规则不依赖具体产品；受支持的运行环境分支和模型绑定见[运行环境与模型厂商支持](../instructions/fundamental-concepts--session-runtime--runtime-provider-support_zh_cn.md)。
- 按需读取 reference。不要仅因为可能以后有用，就预加载整个 Skill、`references/` 或原始项目状态。

# Single-Agent 执行模块


本 Layer-04 模块组合已授权 Single-Agent 任务的执行者/输出处置、当前受控 Slice、本地实施、阶段反馈和 Control。它向调用方返回实施状态与初步证据；最终验证属于后续验证/修复工作流。

## 入口声明

| 字段 | 要求 |
| --- | --- |
| 必需输入 | 当前已授权任务和 Contract、已释放的 Single-Agent 模式、完整且当前的 Session/审计、有来源的 Context 和 Decision、continuation/效果状态，以及任何恢复底线和当前 Control 证据。 |
| 允许效果 | 解析执行者/输出、释放和实施已授权 Slice、在 owner 规定边界提交获准的计划更新、提供阶段反馈及解决 Control。不得创建/派发子代理、预留角色、扩大范围或进行最终验证。 |
| 结果 | 仅在返回当前实施状态、指纹、初步检查和 Control 处置且无待处理恢复/下一 Slice 时返回 `complete`；否则以 continuation 返回 `needs_prerequisite` 或 `blocked`。条件子步骤可带原因标为 `not_applicable`。 |
| 新鲜度 | 将证据绑定到当前 Contract、任务/Slice 指纹、规范 state revision、Control 规则及相关 epoch。实质变化会使受影响证据失效，并要求从指定检查点重新进入。 |

## 工作流路线图


## 有序模块清单

1. **SE00 — 解析入口。** 提供本声明、当前授权与路线/模式证据、完整 Session/审计和 Context/Decision 证据、先前效果、恢复状态及 continuation，调用[模块入口解析](../instructions/workflow-checkpoints--module-entry-resolution_zh_cn.md)。`ready` 只允许模块核验。证据缺失时连同 owner 和位置返回 `needs_prerequisite`；冲突、状态不安全或先前效果无法恢复时返回 `blocked`。
2. **SE01 — 分别解析执行者和输出。** 应用[任务分配](../instructions/fundamental-concepts--execution-planning--task-assignment_zh_cn.md)和[执行者选择](../instructions/workflow-checkpoints--executor-selection_zh_cn.md)，再应用[输出 Token 路由](../instructions/fundamental-concepts--execution-planning--output-token-routing_zh_cn.md)及[输出路由选择](../instructions/workflow-checkpoints--output-route-selection_zh_cn.md)。在已释放 Single-Agent 模式下，明确的 `sub_agent` 结果与锁定 Mode 冲突，返回 `blocked`。Root 直接输出为 `yes` 时，报告锁定的拓扑边界并阻塞 Slice 释放；不得暗示本 Session 可以更改 Mode。必需的执行者/输出证据未知时返回 `needs_prerequisite`。仅当 Root 执行已确认且输出已处置时继续。
3. **SE02 — 应用当前 Control 门禁并释放 Slice。** 应用[执行控制](../instructions/fundamental-concepts--execution-control--execution-control_zh_cn.md)、[执行规划](../instructions/fundamental-concepts--execution-planning--execution-planning_zh_cn.md)和[委派状态记录](../instructions/fundamental-concepts--delegation--delegation-state-record_zh_cn.md)。实质变化会使依赖它的早先 Control 证据失效；释放/恢复前返回 SE05，依据当前事实重新评估。`Stop` 会阻塞。仅释放由当前 Context 和 Decision 支持的有界 Slice，并说明目标、授权范围/修改、返回条件及未释放边界。按 owner 更新并回读父级控制记录。释放前应用[任务计划 Memory 生命周期](../instructions/fundamental-concepts--execution-planning--task-plan-memory-lifecycle_zh_cn.md)，确认当前计划证据与持久化、owner 要求的核验或有记录的限制例外；失败时阻塞依赖释放。
4. **SE03 — 实施并返回初步检查。** 应用[实施](../instructions/workflow-concepts--decision-and-execution--implementation_zh_cn.md)。仅检查必要来源并作最小授权改动。只有当前执行者、输出 class、capability、单独授权、固定 root、准确路径和 baseline 都符合[输出物料化](../instructions/fundamental-concepts--execution-planning--output-materialization_zh_cn.md)时，才应用该 owner。准备并检查有界候选，保留其 manifest 身份/hash。应用前，按[候选合规预检](../instructions/fundamental-concepts--execution-planning--candidate-compliance_zh_cn.md)在同一固定 root 和政策下进行新鲜 whole-batch 预检；然后重新核验授权、artifact 完整性和 baseline，再应用准确候选。审阅收据和实际当前文件；准备、预检和收据不是最终 Verification。未选择可选路径时，记录有原因的 `not_applicable`，且仅在独立授权的直接路径下继续。已选路径缺少必需能力/守卫/预检，或返回失败、未知、遗漏、过期、不确定时，在依赖操作前返回 `needs_prerequisite` 或 `blocked`；不得静默回退。部分、冲突或不确定的应用须先根据实际当前状态解决；不得覆盖已改变内容进行重放。仅在需要代码结构证据且能力可用时才使用[LSP MCP Tools](../instructions/fundamental-concepts--session-runtime--lsp-mcp-tools_zh_cn.md)。所需 LSP 语义不可用时，说明限制并回退到定向文本搜索和路径范围较小的读取；不得将这些发现称为 LSP 证据。只有不需要代码结构证据时才能记录 `not_applicable`。必需关系仍未知时阻塞。运行聚焦的初步检查，返回变更路径、效果、当前指纹、检查输出、适用时的收据/当前状态证据和未解决问题。这不是最终验证。
5. **SE04 — 提供阶段反馈。** 触发时应用[执行阶段反馈](../instructions/fundamental-concepts--execution-control--execution-stage-feedback_zh_cn.md)，在实质阶段边界返回有界 Progress Signal。无触发条件时，记录带观察原因的 `not_applicable`。两条路径都进入 SE05；不得跳过 Control。
6. **SE05 — 解决当前 Control。** 应用[Control](../instructions/workflow-concepts--decision-and-execution--control_zh_cn.md)、[执行控制](../instructions/fundamental-concepts--execution-control--execution-control_zh_cn.md)、[建议选择](../instructions/workflow-checkpoints--advisory-selection_zh_cn.md)及[Decisions Advisory](../instructions/fundamental-concepts--execution-planning--decisions-advisory_zh_cn.md)。消费当前 Progress Signal 的 status、findings、change scope、verification、issue、need 和当前未释放边界证据。仅在建议当前可信、符合条件、已启用且已授权时消费；否则记录带原因的建议 `not_applicable`，并根据当前直接证据决策。为各结果保留当前 continuation：
   - post-floor `Continue` 缺失/过期时，进入或恢复同一 Control 检查。新的 recovery `Continue` 返回 SE02 处理下一/恢复 Slice。
   - `Evidence-on-Demand` 暂停释放并返回 `needs_prerequisite`；保留同一 Control continuation，证据到达后回到此处。
   - `Amend` 返回 `needs_prerequisite`；按 owners 更新 Contract 和 Decision，并在需要时更新 Context。随后恢复同一 Control 检查，并取得新的明确 `Continue` 后才返回 SE02；先前结果不释放工作。
   - `Stop` 返回 `blocked`。
   - 普通 `Continue` 后若有下一 Slice，则返回 `needs_prerequisite`，先为该 Slice 解析当前 Context/Decision，并核验此 `Continue` 仍覆盖新的有界 Slice 且状态/epoch 当前。若范围、Contract、授权、未释放边界或相关 epoch 使其失效，则恢复此 Control 检查并取得新的明确 `Continue`；否则仅在 SE01 重核已变化的执行者/输出证据，然后进入 SE02，不重放已完成效果。若没有下一 Slice 且没有待处理恢复结果，只有当前 post-implementation 证据确认任务已完成后才进入 SE06。
7. **SE06 — 返回实施状态。** 返回证据证明当前任务实施已完成、路径/效果、当前指纹、初步检查证据、当前 Control 结果及 continuation 状态，以及限制。不得声称最终验证或最终 Acceptance；这由后续验证/修复及调用方工作流负责。
