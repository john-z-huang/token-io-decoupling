# unit.caa7baa69e1cbe03

[English](unit.caa7baa69e1cbe03.md) | [简体中文](unit.caa7baa69e1cbe03_zh_cn.md)

Apply the current instruction and its included policy sections below. The current actions, guards, evidence and failure boundary are given directly. Before applying a named independent policy, obtain its exact instruction continuation; reuse any already held unit from this build and retain the affected action's return position. Do not retrieve author files or infer omitted policy. Check current facts and authorization before effects; an instruction is not a pass.

## Hard constraints

- Record hard user, runtime environment, repository, permission, safety, and Session constraints before acting.
- A task-level prohibition, such as “do not create subagents” or “do not use a browser,” remains active for the whole task.
- Computer Use is categorically forbidden: never control a computer, browser, or desktop app through its graphical interface — no screenshots to locate controls, mouse or keyboard simulation, clicking, accessibility APIs, window automation, remote-desktop control, or GUI scripting — and do not route such interaction through an API, CLI, MCP server, helper, or another Agent. Treat this as a blacklist rather than a list of allowed channels: every other tool, command, or capability actually exposed to and authorized for the current Session remains permitted. If a required step needs a forbidden operation, stop and report the blocker instead of attempting, delegating, or skipping it.
- Before route selection or any delegation/Session-topology work, the Mode checkpoint must compose and validate the delegation references; those references own conversation-level mode selection with a default Multi-Agent route and one-child budget, child counts, conditional creation, allocation, reuse, replacement, exceptions, and limits at their respective atomic boundaries. A reserved budget never initializes or authorizes a child by itself.
- Never invent authorization, capability, evidence, product support, or an executable route for an unmaintained scenario.
- Keep Core rules independent of product details; read Runtime and Model Provider Support (instruction continuation: [unit.081374cfbaa37b57](../instructions/unit.081374cfbaa37b57.md)) for supported runtime branches and model bindings.
- Read references on demand. Do not preload the entire Skill, `references/`, or raw project state merely because it may become useful.

# Decision context selection


This checkpoint owns whether a downstream decision needs generated background and whether that background is current and usable. It does not make the executor, output-route, role, advice-eligibility, or other downstream decision.

## Trigger and inputs

Consume the current decision question, verified facts with their source provenance, explicit user direction, and the downstream decision that may use generated context. Apply Decision Context Generation (instruction continuation: [unit.4d8491f91935afe9](../instructions/unit.4d8491f91935afe9.md)). This checkpoint does not enable advice. The separate optional five-node stage-advice gate is governed by route Advisory Selection and Decisions Advisory (instruction continuation: [unit.4d827a8a683055da](../instructions/unit.4d827a8a683055da.md)); it does not reopen or change Mode. Executor, output-route, candidate, and role decisions remain with their direct owners.

## Decision and result

1. Name the unresolved downstream question and identify which current facts and constraints bear on it, with source pointers and provenance labels. Keep user requirements, current evidence, plans, assumptions, and unverified claims distinct.
2. If explicit user direction settles the relevant choice, or no downstream decision requires generated context, record `Not applicable` and why. Otherwise call Decision Context Generation with only the bounded facts, provenance, and concrete decision goal needed for that question.
3. Review the returned context for factual fidelity, provenance, language, relevance, and missing information. Compare its input hash with the exact current source material and goal; compare its policy binding with the current applicable rules. Reject stale, mismatched, incomplete, or conflicting context and do not send it to downstream advice.
4. Return one of these results to the named downstream owner:

| Result | Required route action |
| --- | --- |
| Reviewed context and exact current input/policy bindings | Pass only that context and its provenance/hash evidence to the corresponding advice consumer. |
| Explicit direction settled the choice, or no downstream decision requires generated context | Record `Not applicable` and why; follow the explicit direction or proceed under the direct decision owner. |
| Generation failed, or required facts are missing/conflicting | Do not invent context or hashes. Decide directly only if verified facts are sufficient under the direct owner; otherwise block the dependent decision and request the missing evidence. |

## Failure boundary

Generated context is supporting input, not a decision, authorization, or substitute for current direct owners. This checkpoint does not determine whether any advice is enabled, relevant, or acceptable; each direct decision owner keeps its own gate, and the separate optional five-node stage-advice gate remains with Advisory Selection.
