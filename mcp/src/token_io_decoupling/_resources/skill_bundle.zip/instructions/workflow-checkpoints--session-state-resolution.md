# Session State Resolution

[English](workflow-checkpoints--session-state-resolution.md) | [简体中文](workflow-checkpoints--session-state-resolution_zh_cn.md)

Apply the current instruction and its included policy sections below. The current actions, guards, evidence and failure boundary are given directly. Before applying a named independent policy, obtain its exact instruction continuation; reuse any already held unit from this build and retain the affected action's return position. Do not retrieve author files or infer omitted policy. Check current facts and authorization before effects; an instruction is not a pass.

## Hard constraints

- Record hard user, runtime environment, repository, permission, safety, and Session constraints before acting.
- A task-level prohibition, such as “do not create subagents” or “do not use a browser,” remains active for the whole task.
- Computer Use is categorically forbidden: never control a computer, browser, or desktop app through its graphical interface — no screenshots to locate controls, mouse or keyboard simulation, clicking, accessibility APIs, window automation, remote-desktop control, or GUI scripting — and do not route such interaction through an API, CLI, MCP server, helper, or another Agent. Treat this as a blacklist rather than a list of allowed channels: every other tool, command, or capability actually exposed to and authorized for the current Session remains permitted. If a required step needs a forbidden operation, stop and report the blocker instead of attempting, delegating, or skipping it.
- Before route selection or any delegation/Session-topology work, the Mode checkpoint must compose and validate the delegation references; those references own conversation-level mode selection with a default Multi-Agent route and one-child budget, child counts, conditional creation, allocation, reuse, replacement, exceptions, and limits at their respective atomic boundaries. A reserved budget never initializes or authorizes a child by itself.
- Never invent authorization, capability, evidence, product support, or an executable route for an unmaintained scenario.
- Keep Core rules independent of product details; read [Runtime and Model Provider Support](../instructions/fundamental-concepts--session-runtime--runtime-provider-support.md) for supported runtime branches and model bindings.
- Read references on demand. Do not preload the entire Skill, `references/`, or raw project state merely because it may become useful.

# Session State Resolution


This checkpoint owns the route-level confirmation of the current Session facts and canonical parent-controlled workflow record before audit preferences are applied. It does not own audit values or mode/count policy.

## Trigger and inputs

Consume released Mode/count and current Session identity, role, and Context Firewall facts. Apply [Session Model](../instructions/fundamental-concepts--session-runtime--session-model.md), [Session Role Ownership](../instructions/fundamental-concepts--session-runtime--session-role-ownership.md), [Session Context Firewall](../instructions/fundamental-concepts--session-runtime--session-context-firewall.md), and [Delegation State Record](../instructions/fundamental-concepts--delegation--delegation-state-record.md).

## Decision and result

1. Confirm the released Mode/count and current Session facts. Missing or conflicting mode, identity, role, or Context Firewall evidence blocks dependent work before any protected operation.
2. Read the canonical parent-controlled record from its authoritative conversation context. Preserve existing mode, count, allocations, approved task scope, and lifecycle values; do not reconstruct or overwrite missing/conflicting history from a tool result, hash, or stale summary.
3. Confirm the record agrees with the released Mode/count and current known allocation state. Apply the owner-defined role and path checks before any gated operation. A worker assignment, Slice release, task authorization, and creation/dispatch remain distinct facts and must each be verified under their owners.
4. Read back and return the current record and evidence to the route. This readback does not grant authority or release a Slice, does not establish cross-call sequencing, and does not establish audit preferences.

## Failure boundary

If current identity, role, firewall, released mode/count, or canonical record cannot be verified, block the dependent protected operation. Do not substitute a database, infer a replacement record, or treat a structural evaluation result as canonical state. Independent authorized work may continue when it does not rely on the missing facts.
