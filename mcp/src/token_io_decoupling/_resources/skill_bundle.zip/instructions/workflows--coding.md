# workflows / coding

[English](workflows--coding.md) | [简体中文](workflows--coding_zh_cn.md)

Apply the current instruction and its included policy sections below. The current actions, guards, evidence and failure boundary are given directly. Before applying a named independent policy, obtain its exact instruction continuation; reuse any already held unit from this build and retain the affected action's return position. Do not retrieve author files or infer omitted policy. Check current facts and authorization before effects; an instruction is not a pass.

## Hard constraints

- Record hard user, runtime environment, repository, permission, safety, and Session constraints before acting.
- A task-level prohibition, such as “do not create subagents” or “do not use a browser,” remains active for the whole task.
- Computer Use is categorically forbidden: never control a computer, browser, or desktop app through its graphical interface — no screenshots to locate controls, mouse or keyboard simulation, clicking, accessibility APIs, window automation, remote-desktop control, or GUI scripting — and do not route such interaction through an API, CLI, MCP server, helper, or another Agent. Treat this as a blacklist rather than a list of allowed channels: every other tool, command, or capability actually exposed to and authorized for the current Session remains permitted. If a required step needs a forbidden operation, stop and report the blocker instead of attempting, delegating, or skipping it.
- Before route selection or any delegation/Session-topology work, the Mode checkpoint must compose and validate the delegation references; those references own conversation-level mode selection with a default Multi-Agent route and one-child budget, child counts, conditional creation, allocation, reuse, replacement, exceptions, and limits at their respective atomic boundaries. A reserved budget never initializes or authorizes a child by itself.
- Never invent authorization, capability, evidence, product support, or an executable route for an unmaintained scenario.
- Keep Core rules independent of product details; read [Runtime and Model Provider Support](../instructions/fundamental-concepts--session-runtime--runtime-provider-support.md) for supported runtime branches and model bindings.
- Read references on demand. Do not preload the entire Skill, `references/`, or raw project state merely because it may become useful.

## Entry

1. Complete the Contract checkpoint before route selection.
2. Identify the actual runtime environment, complete the Environment checkpoint, and establish or load the [Environment capability inventory](../instructions/workflow-concepts--entry-and-context--environment-capability-inventory.md) for capability checks.
3. Pass the Mode checkpoint, which consumes the already established Environment capability inventory and composes the delegation references needed for the root-directive mode gate.
4. Call [Route Entry](../instructions/workflow-checkpoints--route-entry.md) with current evidence that Contract, Environment, capability inventory, and Mode passed. Select exactly its authorized complete route, then pass released mode/count evidence to its first module checkpoint SM01/MM01. Each route composes [Entry Readiness](../instructions/workflows--modules--entry-readiness.md), [Session Readiness](../instructions/workflows--modules--session-readiness.md), [Work Definition](../instructions/workflows--modules--work-definition.md), its mode-specific execution module, [Verification and Repair](../instructions/workflows--modules--verification-repair.md), [Documentation](../instructions/workflows--modules--documentation.md), and [Delivery and Acceptance](../instructions/workflows--modules--delivery-acceptance.md) in order. Load only the selected route and modules as reached.

All current and future routes consume [Task Plan Memory Lifecycle](../instructions/fundamental-concepts--execution-planning--task-plan-memory-lifecycle.md) through Work Definition and their execution checkpoints. Pass the shared plan identity, current plan evidence and persistence confirmation, or documented restriction exception into execution; complete any content verification the owner requires. Record updates at owner-defined phase, handoff, pause, and completion boundaries, and record changes affecting authorization, scope, acceptance, direction, or dependent actions before those actions. Complete only after the matching plan lifecycle is resolved. An explicit planning request is unnecessary.

## Routes

- [Single-Agent Coding](../instructions/workflows--coding-single-agent.md): use when the released Mode selects `mode: Single-Agent Coding`; directive-related work stays in the current Session.
- [Multi-Agent Coding](../instructions/workflows--coding-multi-agent.md): use when the released Mode selects Multi-Agent Coding with a locked positive `child_count`. The Mode checkpoint owns the four-option menu, default, and invalid-input handling; locking the budget does not initialize a child.

Do not load both routes. If a later material fact invalidates the selected route, stop the current slice, amend the Contract as needed, and return to Route Entry.

## Completion

Return `COMPLETE` only after the selected route reaches Acceptance with current evidence. Report unavailable checks, assumptions, residual risks, authorized effects, and the recorded delegation state. Do not cause external effects without explicit authorization.
