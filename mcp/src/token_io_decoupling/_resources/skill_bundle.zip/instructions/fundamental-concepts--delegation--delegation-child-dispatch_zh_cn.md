# Coding 子 Agent 派发

[English](fundamental-concepts--delegation--delegation-child-dispatch.md) | [简体中文](fundamental-concepts--delegation--delegation-child-dispatch_zh_cn.md)

下列直接给出当前动作、守卫、证据和失败边界。应用独立政策前，先按明确的指令继续入口取得对应单元；同一构建中已持有的单元直接复用，并保留受影响动作的准确恢复位置。不读取作者文件或推测缺失政策。执行副作用前核实当前事实与授权；指令内容可用不表示检查通过。

## 硬约束

- 采取行动前记录用户、运行环境、仓库、权限、安全和 Session 硬约束。
- “不要创建子代理”“不要使用浏览器”等任务级禁止条件在整个任务中持续有效。
- 绝对禁止 Computer Use：不得通过图形界面控制计算机、浏览器或桌面应用——包括以操纵控件为目的的截图、鼠标／键盘模拟、点击、辅助功能 API、窗口自动化、远程桌面控制或 GUI 脚本——也不得把此类交互包装为 API、CLI、MCP Server、辅助程序或其他 Agent 调用来绕过。本节是黑名单而非允许渠道清单：当前 Session 实际暴露且已获授权的其他工具、命令或能力仍然允许。若必需步骤需要借助被禁止的操作，应停止并报告阻塞，而不是尝试、委派或跳过。
- 路线选择或任何委派/Session 拓扑工作前，模式检查点必须组合并验证委派 references；这些 references 在各自的原子边界内规定会话级模式选择及默认多代理路线和单个子代理预算、子代理数量、条件创建、分配、复用、替换、例外和限制。预留预算本身不会初始化或授权创建子代理。
- 不得虚构授权、能力、证据、产品支持，或为未维护场景推导可执行路线。
- Core 规则不依赖具体产品；受支持的运行环境分支和模型绑定见[运行环境与模型厂商支持](../instructions/fundamental-concepts--session-runtime--runtime-provider-support_zh_cn.md)。
- 按需读取 reference。不要仅因为可能以后有用，就预加载整个 Skill、`references/` 或原始项目状态。

# Coding 子 Agent 派发

## 通用规范

### Dispatch Preview 和返回边界

模型和 reasoning-effort 设置在创建子代理时确定。派发、任务工作和 follow-up 不检查这些设置，也不得要求子代理检查或报告自身设置。以下任务授权、范围和上下文检查仍须分别执行。

分配或实质派发前，检查输入侧推理职责已完成指令、环境和定义任务所需代码事实的前置确认，具有 source pointer，且具体 Interaction Slice 已放行。仅当审计预设选择 preview 时，父级才展示获准目标、修改和返回条件的简洁 Dispatch Preview；若预设要求全文展示，则展示完整安全消息正文。前置条件缺失时仍由父级持有 Slice。Root 和 Worker 消息正文按[会话审计可见性](../instructions/fundamental-concepts--session-runtime--session-audit-visibility_zh_cn.md)预设处理。Worker 在可用时完整展示安全任务提示，并保持安全出站正文完整可见；其完整最终结果就是出站副本，不得重复打印。缺失 Worker 侧正文时，须定向报告审计限制，不得默认为已验证或据此扩大范围。Worker 只向直接父级返回，不得创建、fork、handoff、向其他 Agent 或 Session 发消息、替换或协调其他 Agent 或 Session，也不得联系任意线程。与已确认前提冲突的发现返回父级重新决策，不得改变模式或数量。

### Named path 和 slice 放行

按[上下文工作区边界](../instructions/fundamental-concepts--context-exchange--context-exchange-workspace-boundary_zh_cn.md)检查已放行任务授权的 Memory 名称及逻辑归属；源码和代码路径访问仍遵守单独批准的边界。通过[执行控制](../instructions/fundamental-concepts--execution-control--execution-control_zh_cn.md)消费获准的 Interaction Slice，一次只派发一个 Slice，除非明确允许相互独立且不冲突的并行工作。本模块不重新定义 Memory 名称或 Slice 字段。

## Codex CLI / ChatGPT Desktop 特别优化指令

Codex 自定义 Agent 可通过 `developer_instructions` 保存职责专属指令；父级仍必须通过实际子任务调用发送已放行目标、具名来源、范围和返回条件。`AGENTS.md` 可提供仓库指令，却不能代替这份任务专属 bundle。若已配置 Codex Hooks，`SubagentStart` 可以添加少量上下文，但不能阻止创建，也不得默默扩大获准 Slice。[OpenAI：子代理 profile](https://learn.chatgpt.com/docs/agent-configuration/subagents)、[OpenAI：SubagentStart](https://learn.chatgpt.com/docs/hooks)。

### 可观察的派发与创建前守卫

交互式 Codex CLI 可用 `/agent` 查看所选 Agent 线程。ChatGPT Desktop 只有在当前 Session 直接暴露线程／结果工具时，才能通过该工具读取子代理工作与返回摘要；否则将此能力记录为不可用。实际 spawn 前，父级回合应保留简短任务指令，并将目标、获准源码/权威文档路径、已授权 Memory 名称、来源指针、显式 `write_content_memo` 与返回条件写入 Child 的真实任务提示。若已经审查并启用的 `PreToolUse` Hook 匹配 `spawn_agent`／`Agent`，可拒绝缺少已放行 Slice 的调用；`SubagentStart` 太晚，不能否决创建。应检查 Hook 的信任与覆盖情况，不得声称该守卫默认存在。[OpenAI：子代理工具与线程](https://learn.chatgpt.com/docs/agent-configuration/subagents)、[OpenAI：Hooks 工具覆盖](https://learn.chatgpt.com/docs/hooks)。

## Claude Code CLI / Claude Desktop 特别优化指令

### 派发前工具门禁

本地已配置 Claude Code 的宿主中，获准的 `PreToolUse` Hook 可匹配 `Agent`，在调用执行**之前**检查父级记录是否具备预留名额、已放行 Slice 和获准返回路径；缺少时通过显式 deny 阻止创建。不得依赖创建之后才触发且不能 veto 的 `SubagentStart`。必须在 `Agent` 工具调用**之前**在父级会话展示人类可读的 Dispatch Preview；Hook 本身不能证明父级已审核或展示该预览。守卫脚本必须读取真实状态记录，授权缺失时拒绝执行，不记录密钥或完整提示词。未安装经过审查的 Hook 时，派发前语义检查仍然是强制要求。

官方依据：[PreToolUse 与 SubagentStart 语义](https://code.claude.com/docs/en/hooks)。

Claude Code 自定义 subagent 具有自己的上下文，不会自动继承父级完整对话历史或此前调用过的 Skills。必须在实际 `Agent` 任务提示中携带已放行目标、有界来源指针及返回条件。`skills` frontmatter 会将**整个具名 Skill**预加载到该子代理，因此只有职责确需时才配置，不把它当作选择性加载概念的替代方案。若 Worker 工具池暴露 `SendMessage`／peer 控制，应从 Worker 排除，保留获准的父级到子代理 follow-up。[Anthropic：子代理上下文与 Skills](https://code.claude.com/docs/en/sub-agents)。
