# Coding Execution Decision Gate

[English](fundamental-concepts--execution-planning--execution-decision-gate.md) | [简体中文](fundamental-concepts--execution-planning--execution-decision-gate_zh_cn.md)

下列直接给出当前动作、守卫、证据和失败边界。应用独立政策前，先按明确的指令继续入口取得对应单元；同一构建中已持有的单元直接复用，并保留受影响动作的准确恢复位置。不读取作者文件或推测缺失政策。执行副作用前核实当前事实与授权；指令内容可用不表示检查通过。

## 硬约束

- 采取行动前记录用户、运行环境、仓库、权限、安全和 Session 硬约束。
- “不要创建子代理”“不要使用浏览器”等任务级禁止条件在整个任务中持续有效。
- 绝对禁止 Computer Use：不得通过图形界面控制计算机、浏览器或桌面应用——包括以操纵控件为目的的截图、鼠标／键盘模拟、点击、辅助功能 API、窗口自动化、远程桌面控制或 GUI 脚本——也不得把此类交互包装为 API、CLI、MCP Server、辅助程序或其他 Agent 调用来绕过。本节是黑名单而非允许渠道清单：当前 Session 实际暴露且已获授权的其他工具、命令或能力仍然允许。若必需步骤需要借助被禁止的操作，应停止并报告阻塞，而不是尝试、委派或跳过。
- 路线选择或任何委派/Session 拓扑工作前，模式检查点必须组合并验证委派 references；这些 references 在各自的原子边界内规定会话级模式选择及默认多代理路线和单个子代理预算、子代理数量、条件创建、分配、复用、替换、例外和限制。预留预算本身不会初始化或授权创建子代理。
- 不得虚构授权、能力、证据、产品支持，或为未维护场景推导可执行路线。
- Core 规则不依赖具体产品；受支持的运行环境分支和模型绑定见[运行环境与模型厂商支持](../instructions/fundamental-concepts--session-runtime--runtime-provider-support_zh_cn.md)。
- 按需读取 reference。不要仅因为可能以后有用，就预加载整个 Skill、`references/` 或原始项目状态。

# Coding Execution Decision Gate

## 通用规范

### Decision Brief

对于不是简单、局部、低风险、明显、可逆且可机械验证的工作，第一次实质性执行 slice 前应准备简洁的 **Decision Brief**。它记录分析结果而不是 private chain-of-thought，至少应包含：

- `Problem`
- `Known facts`
- `Assumptions and unknowns`
- `Decision questions`
- `Solution envelope`
- `Risks`
- `Acceptance`
- `Stages and checkpoints`

`Acceptance` 作为 Decision Brief 字段记录验收信息；本文档不定义 Acceptance 工作流。

### Decision Checkpoint 与实现放行

当下一阶段依赖高价值判断时，使用阻塞式 Decision Checkpoint，例如存在竞争的架构/API 选择、跨越公共接口/schema/兼容性/安全边界、调试出现实质分叉、范围将大幅扩大，或验证失败需要改变 Contract。

如果仍有实质性决策未解决，只能放行 reconnaissance。返回后确认或否定假设，选择批准方向，更新 Contract 并放行实现。如果新证据改变实质性决策，应暂停当前方向并重新执行决策门禁。不得放行让一个执行者同时分析、选择、实现和验证未定方案的未解决组合指令。

## Codex CLI / ChatGPT Desktop 特别优化指令

Codex 暴露 `/plan` 或 Plan permission mode 时，可用于实质写入前的有界调查及 Decision Brief 草拟。`/review` 能在不修改工作树的情况下检查既有 diff，为重要的修复决策提供依据。生成计划或得到 review 结果都不等于本 Skill 的 Contract／实施 Slice 已放行；新开的独立 review chat 也不自动计为已分配验证 Child。[OpenAI：CLI plan 与 review 命令](https://learn.chatgpt.com/docs/developer-commands)、[OpenAI：review 行为](https://learn.chatgpt.com/docs/code-review)。

## Claude Code CLI / Claude Desktop 特别优化指令

Claude Code 的实质性决策阶段，当前 Session 已获授权的 Plan mode 可以辅助只读调查和草拟 Decision Brief；该模式的启用方法与 Session 边界由[运行环境与模型厂商支持](../instructions/fundamental-concepts--session-runtime--runtime-provider-support_zh_cn.md)负责。Plan mode 只是**工具权限模式**，并非 Semantic Contract、获准修改、用户确认或父级 Slice Release 已通过的证据。即使计划获批，编辑前仍须满足通用 Decision Brief 和当前路线的放行边界。若当前 Session 未暴露已获授权的 Plan-mode 控制，则使用通用有界决策流程。[Anthropic：常见工作流](https://code.claude.com/docs/en/common-workflows)、[Anthropic：权限](https://code.claude.com/docs/en/permissions)。
