# unit.a60497211dd34eb4

[English](unit.a60497211dd34eb4.md) | [简体中文](unit.a60497211dd34eb4_zh_cn.md)

Apply the current instruction and its included policy sections below. The current actions, guards, evidence and failure boundary are given directly. Before applying a named independent policy, obtain its exact instruction continuation; reuse any already held unit from this build and retain the affected action's return position. Do not retrieve author files or infer omitted policy. Check current facts and authorization before effects; an instruction is not a pass.

## Hard constraints

- Record hard user, runtime environment, repository, permission, safety, and Session constraints before acting.
- A task-level prohibition, such as “do not create subagents” or “do not use a browser,” remains active for the whole task.
- Computer Use is categorically forbidden: never control a computer, browser, or desktop app through its graphical interface — no screenshots to locate controls, mouse or keyboard simulation, clicking, accessibility APIs, window automation, remote-desktop control, or GUI scripting — and do not route such interaction through an API, CLI, MCP server, helper, or another Agent. Treat this as a blacklist rather than a list of allowed channels: every other tool, command, or capability actually exposed to and authorized for the current Session remains permitted. If a required step needs a forbidden operation, stop and report the blocker instead of attempting, delegating, or skipping it.
- Before route selection or any delegation/Session-topology work, the Mode checkpoint must compose and validate the delegation references; those references own conversation-level mode selection with a default Multi-Agent route and one-child budget, child counts, conditional creation, allocation, reuse, replacement, exceptions, and limits at their respective atomic boundaries. A reserved budget never initializes or authorizes a child by itself.
- Never invent authorization, capability, evidence, product support, or an executable route for an unmaintained scenario.
- Keep Core rules independent of product details; read Runtime and Model Provider Support (instruction continuation: [unit.081374cfbaa37b57](../instructions/unit.081374cfbaa37b57.md)) for supported runtime branches and model bindings.
- Read references on demand. Do not preload the entire Skill, `references/`, or raw project state merely because it may become useful.

# Advisory selection


This checkpoint owns stage-level applicability routing for optional advice.


## Trigger and inputs

Before Mode and Session pass and authorized Root context exists, record advice as `Not applicable`; use direct authoritative sources for task-intent/output classification. Advice cannot select or change the route selection result, reopen the Mode gate, or change locked mode/count. After authorized Root context exists, the Decision, Control, and Verification/Epoch stages consume only their relevant advice, respectively. Apply Decisions Advisory (instruction continuation: [unit.4d827a8a683055da](../instructions/unit.4d827a8a683055da.md)) and the current direct checkpoint owner; return each suggestion to its named stage for evidence-based review.

## Decision and result

1. Before Mode, Session, and authorized Root context pass, record `Not applicable`; classify task intent and output from direct authoritative sources.
2. At Decision, Control, and Verification/Epoch, assess optional advice only when enabled, eligible, relevant, and the current stage binding and Root authorization are verified.
3. Record the typed suggestion, current policy/input/context hashes, freshness result, and direct-owner comparison. Return it to that stage for a decision from authoritative owners and current evidence.
4. Keep Task Assignment, Output Token Routing, and role-reservation advice outside this five-node opt-in gate; their owners control those decisions independently.
5. Return the reviewed suggestion or `Not applicable` and reason to route scheduling; advice never authorizes work or replaces a pass condition.

## Failure boundary

Stale, unavailable, malformed, or failed advice falls back to direct owner review only when required facts remain sufficient; otherwise block. Do not make external advice calls mandatory or retry around opt-in/authorization limits.
