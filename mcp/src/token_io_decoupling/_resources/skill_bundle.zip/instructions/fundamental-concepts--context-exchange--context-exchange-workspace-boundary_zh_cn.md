# Coding Context Exchange 工作区边界

[English](fundamental-concepts--context-exchange--context-exchange-workspace-boundary.md) | [简体中文](fundamental-concepts--context-exchange--context-exchange-workspace-boundary_zh_cn.md)

下列直接给出当前动作、守卫、证据和失败边界。应用独立政策前，先按明确的指令继续入口取得对应单元；同一构建中已持有的单元直接复用，并保留受影响动作的准确恢复位置。不读取作者文件或推测缺失政策。执行副作用前核实当前事实与授权；指令内容可用不表示检查通过。

## 硬约束

- 采取行动前记录用户、运行环境、仓库、权限、安全和 Session 硬约束。
- “不要创建子代理”“不要使用浏览器”等任务级禁止条件在整个任务中持续有效。
- 绝对禁止 Computer Use：不得通过图形界面控制计算机、浏览器或桌面应用——包括以操纵控件为目的的截图、鼠标／键盘模拟、点击、辅助功能 API、窗口自动化、远程桌面控制或 GUI 脚本——也不得把此类交互包装为 API、CLI、MCP Server、辅助程序或其他 Agent 调用来绕过。本节是黑名单而非允许渠道清单：当前 Session 实际暴露且已获授权的其他工具、命令或能力仍然允许。若必需步骤需要借助被禁止的操作，应停止并报告阻塞，而不是尝试、委派或跳过。
- 路线选择或任何委派/Session 拓扑工作前，模式检查点必须组合并验证委派 references；这些 references 在各自的原子边界内规定会话级模式选择及默认多代理路线和单个子代理预算、子代理数量、条件创建、分配、复用、替换、例外和限制。预留预算本身不会初始化或授权创建子代理。
- 不得虚构授权、能力、证据、产品支持，或为未维护场景推导可执行路线。
- Core 规则不依赖具体产品；受支持的运行环境分支和模型绑定见[运行环境与模型厂商支持](../instructions/fundamental-concepts--session-runtime--runtime-provider-support_zh_cn.md)。
- 按需读取 reference。不要仅因为可能以后有用，就预加载整个 Skill、`references/` 或原始项目状态。

# Coding Context Exchange 工作区边界

## 通用规范

### Memory 名称与逻辑归属

上下文记录使用 Serena 项目 Memory 名称。默认项目数据目录下，名称映射到 `.serena/memories/`，斜杠分段创建子目录，Serena 自动补 `.md`；配置覆盖时遵循配置。保留原记录布局作为名称：`context-exchange/INDEX`；`context-exchange/workers/<worker-context-id>/INDEX`；`context-exchange/workers/<worker-context-id>/content-memo`；以及 `context-exchange/context-bootstrap/MANIFEST`、`.../project-context`、`.../policy-context`。其他 handoff/import 记录沿用原 basename 和子目录意图映射。

Memory 名称只表示逻辑归属。Serena 不为 Memory 记录提供 Worker 级可见性隔离、只读 ACL 或 OS/RW/RO/DENY 强制。工具可能向任何获准 Session 暴露已列出的 Memory。Agent 必须遵守已放行任务对可读写名称的指令，但命名空间和 Serena 项目级模式都不会在技术上强制该规则。不得声称这些记录受目录、`.gitignore`、worktree 或文件系统权限保护。

代码与权威仓库文件访问仍受各自单独批准的文件系统/工具边界约束。Memory capsule 可保存精简事实、准确权威来源指针、hash、新鲜度和范围；不得把来源全文作为权威副本存入 Memory。父级实时 mode/count/allocation/epoch 状态仍归其原 owner，不写入这些 Memory。秘密、完整 transcript 和私有推理仍禁止。

Serena Memory 工具不可用时，报告限制并阻塞依赖读取或写入该上下文记录的工作。不得回退为文件副本。独立工作可以继续。

## Codex CLI / ChatGPT Desktop 特别优化指令

只使用当前 Session 实际暴露且获准的 Serena Memory 工具。依赖记录前先列出并读取具名记录；只写已放行任务授权的名称，并确认写入结果。Codex 文件系统沙箱或 worktree 设置仍约束源文件，但不构成也不代表 Worker 级 Memory 隔离。

## Claude Code CLI / Claude Desktop 特别优化指令

仅当当前 Agent Session 暴露且授权相关 MCP 工具时使用 Serena Memory。Claude Code MCP Tool Search 可能延迟工具定义，因此先发现并核实实际工具。Claude auto memory、worktree 隔离和文件系统规则均不提供 Serena Memory 隔离。能力不可用时按通用报告/阻塞规则处理。
