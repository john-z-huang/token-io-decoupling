# checkpoint.delegation_zh_cn

[English](checkpoint.delegation.md) | [简体中文](checkpoint.delegation_zh_cn.md)

下列直接给出当前动作、守卫、证据和失败边界。应用独立政策前，先按明确的指令继续入口取得对应单元；同一构建中已持有的单元直接复用，并保留受影响动作的准确恢复位置。不读取作者文件或推测缺失政策。执行副作用前核实当前事实与授权；指令内容可用不表示检查通过。

## 硬约束

- 采取行动前记录用户、运行环境、仓库、权限、安全和 Session 硬约束。
- “不要创建子代理”“不要使用浏览器”等任务级禁止条件在整个任务中持续有效。
- 绝对禁止 Computer Use：不得通过图形界面控制计算机、浏览器或桌面应用——包括以操纵控件为目的的截图、鼠标／键盘模拟、点击、辅助功能 API、窗口自动化、远程桌面控制或 GUI 脚本——也不得把此类交互包装为 API、CLI、MCP Server、辅助程序或其他 Agent 调用来绕过。本节是黑名单而非允许渠道清单：当前 Session 实际暴露且已获授权的其他工具、命令或能力仍然允许。若必需步骤需要借助被禁止的操作，应停止并报告阻塞，而不是尝试、委派或跳过。
- 路线选择或任何委派/Session 拓扑工作前，模式检查点必须组合并验证委派 references；这些 references 在各自的原子边界内规定会话级模式选择及默认多代理路线和单个子代理预算、子代理数量、条件创建、分配、复用、替换、例外和限制。预留预算本身不会初始化或授权创建子代理。
- 不得虚构授权、能力、证据、产品支持，或为未维护场景推导可执行路线。
- Core 规则不依赖具体产品；受支持的运行环境分支和模型绑定见运行环境与模型厂商支持 (instruction continuation: [unit.081374cfbaa37b57](../instructions/unit.081374cfbaa37b57_zh_cn.md))。
- 按需读取 reference。不要仅因为可能以后有用，就预加载整个 Skill、`references/` 或原始项目状态。

### 记录结构

路线放行前维护以下规范状态记录：

```text
owner: <根父级身份>
run_id: unset | <本次 Multi-Agent 委派运行的稳定标识>
gate_status: awaiting-mode | awaiting-count | released | blocked
mode_source: unset | explicit | default | timeout-default（仅兼容旧记录）
mode: unset | Single-Agent Coding | Multi-Agent Coding
child_count: unset | 0 | <已锁定正整数>
source: <当前模式/数量决策的 SemanticRef>
semantic_references: [<保留的 SemanticRef，包括先前数量来源>]
allocations: [{allocation_id: <稳定的子代理 allocation 标识>,
               agent: unbound | <已创建代理身份>, role: unassigned | <职责>,
               slice_status: pending | released, interaction_slice, scope, mutations,
               return_conditions, lifecycle, write_content_memo}]
session_audit: {audit_mode, root_reasoning_cadence, worker_reasoning_cadence,
                source: {audit_mode: explicit | default, root_reasoning_cadence: explicit | default,
                        worker_reasoning_cadence: explicit | default},
                worker_log_visibility: available | unverified | unavailable | Not applicable,
                worker_log_evidence}
lifecycle: pending | running | completed | interrupted
unavailable_capabilities: [<能力名称>]
block_reason: <仅 blocked 时必需>
```

所选工作流路线记录用户显式偏好或规定的缺省值；该记录继续保留模式/数量、allocations、任务范围和生命周期状态。

| `gate_status` | 模式与数量 | Allocation 和 lifecycle | 其他要求 |
| --- | --- | --- | --- |
| `awaiting-mode` | 未设置 | `[]`；顶层 `pending` | 记录首次明确选择或默认值前先初始化。 |
| `awaiting-count` | Multi-Agent；数量未设置 | `[]`；顶层 `pending` | 仅明确给出无效数量时进入；省略数量时默认 1。 |
| `released` — Single-Agent | Single-Agent；数量 `0` | `[]`；顶层 lifecycle 必需 | 放行单代理路线，不授予独立 Session。`timeout-default` 仅作为旧记录来源接受并读回。 |
| `released` — Multi-Agent | Multi-Agent；已锁定正整数 | 恰好 `child_count` 个预留 allocation；`run_id` 已设置；每个 allocation 有唯一且稳定的 `allocation_id`，并初始为 `agent: unbound`、`role: unassigned`、`slice_status: pending`、`lifecycle: pending` | 只放行路线与数量预算，**不**放行具体子代理或 Interaction Slice。 |
| `blocked` | 保留已确认值 | 保留现有 allocation/lifecycle | `unavailable_capabilities` 与 `block_reason` 必需；不得进入依赖路线。 |

初始数量只预留恰好对应数量的未分配名额；预留本身不选择职责。一个名额的预算不会自动分配 Primary Output。审阅任务上下文和 Decision 后，由职责选择 owner 提供职责建议，或由 Root 直接判断；然后将选定的唯一职责记录到一个未分配名额。具体 `slice_status: released` 必须具备已分配 `role`、`interaction_slice`、`scope`、`mutations`、`return_conditions` 和显式布尔 `write_content_memo`；pending Slice 可以暂不设置这些字段。序列化每个已放行 Worker bundle 前，必须显式写入 `write_content_memo: true` 或 `false`，Worker 不得推断默认值。Child Creation 只能在相应职责和 Slice 已放行后绑定 `agent` 与 lifecycle。后续 Slice 可在**同一个**已创建子代理上准备，不创建或回收名额。

`mode_source` 和 `source` 记录当前模式/数量决策。本次会话中的模式保持固定。同会话唯一允许的数量变更，是按数量门禁获批增加一个名额：将 `mode_source` 设为 `explicit`，将 `source` 设为实际批准引用，并在 `semantic_references` 中保留先前来源。受保护的预留回执记录新旧数量及经 Root 审阅的批准引用。不得把建议推断成批准，也不得绕过此事务修改数量。新会话不再写入 `timeout-default`；仅为读回按旧规则创建的会话而接受该来源。旧 `timeout-default` 记录必须保持 Single-Agent、`child_count: 0` 和 `allocations: []`；读回时不得重新解释或迁移。各 allocation 的 lifecycle 可不同于顶层任务的 lifecycle。阻塞保留已确认值；后续指令中，Fork 或其他重入遵循 Re-entry owner，唯一获批扩展遵循数量门禁。

未经修改的初始 `mode_source: default` 记录必须是 Multi-Agent、`child_count: 1` 且恰好有一个预留 allocation；此预留不会初始化子代理。用户批准增加名额后，记录来源变为 explicit。所有已放行 Multi-Agent 记录都必须满足 `child_count` 等于 allocation 名额数量。当前会话中的每项职责和已绑定子代理身份都唯一；即使子代理已完成、失败、中断、取消或不可用也一样，生命周期变化不会释放职责。Native 导入或恢复必须拒绝重复职责或子代理身份。Fork 只有在重新通过模式/数量门禁后才能创建新记录，不得把来源 Session 的子代理身份导入为当前 allocation。实际子代理创建仍受输出类型和 Slice 门禁约束。

`session_audit` 遵循会话审计可见性 (instruction continuation: [unit.6063588dfa2ee6c4](../instructions/unit.6063588dfa2ee6c4_zh_cn.md))定义的字段。仅根父级写入生效偏好及各字段来源。未提供显式偏好时，立即采用规定的缺省值。Worker 日志证据仅在首次需要或出现新的实际能力/访问证据或失败时更新，不逐消息更新。此状态不得改变 `mode`、`child_count`、授权、allocation 或 Slice 放行。不得将完整 Root 审计记录复制到策略文件或 Worker 可控状态中。
