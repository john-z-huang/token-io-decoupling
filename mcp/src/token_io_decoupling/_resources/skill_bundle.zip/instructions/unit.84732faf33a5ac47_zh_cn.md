# unit.84732faf33a5ac47_zh_cn

[English](unit.84732faf33a5ac47.md) | [简体中文](unit.84732faf33a5ac47_zh_cn.md)

下列直接给出当前动作、守卫、证据和失败边界。应用独立政策前，先按明确的指令继续入口取得对应单元；同一构建中已持有的单元直接复用，并保留受影响动作的准确恢复位置。不读取作者文件或推测缺失政策。执行副作用前核实当前事实与授权；指令内容可用不表示检查通过。

## 硬约束

- 采取行动前记录用户、运行环境、仓库、权限、安全和 Session 硬约束。
- “不要创建子代理”“不要使用浏览器”等任务级禁止条件在整个任务中持续有效。
- 绝对禁止 Computer Use：不得通过图形界面控制计算机、浏览器或桌面应用——包括以操纵控件为目的的截图、鼠标／键盘模拟、点击、辅助功能 API、窗口自动化、远程桌面控制或 GUI 脚本——也不得把此类交互包装为 API、CLI、MCP Server、辅助程序或其他 Agent 调用来绕过。本节是黑名单而非允许渠道清单：当前 Session 实际暴露且已获授权的其他工具、命令或能力仍然允许。若必需步骤需要借助被禁止的操作，应停止并报告阻塞，而不是尝试、委派或跳过。
- 路线选择或任何委派/Session 拓扑工作前，模式检查点必须组合并验证委派 references；这些 references 在各自的原子边界内规定会话级模式选择及默认多代理路线和单个子代理预算、子代理数量、条件创建、分配、复用、替换、例外和限制。预留预算本身不会初始化或授权创建子代理。
- 不得虚构授权、能力、证据、产品支持，或为未维护场景推导可执行路线。
- Core 规则不依赖具体产品；受支持的运行环境分支和模型绑定见运行环境与模型厂商支持 (instruction continuation: [unit.081374cfbaa37b57](../instructions/unit.081374cfbaa37b57_zh_cn.md))。
- 按需读取 reference。不要仅因为可能以后有用，就预加载整个 Skill、`references/` 或原始项目状态。

# 上下文来源选择


本检查点负责路线级 active plan、有界规则查询、可复用项目记忆和持久交换上下文的选择与核验流程。

## 触发与输入

Session 已解决后，根据已验证事实和任务范围执行上下文来源选择。应用Context (instruction continuation: [unit.d2e88709b902fca6](../instructions/unit.d2e88709b902fca6_zh_cn.md))、Session Context Firewall (instruction continuation: [unit.95aba471482062c9](../instructions/unit.95aba471482062c9_zh_cn.md))、项目 Memory 与代码结构能力 (instruction continuation: [unit.eb35e270023c9aac](../instructions/unit.eb35e270023c9aac_zh_cn.md))、工作流规则上下文 (instruction continuation: [unit.b2c56bb76a6f6521](../instructions/unit.b2c56bb76a6f6521_zh_cn.md))，并在触发条件成立时应用 context-exchange owners。

## 决策与结果

1. 定义当前最小 Context 问题、任务范围及可回答它的来源类别。应用 Context owner；不读取无关项目状态。
2. 始终列出 `plans/` 中本任务的活动计划 Memory，并读取每个匹配项。依据当前指令、任务匹配、来源指针和新鲜度核对每项；当前指令优先，计划不授予授权。无匹配活动计划时记录 `Not applicable` 和原因。若无法列出或读取相关活动计划，阻塞依赖工作；不得用文件替代该计划。
3. 若问题需要此前工作的可复用项目知识，列出项目 Memory 并读取相关项；对照权威项目文件核验来源指针和新鲜度。无相关项或无需跨会话知识时，记录 `Not applicable` 和原因。Memory 不可用时返回已批准的权威项目文件；仅当必需事实无法另行确认时阻塞。此回退适用于普通可复用项目知识，不适用于第 2 步必需的活动计划查询/读取。
4. 当前问题需要工作流指令时，按工作流规则上下文消费同一构建、语言的明确当前编译节点或单元，核验标识、完整性及未解决事实；在依赖动作前取得每个明确指令继续入口，保留准确返回位置。可选有界导航不需要时，记录 `Not applicable` 并消费对应已交付指令；可选导航不可用时，可由实际可用且获授权的同构建生成纯文档入口提供单元。必需资源缺失、损坏、不完整或不兼容时阻塞依赖判断，绝不查找作者 owner 或推断遗漏政策。
5. 应用 Session Context Firewall 限制来源范围和入口。需要 Worker memo 或 memo 派发时，应用内容 Memo 派发 (instruction continuation: [unit.90ad9fe16c44d13f](../instructions/unit.90ad9fe16c44d13f_zh_cn.md))及其内容 Memo 生命周期 (instruction continuation: [unit.26341c60191650ce](../instructions/unit.26341c60191650ce_zh_cn.md))，核验必需的 Memory 能力与证据，作为之后获授权 Worker memo 派发的证据；未触发时记录 `Not applicable` 及原因。Worker 需要跨 Worker 交换/bootstrap 时，应用工作流 Context Exchange (instruction continuation: [unit.439bedbb36334cd3](../instructions/unit.439bedbb36334cd3_zh_cn.md))及工作区边界 (instruction continuation: [unit.0a54c601ab09a7e6](../instructions/unit.0a54c601ab09a7e6_zh_cn.md))。仅在具体交接或恢复时应用Context Exchange Handoff (instruction continuation: [unit.2d0f4872b823ef44](../instructions/unit.2d0f4872b823ef44_zh_cn.md))。按各自 owner 分别判断独立触发条件，并核验必需的持久 Memory 能力和证据。不得仅因收集 Context 而创建交换记录。必需的交换能力不可用时，阻塞依赖工作；owner 要求的持久记录不得回退为文件。
6. 返回带来源指针、来源溯源、新鲜度/epoch 及限制说明的最小当前事实。关键上下文过期、不完整或冲突时阻塞依赖决策。memo 适用性、同意和持久化仍由各自 owner 负责。

## 失败边界

关键上下文过期、不可访问或冲突时，阻塞依赖它的决策。不得扩大来源范围、从记忆推断授权或绕过必需 Memory 能力。
