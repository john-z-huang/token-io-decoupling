# Coding Child Reuse and Replacement

[English](fundamental-concepts--delegation--delegation-child-reuse-replacement.md) | [简体中文](fundamental-concepts--delegation--delegation-child-reuse-replacement_zh_cn.md)

Apply the current instruction and its included policy sections below. The current actions, guards, evidence and failure boundary are given directly. Before applying a named independent policy, obtain its exact instruction continuation; reuse any already held unit from this build and retain the affected action's return position. Do not retrieve author files or infer omitted policy. Check current facts and authorization before effects; an instruction is not a pass.

## Hard constraints

- Record hard user, runtime environment, repository, permission, safety, and Session constraints before acting.
- A task-level prohibition, such as “do not create subagents” or “do not use a browser,” remains active for the whole task.
- Computer Use is categorically forbidden: never control a computer, browser, or desktop app through its graphical interface — no screenshots to locate controls, mouse or keyboard simulation, clicking, accessibility APIs, window automation, remote-desktop control, or GUI scripting — and do not route such interaction through an API, CLI, MCP server, helper, or another Agent. Treat this as a blacklist rather than a list of allowed channels: every other tool, command, or capability actually exposed to and authorized for the current Session remains permitted. If a required step needs a forbidden operation, stop and report the blocker instead of attempting, delegating, or skipping it.
- Before route selection or any delegation/Session-topology work, the Mode checkpoint must compose and validate the delegation references; those references own conversation-level mode selection with a default Multi-Agent route and one-child budget, child counts, conditional creation, allocation, reuse, replacement, exceptions, and limits at their respective atomic boundaries. A reserved budget never initializes or authorizes a child by itself.
- Never invent authorization, capability, evidence, product support, or an executable route for an unmaintained scenario.
- Keep Core rules independent of product details; read [Runtime and Model Provider Support](../instructions/fundamental-concepts--session-runtime--runtime-provider-support.md) for supported runtime branches and model bindings.
- Read references on demand. Do not preload the entire Skill, `references/`, or raw project state merely because it may become useful.

# Coding Child Reuse and Replacement

## General rules

### Authorized reuse

Model and reasoning-effort settings are checked only during creation. A follow-up, repair, compaction, interruption, wake, or resume of the same child must not repeat the check or ask the child to inspect or report those settings. Continue to apply the child identity, lifecycle, authorization, scope, and return-path rules in this module.

For authorized follow-ups, repaired epochs, and interruptions, reuse the same created child when safe. First attempt an authorized repair through that child; if it cannot safely continue, report the blocker and set dependent Multi-Agent work to `blocked`. Reuse must not create a recursive hierarchy or peer coordination. Retain the created child's identity and evidence according to the lifecycle owner.

### Replacement relation

A parent-authorized plan revision may adjust the unbound role or pending slice of an `agent: unbound` allocation before that slot's child is created, within the current approved count. Before count locking, the awaiting-count record has no allocation to revise. Within the existing count, an additional child may use an unassigned slot and an unoccupied role through the normal release and creation gates. A created child's identity, slot, and role are permanent in this Session; never recycle or replace them. Any child above the current count requires the [Delegation Count Gate](../instructions/fundamental-concepts--delegation--delegation-mode-count-gate.md)'s actual user approval for exactly one additional slot and a different unoccupied role. That approval never authorizes replacement or a repeated role. Do not reopen the count question, fork, or hand off to a new child as a way to bypass these gates. Context handoff is owned by [Coding Context Exchange Handoff](../instructions/fundamental-concepts--context-exchange--context-exchange-handoff.md) and does not grant an Agent-creation capability.

## Codex CLI / ChatGPT Desktop optimizations

### Reuse the allocated Codex thread

When the host exposes parent-controlled steering or an actual follow-up to a recorded Codex child thread, address that same identity for its authorized repair or next epoch. A Session-exposed `/agent` or direct child-thread tool can locate the recorded identity. A distinct Session or worktree returned by an exposed tool does not establish continuity with the allocated child. Requesting a fresh subagent creates a distinct identity and must not be disguised as reuse after count locking. If the original thread cannot be steered or continued through an exposed tool, keep its evidence and block the dependent Multi-Agent slice. [OpenAI: subagent orchestration and thread controls](https://learn.chatgpt.com/docs/agent-configuration/subagents), [OpenAI: worktree behavior](https://learn.chatgpt.com/docs/environments/git-worktrees).

## Claude Code CLI / Claude Desktop optimizations

Use `SendMessage` with the returned Agent ID for an authorized follow-up or repair of the same child. Calling `Agent` again creates another child and consumes another slot; do not use it for reuse after count locking.

### Resume identity, do not respawn

Resume an authorized persistent `general-purpose` or custom subagent with `SendMessage` addressed to its returned `agent_id` (or the supported agent name) and a narrow repair/follow-up prompt. A fresh `Agent` invocation creates a distinct instance even if its type and prompt match; never use it as a hidden replacement under the locked budget. Built-in `Explore` and `Plan` are one-shot and return no resumable ID; do not assign them to a slot that requires later follow-up. If resume fails, preserve the error and block dependent work rather than trying another child. A Claude Desktop connector tool call is not a substitute for `SendMessage` to the recorded Agent identity unless its result explicitly provides that parent-controlled relation.

Official reference: [resume subagents](https://code.claude.com/docs/en/sub-agents).

An agent-team message or `/branch` cannot substitute for resuming the recorded Agent identity. If the original child ID is no longer resumable, keep its evidence and block the dependent slice; do not spend an unapproved replacement slot. [Anthropic: subagent resume](https://code.claude.com/docs/en/sub-agents).
