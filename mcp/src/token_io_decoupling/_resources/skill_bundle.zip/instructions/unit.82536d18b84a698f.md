# unit.82536d18b84a698f

[English](unit.82536d18b84a698f.md) | [简体中文](unit.82536d18b84a698f_zh_cn.md)

Apply the current instruction and its included policy sections below. The current actions, guards, evidence and failure boundary are given directly. Before applying a named independent policy, obtain its exact instruction continuation; reuse any already held unit from this build and retain the affected action's return position. Do not retrieve author files or infer omitted policy. Check current facts and authorization before effects; an instruction is not a pass.

## Hard constraints

- Record hard user, runtime environment, repository, permission, safety, and Session constraints before acting.
- A task-level prohibition, such as “do not create subagents” or “do not use a browser,” remains active for the whole task.
- Computer Use is categorically forbidden: never control a computer, browser, or desktop app through its graphical interface — no screenshots to locate controls, mouse or keyboard simulation, clicking, accessibility APIs, window automation, remote-desktop control, or GUI scripting — and do not route such interaction through an API, CLI, MCP server, helper, or another Agent. Treat this as a blacklist rather than a list of allowed channels: every other tool, command, or capability actually exposed to and authorized for the current Session remains permitted. If a required step needs a forbidden operation, stop and report the blocker instead of attempting, delegating, or skipping it.
- Before route selection or any delegation/Session-topology work, the Mode checkpoint must compose and validate the delegation references; those references own conversation-level mode selection with a default Multi-Agent route and one-child budget, child counts, conditional creation, allocation, reuse, replacement, exceptions, and limits at their respective atomic boundaries. A reserved budget never initializes or authorizes a child by itself.
- Never invent authorization, capability, evidence, product support, or an executable route for an unmaintained scenario.
- Keep Core rules independent of product details; read Runtime and Model Provider Support (instruction continuation: [unit.081374cfbaa37b57](../instructions/unit.081374cfbaa37b57.md)) for supported runtime branches and model bindings.
- Read references on demand. Do not preload the entire Skill, `references/`, or raw project state merely because it may become useful.

# Worker Content Memo

## General rules

### Purpose and content

Use the memory name `context-exchange/workers/<worker-context-id>/content-memo`, which Serena maps to `.serena/memories/context-exchange/workers/<worker-context-id>/content-memo.md` under its default project data directory. Serena configuration may change that directory. The name identifies logical ownership only: Serena does not enforce Worker-specific visibility, read-only access, or filesystem isolation, and any Session with the relevant tools may see or change the Memory. Follow the released task's ownership instructions and never claim technical isolation.

Worker-authored prose uses Chinese. Preserve paths, filenames, commands, symbols, keys, hashes, exact errors, and log fragments in original form. Record only stable, reusable execution state: completed results, findings, changed paths/symbols, verification evidence, failed approaches, remaining work, blockers, and handoff needs. Keep accurate pointers to authoritative sources; do not store their full text as an authoritative copy.

### Prohibited material and unavailable capability

Do not write a per-command journal, full logs/diffs, large source copies, secrets, private reasoning, complete transcripts, unrelated history, or live parent mode/count/allocation/epoch state. If Serena Memory read/write is unavailable, report the limitation and block work that depends on this record; do not write the record to a file as fallback. Independent work may continue.

## Codex CLI / ChatGPT Desktop optimizations

Use only Serena Memory tools actually exposed and authorized in the current Session. Codex-local memories and `/compact` do not replace the named Serena Memory. Confirm a successful write result and verify the stored entry with `read_memory` when the active workflow requires it.

## Claude Code CLI / Claude Desktop optimizations

Use Serena Memory only if the current Session exposes and authorizes the relevant Serena MCP tools. Claude auto memory and compaction do not replace this named project Memory. Confirm the actual tool availability and write result; Serena Memory access is not shared or isolated by assumption.
