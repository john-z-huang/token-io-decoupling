# unit.006f9eef4b46c673

[English](unit.006f9eef4b46c673.md) | [简体中文](unit.006f9eef4b46c673_zh_cn.md)

Apply the current instruction and its included policy sections below. The current actions, guards, evidence and failure boundary are given directly. Before applying a named independent policy, obtain its exact instruction continuation; reuse any already held unit from this build and retain the affected action's return position. Do not retrieve author files or infer omitted policy. Check current facts and authorization before effects; an instruction is not a pass.

## Hard constraints

- Record hard user, runtime environment, repository, permission, safety, and Session constraints before acting.
- A task-level prohibition, such as “do not create subagents” or “do not use a browser,” remains active for the whole task.
- Computer Use is categorically forbidden: never control a computer, browser, or desktop app through its graphical interface — no screenshots to locate controls, mouse or keyboard simulation, clicking, accessibility APIs, window automation, remote-desktop control, or GUI scripting — and do not route such interaction through an API, CLI, MCP server, helper, or another Agent. Treat this as a blacklist rather than a list of allowed channels: every other tool, command, or capability actually exposed to and authorized for the current Session remains permitted. If a required step needs a forbidden operation, stop and report the blocker instead of attempting, delegating, or skipping it.
- Before route selection or any delegation/Session-topology work, the Mode checkpoint must compose and validate the delegation references; those references own conversation-level mode selection with a default Multi-Agent route and one-child budget, child counts, conditional creation, allocation, reuse, replacement, exceptions, and limits at their respective atomic boundaries. A reserved budget never initializes or authorizes a child by itself.
- Never invent authorization, capability, evidence, product support, or an executable route for an unmaintained scenario.
- Keep Core rules independent of product details; read Runtime and Model Provider Support (instruction continuation: [unit.081374cfbaa37b57](../instructions/unit.081374cfbaa37b57.md)) for supported runtime branches and model bindings.
- Read references on demand. Do not preload the entire Skill, `references/`, or raw project state merely because it may become useful.

# Repair disposition


This checkpoint owns route-level recovery and re-verification routing after failure or a material decision change.


## Trigger and inputs

After a failed current Verification or a material decision change, use this checkpoint to route recovery. Apply Repair (instruction continuation: [unit.6dda2ed61cb61569](../instructions/unit.6dda2ed61cb61569.md)), Repair Scope Gate (instruction continuation: [unit.74f6aa64994e9f30](../instructions/unit.74f6aa64994e9f30.md)), Repair Execution (instruction continuation: [unit.42e9ccbf8fdaa24a](../instructions/unit.42e9ccbf8fdaa24a.md)), and Repair Verification Handoff (instruction continuation: [unit.5ca52cb1934d946b](../instructions/unit.5ca52cb1934d946b.md)).

## Decision and result

1. Require concrete failing evidence, affected paths, and the smallest repair candidate. A semantic change without a concrete failure is not a Repair; route it as a material decision change.
2. Apply the Repair scope gate against the current Contract and Decision. Release only the authorized narrow repair and its focused checks.
3. Capture the repair handoff, new fingerprint, and affected epochs; send current evidence to Verification and re-run every required check for changed epochs before dependent work.
4. A material decision change returns its changed Contract/Decision facts and evidence to the caller for renewed Contract and Decision review and route scheduling. Without a concrete failure, return Repair `Not applicable` and its evidence basis. If an accepted epoch changes, require current Verification evidence before dependent work proceeds.

## Failure boundary

Missing diagnosis, authorization, bounded scope, handoff evidence, or changed-epoch re-verification blocks the dependent route. Do not treat repair intent as authorization or reuse stale pass evidence.
