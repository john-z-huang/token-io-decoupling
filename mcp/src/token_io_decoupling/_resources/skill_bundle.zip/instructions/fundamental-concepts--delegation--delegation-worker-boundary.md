# Coding Delegation Worker Boundary

[English](fundamental-concepts--delegation--delegation-worker-boundary.md) | [简体中文](fundamental-concepts--delegation--delegation-worker-boundary_zh_cn.md)

Apply the current instruction and its included policy sections below. The current actions, guards, evidence and failure boundary are given directly. Before applying a named independent policy, obtain its exact instruction continuation; reuse any already held unit from this build and retain the affected action's return position. Do not retrieve author files or infer omitted policy. Check current facts and authorization before effects; an instruction is not a pass.

## Hard constraints

- Record hard user, runtime environment, repository, permission, safety, and Session constraints before acting.
- A task-level prohibition, such as “do not create subagents” or “do not use a browser,” remains active for the whole task.
- Computer Use is categorically forbidden: never control a computer, browser, or desktop app through its graphical interface — no screenshots to locate controls, mouse or keyboard simulation, clicking, accessibility APIs, window automation, remote-desktop control, or GUI scripting — and do not route such interaction through an API, CLI, MCP server, helper, or another Agent. Treat this as a blacklist rather than a list of allowed channels: every other tool, command, or capability actually exposed to and authorized for the current Session remains permitted. If a required step needs a forbidden operation, stop and report the blocker instead of attempting, delegating, or skipping it.
- Before route selection or any delegation/Session-topology work, the Mode checkpoint must compose and validate the delegation references; those references own conversation-level mode selection with a default Multi-Agent route and one-child budget, child counts, conditional creation, allocation, reuse, replacement, exceptions, and limits at their respective atomic boundaries. A reserved budget never initializes or authorizes a child by itself.
- Never invent authorization, capability, evidence, product support, or an executable route for an unmaintained scenario.
- Keep Core rules independent of product details; read [Runtime and Model Provider Support](../instructions/fundamental-concepts--session-runtime--runtime-provider-support.md) for supported runtime branches and model bindings.
- Read references on demand. Do not preload the entire Skill, `references/`, or raw project state merely because it may become useful.

# Coding Delegation Worker Boundary

## General rules

### Worker snapshot and access boundary

Workers receive only the relevant released snapshot through the parent-controlled Dispatch. They must not infer, mutate, or replace the root record. The Worker may use the snapshot only within the released scope and return the required facts through the parent-controlled path.

### Dispatch entry and persistence block

After release, a Worker enters through the parent-provided Dispatch Preview and does not reopen the root-user mode or count gates. If the runtime cannot persist or return the task-control record, the dependent route is blocked.

### Shared task-plan contribution

Apply [Task Plan Memory Lifecycle](../instructions/fundamental-concepts--execution-planning--task-plan-memory-lifecycle.md) to every assigned role. Dispatch names the exact project and shared plan, permitted contribution, and any authorized current record-writer turn. The Worker confirms only the access its released role requires; it uses current plan context or obtains needed content at that owner's refresh triggers. Submit sourced facts and progress through the authorized record writer or contribution path at owner-defined boundaries; an ordinary progress report does not independently trigger a write or full readback. Record changed requirements before analysis, then persist the analysis/revised proposal and complete any owner-required verification before requesting parent release. Facts affecting authorization, scope, acceptance, direction, or dependent actions must be recorded and analyzed before those actions. This named contribution is separate from the root record and optional execution memo; it grants no source/peer access or Contract authority. A verifier may contribute verification facts only. Missing required access, failed persistence, or failed required verification blocks dependent work and must be reported to the parent.

## Codex CLI / ChatGPT Desktop optimizations

Codex's configured `PreToolUse` hook can match the local `spawn_agent` tool under its `Agent` alias; where available, use it as a tested guardrail against unauthorized nested delegation, alongside the runtime's actual tool/sandbox restrictions. Some specialized tools bypass hook coverage, so a prompt or hook alone is not proof that recursion or peer messaging is impossible. Keep the parent-controlled spawn/follow-up role separate from Worker permissions. [OpenAI: hook tool coverage](https://learn.chatgpt.com/docs/hooks).

### Effective worker authority

A Codex custom agent file can set `developer_instructions`, `sandbox_mode`, scoped `mcp_servers` and `skills.config`, but omitted fields inherit the parent and live parent permission overrides can be reapplied at spawn. Inspect the resulting child rather than trusting the file's intended profile. Where a trusted `PreToolUse` hook is installed, match local `spawn_agent`/`Agent` and exposed peer operations before executing, but no hook can prove a complete deny boundary for tools outside its coverage; use real runtime/OS restrictions or block the dependent Worker. [OpenAI: inherited subagent settings](https://learn.chatgpt.com/docs/agent-configuration/subagents), [OpenAI: tool-hook exceptions](https://learn.chatgpt.com/docs/hooks).

## Claude Code CLI / Claude Desktop optimizations

### Scoped worker tools

For an approved Claude Code custom Worker, restrict the frontmatter `tools` allowlist and/or `disallowedTools` so the Worker cannot call `Agent` or peer-messaging tools. An Agent tool made available to the Worker can create nested subagents in current Claude Code; a prose-only prohibition is not a reliable tool boundary. If an MCP server is needed, grant only the required server/tool scope and deny unrelated MCP tools (for example, supported `mcp__<server>` patterns); this narrows tool availability, not the parent's record ownership. Project/user agent definitions can also scope `mcpServers`, but plugin-shipped agent frontmatter ignores that field. Do not assume the same restrictions are installed in Desktop Chat.

Official reference: [subagent tools, disallowedTools and MCP scope](https://code.claude.com/docs/en/sub-agents).

Before dispatch, check that the **effective**, inherited custom-agent tool pool matches the released role. Keep parent-to-child `SendMessage` and resume controls outside the Worker, and do not treat a narrowed `tools` list as a verified per-path filesystem boundary. [Anthropic: subagent tool scope](https://code.claude.com/docs/en/sub-agents).
