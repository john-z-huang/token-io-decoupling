# Coding Context Exchange

[English](fundamental-concepts--context-exchange--context-exchange.md) | [简体中文](fundamental-concepts--context-exchange--context-exchange_zh_cn.md)

下列直接给出当前动作、守卫、证据和失败边界。应用独立政策前，先按明确的指令继续入口取得对应单元；同一构建中已持有的单元直接复用，并保留受影响动作的准确恢复位置。不读取作者文件或推测缺失政策。执行副作用前核实当前事实与授权；指令内容可用不表示检查通过。

## 硬约束

- 采取行动前记录用户、运行环境、仓库、权限、安全和 Session 硬约束。
- “不要创建子代理”“不要使用浏览器”等任务级禁止条件在整个任务中持续有效。
- 绝对禁止 Computer Use：不得通过图形界面控制计算机、浏览器或桌面应用——包括以操纵控件为目的的截图、鼠标／键盘模拟、点击、辅助功能 API、窗口自动化、远程桌面控制或 GUI 脚本——也不得把此类交互包装为 API、CLI、MCP Server、辅助程序或其他 Agent 调用来绕过。本节是黑名单而非允许渠道清单：当前 Session 实际暴露且已获授权的其他工具、命令或能力仍然允许。若必需步骤需要借助被禁止的操作，应停止并报告阻塞，而不是尝试、委派或跳过。
- 路线选择或任何委派/Session 拓扑工作前，模式检查点必须组合并验证委派 references；这些 references 在各自的原子边界内规定会话级模式选择及默认多代理路线和单个子代理预算、子代理数量、条件创建、分配、复用、替换、例外和限制。预留预算本身不会初始化或授权创建子代理。
- 不得虚构授权、能力、证据、产品支持，或为未维护场景推导可执行路线。
- Core 规则不依赖具体产品；受支持的运行环境分支和模型绑定见[运行环境与模型厂商支持](../instructions/fundamental-concepts--session-runtime--runtime-provider-support_zh_cn.md)。
- 按需读取 reference。不要仅因为可能以后有用，就预加载整个 Skill、`references/` 或原始项目状态。

# Coding Context Exchange

## 通用规范

### Capsule 内容与权威来源

只有已授权 handoff 或 context bootstrap 需要持久记录时才写入 capsule。内容限于精简中性事实、指向权威来源的准确指针、hash、新鲜度/失效数据和窄范围证据指针。不得把来源文件全文复制到 Memory；权威仓库文件仍具有约束力。接收 Worker 只读取已放行任务中点名的 capsule Memory，再对照获准且点名的来源核实所需事实。

使用以下 bootstrap Memory 名称保留原文件名：`context-exchange/context-bootstrap/MANIFEST`、`context-exchange/context-bootstrap/project-context` 和 `context-exchange/context-bootstrap/policy-context`。`MANIFEST` 记录快照身份、hash 和新鲜度规则；其他 Memory 保存中性项目事实/指针及 policy-routing 指针。其他交换/import 记录在 `context-exchange/` 下沿用原 basename 和子目录意图。

根据 `HEAD`/tree、tracked-delta fingerprint、所列来源 hash、相关未跟踪状态和当前 task/scope 检查新鲜度。实质字段变化时只刷新受影响条目；否则直接读取点名权威来源。Capsule 不能替代 Contract 或最终状态的独立验证。Memory 列表/读写能力不可用时，报告限制并阻塞依赖工作；不得回退为文件存储。

## Codex CLI / ChatGPT Desktop 特别优化指令

只使用实际暴露且获准的 Serena Memory 工具。在已放行任务中点名准确 capsule Memory，使用前先读取并核验来源指针/新鲜度，写入后确认结果。不得仅为加载 capsule 而扩大来源或工具权限。

## Claude Code CLI / Claude Desktop 特别优化指令

仅当当前 Agent Session 暴露且授权 Serena MCP 工具时使用 Serena Memory。Claude Code MCP Tool Search 可能延迟工具定义；依赖前先发现并核实工具。Claude auto memory 或 compaction 不能替代具名交换 capsule。
