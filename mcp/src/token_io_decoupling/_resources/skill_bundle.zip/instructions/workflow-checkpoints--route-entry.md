# Coding route entry

[English](workflow-checkpoints--route-entry.md) | [简体中文](workflow-checkpoints--route-entry_zh_cn.md)

Apply the current instruction and its included policy sections below. The current actions, guards, evidence and failure boundary are given directly. Before applying a named independent policy, obtain its exact instruction continuation; reuse any already held unit from this build and retain the affected action's return position. Do not retrieve author files or infer omitted policy. Check current facts and authorization before effects; an instruction is not a pass.

## Hard constraints

- Record hard user, runtime environment, repository, permission, safety, and Session constraints before acting.
- A task-level prohibition, such as “do not create subagents” or “do not use a browser,” remains active for the whole task.
- Computer Use is categorically forbidden: never control a computer, browser, or desktop app through its graphical interface — no screenshots to locate controls, mouse or keyboard simulation, clicking, accessibility APIs, window automation, remote-desktop control, or GUI scripting — and do not route such interaction through an API, CLI, MCP server, helper, or another Agent. Treat this as a blacklist rather than a list of allowed channels: every other tool, command, or capability actually exposed to and authorized for the current Session remains permitted. If a required step needs a forbidden operation, stop and report the blocker instead of attempting, delegating, or skipping it.
- Before route selection or any delegation/Session-topology work, the Mode checkpoint must compose and validate the delegation references; those references own conversation-level mode selection with a default Multi-Agent route and one-child budget, child counts, conditional creation, allocation, reuse, replacement, exceptions, and limits at their respective atomic boundaries. A reserved budget never initializes or authorizes a child by itself.
- Never invent authorization, capability, evidence, product support, or an executable route for an unmaintained scenario.
- Keep Core rules independent of product details; read [Runtime and Model Provider Support](../instructions/fundamental-concepts--session-runtime--runtime-provider-support.md) for supported runtime branches and model bindings.
- Read references on demand. Do not preload the entire Skill, `references/`, or raw project state merely because it may become useful.

# Coding route entry


This checkpoint owns pre-route validation composition and the unique authorized route-selection result.

## Trigger and inputs

The Coding entry invokes this checkpoint after the [Contract checkpoint](../instructions/workflow-concepts--entry-and-context--contract.md), [Environment checkpoint](../instructions/workflow-concepts--entry-and-context--environment.md), [capability inventory](../instructions/workflow-concepts--entry-and-context--environment-capability-inventory.md), and [Mode checkpoint](../instructions/workflow-concepts--entry-and-context--mode.md) have passed. Inputs are their current results, including the released mode/count and any unresolved failure.

## Decision and result

Confirm all required gates are complete, select only the route authorized by Mode, and return the selected route identity and gate evidence to the caller for loading and validation.

## Failure boundary

If any prerequisite is missing, contradictory, or unreleased, return to the owning entry checkpoint and stop dependent route work. Do not reinterpret Mode, choose a fallback route, or initialize route-only state here.
