# unit.3e8ea17d9772d20d_zh_cn

[English](unit.3e8ea17d9772d20d.md) | [简体中文](unit.3e8ea17d9772d20d_zh_cn.md)

下列直接给出当前动作、守卫、证据和失败边界。应用独立政策前，先按明确的指令继续入口取得对应单元；同一构建中已持有的单元直接复用，并保留受影响动作的准确恢复位置。不读取作者文件或推测缺失政策。执行副作用前核实当前事实与授权；指令内容可用不表示检查通过。

## 硬约束

- 采取行动前记录用户、运行环境、仓库、权限、安全和 Session 硬约束。
- “不要创建子代理”“不要使用浏览器”等任务级禁止条件在整个任务中持续有效。
- 绝对禁止 Computer Use：不得通过图形界面控制计算机、浏览器或桌面应用——包括以操纵控件为目的的截图、鼠标／键盘模拟、点击、辅助功能 API、窗口自动化、远程桌面控制或 GUI 脚本——也不得把此类交互包装为 API、CLI、MCP Server、辅助程序或其他 Agent 调用来绕过。本节是黑名单而非允许渠道清单：当前 Session 实际暴露且已获授权的其他工具、命令或能力仍然允许。若必需步骤需要借助被禁止的操作，应停止并报告阻塞，而不是尝试、委派或跳过。
- 路线选择或任何委派/Session 拓扑工作前，模式检查点必须组合并验证委派 references；这些 references 在各自的原子边界内规定会话级模式选择及默认多代理路线和单个子代理预算、子代理数量、条件创建、分配、复用、替换、例外和限制。预留预算本身不会初始化或授权创建子代理。
- 不得虚构授权、能力、证据、产品支持，或为未维护场景推导可执行路线。
- Core 规则不依赖具体产品；受支持的运行环境分支和模型绑定见运行环境与模型厂商支持 (instruction continuation: [unit.081374cfbaa37b57](../instructions/unit.081374cfbaa37b57_zh_cn.md))。
- 按需读取 reference。不要仅因为可能以后有用，就预加载整个 Skill、`references/` 或原始项目状态。

# 角色预留


本检查点负责已授权 Multi-Agent 任务的职责预留决策。Child Role Selection (instruction continuation: [unit.19cd1c8e16500b17](../instructions/unit.19cd1c8e16500b17_zh_cn.md))、Count Gate (instruction continuation: [unit.36a14d319d1b638c](../instructions/unit.36a14d319d1b638c_zh_cn.md))、State Record (instruction continuation: [unit.04519b62e6c4f711](../instructions/unit.04519b62e6c4f711_zh_cn.md))和Child Role Allocation (instruction continuation: [unit.4706ccaa5a523c17](../instructions/unit.4706ccaa5a523c17_zh_cn.md))分别是角色选择、容量、身份/状态及预留政策的权威 owner。

## 触发与输入

仅当 Executor Selection 针对获授权拟议任务返回 `new-executor-needed`，且 Output Route Selection 已独立处置 Root 直接输出后运行。读取四个已链接的 L1 owner 及当前 Session 角色/allocation/容量事实。

## 决策与结果

1. 应用 Child Role Selection，将实际获授权拟议任务匹配到一种受维护角色。遵循用户明确的角色指令；仅当 owner 触发条件满足时使用其有条件的 Primary 回退。建议或 Primary 偏好不授权创建。
2. 从 State Record 和 Role Allocation owner 读取完整的当前 Session 角色台账。任一 Session 成员已预留或创建的角色均视为占用。不得将其他 Session 的继承子代理计入。
3. 若存在匹配的其他未占用角色，在锁定容量内将其唯一预留记录到当前 allocation。若仅容量不足，且该角色仍未占用，则经 Count Gate 请求明确批准恰好 `+1`。不得自动扩额。
4. 若四种角色都已占用，阻塞且不申请更多容量。向调用方返回预留、有证据/理由的 `Not applicable` 或阻塞，供其编排任务。Slice 放行和子代理创建仍是后续独立门禁。

## 失败边界

缺少获授权任务、Session 状态过期或不确定、角色冲突、角色不可用、容量不足且无精确批准，或角色适配未决时，阻塞 Slice 释放。本检查点不释放 Slice、不创建或派发。
