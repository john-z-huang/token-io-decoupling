# Worker Content Memo Lifecycle

[English](fundamental-concepts--context-exchange--content-memo-lifecycle.md) | [简体中文](fundamental-concepts--context-exchange--content-memo-lifecycle_zh_cn.md)

Apply the current instruction and its included policy sections below. The current actions, guards, evidence and failure boundary are given directly. Before applying a named independent policy, obtain its exact instruction continuation; reuse any already held unit from this build and retain the affected action's return position. Do not retrieve author files or infer omitted policy. Check current facts and authorization before effects; an instruction is not a pass.

## Hard constraints

- Record hard user, runtime environment, repository, permission, safety, and Session constraints before acting.
- A task-level prohibition, such as “do not create subagents” or “do not use a browser,” remains active for the whole task.
- Computer Use is categorically forbidden: never control a computer, browser, or desktop app through its graphical interface — no screenshots to locate controls, mouse or keyboard simulation, clicking, accessibility APIs, window automation, remote-desktop control, or GUI scripting — and do not route such interaction through an API, CLI, MCP server, helper, or another Agent. Treat this as a blacklist rather than a list of allowed channels: every other tool, command, or capability actually exposed to and authorized for the current Session remains permitted. If a required step needs a forbidden operation, stop and report the blocker instead of attempting, delegating, or skipping it.
- Before route selection or any delegation/Session-topology work, the Mode checkpoint must compose and validate the delegation references; those references own conversation-level mode selection with a default Multi-Agent route and one-child budget, child counts, conditional creation, allocation, reuse, replacement, exceptions, and limits at their respective atomic boundaries. A reserved budget never initializes or authorizes a child by itself.
- Never invent authorization, capability, evidence, product support, or an executable route for an unmaintained scenario.
- Keep Core rules independent of product details; read [Runtime and Model Provider Support](../instructions/fundamental-concepts--session-runtime--runtime-provider-support.md) for supported runtime branches and model bindings.
- Read references on demand. Do not preload the entire Skill, `references/`, or raw project state merely because it may become useful.

# Worker Content Memo Lifecycle

## General rules

### Creation, update, and discovery

When `write_content_memo` is true, use `list_memories` to check the named entry and `write_memory` to create or update `context-exchange/workers/<worker-context-id>/content-memo` when reusable state first appears and at material milestones, blockers, handoff, replacement, or normal exit. Update only when state/evidence materially changes, not after every command. A parent or successor may read it only when the released instructions name or authorize it; Serena itself does not enforce that ownership rule. Do not create a local file index for these records; the name is discoverable through Serena's memory listing.

Memory capability failure must be reported and blocks dependent record use; never fall back to writing the record as a file. Preserve the content contract and do not turn it into a command journal.

## Codex CLI / ChatGPT Desktop optimizations

Hooks may signal a compaction or exit boundary but do not write or validate the named Memory. Use exposed, authorized Serena tools and confirm the write result; do not write another Worker's memory name unless the parent explicitly authorizes that record.

## Claude Code CLI / Claude Desktop optimizations

Only when Serena MCP Memory tools are exposed and authorized, use the named memory and verify the write result. Hooks or auto memory do not replace it. If unavailable, report the limitation and block dependent work.
