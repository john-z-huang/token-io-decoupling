# Coding 子 Agent 生命周期

[English](fundamental-concepts--delegation--delegation-child-lifecycle.md) | [简体中文](fundamental-concepts--delegation--delegation-child-lifecycle_zh_cn.md)

下列直接给出当前动作、守卫、证据和失败边界。应用独立政策前，先按明确的指令继续入口取得对应单元；同一构建中已持有的单元直接复用，并保留受影响动作的准确恢复位置。不读取作者文件或推测缺失政策。执行副作用前核实当前事实与授权；指令内容可用不表示检查通过。

## 硬约束

- 采取行动前记录用户、运行环境、仓库、权限、安全和 Session 硬约束。
- “不要创建子代理”“不要使用浏览器”等任务级禁止条件在整个任务中持续有效。
- 绝对禁止 Computer Use：不得通过图形界面控制计算机、浏览器或桌面应用——包括以操纵控件为目的的截图、鼠标／键盘模拟、点击、辅助功能 API、窗口自动化、远程桌面控制或 GUI 脚本——也不得把此类交互包装为 API、CLI、MCP Server、辅助程序或其他 Agent 调用来绕过。本节是黑名单而非允许渠道清单：当前 Session 实际暴露且已获授权的其他工具、命令或能力仍然允许。若必需步骤需要借助被禁止的操作，应停止并报告阻塞，而不是尝试、委派或跳过。
- 路线选择或任何委派/Session 拓扑工作前，模式检查点必须组合并验证委派 references；这些 references 在各自的原子边界内规定会话级模式选择及默认多代理路线和单个子代理预算、子代理数量、条件创建、分配、复用、替换、例外和限制。预留预算本身不会初始化或授权创建子代理。
- 不得虚构授权、能力、证据、产品支持，或为未维护场景推导可执行路线。
- Core 规则不依赖具体产品；受支持的运行环境分支和模型绑定见[运行环境与模型厂商支持](../instructions/fundamental-concepts--session-runtime--runtime-provider-support_zh_cn.md)。
- 按需读取 reference。不要仅因为可能以后有用，就预加载整个 Skill、`references/` 或原始项目状态。

# Coding 子 Agent 生命周期

## 通用规范

### 生命周期状态

在父级记录中持久保存每个已创建子 Agent 的身份和生命周期。不得仅为清理而关闭、shutdown、归档、删除或移除子 Agent。运行时状态信息是短暂的情形下，即使状态不再可用，仍须在父级记录保留子 Agent ID 和状态。pending 或 running 时，在可用情况下采用有界的事件驱动等待；只有状态变化时才更新记录，避免无变化时重复轮询或重写状态。只有返回最终结果和证据后才能进入 completed。应用配置的摘要频率，必需的里程碑反馈仍须输出。

### 错误与中断

发生错误或中断时，保留原子代理的身份、明确的生命周期状态与现有证据；未经授权不得以清理为由关闭它。同一子代理是否能够进行获准 follow-up，以及无法继续时如何处理，均由复用/替换 owner 决定；生命周期 owner 只记录结果状态和阻塞原因。不得从生命周期变化推断创建 successor 或回收 allocation 名额的权限。

## Codex CLI / ChatGPT Desktop 特别优化指令

Codex 也可通过已配置的 `SubagentStart`／`SubagentStop` Hooks 观察子代理 ID 与生命周期；在 `SubagentStart` 中返回 `continue: false` **不会**阻止创建。即使状态结果或 Hook 报告不再可用，仍要把实际子代理 ID 与完成证据保留在父级记录中。这些事件只用于观察，不授权替换，也不能证明验证通过。[OpenAI：生命周期 Hooks](https://learn.chatgpt.com/docs/hooks)。

### Codex 线程观察

当前 Agent Session 暴露 `/agent` 或直接的子代理状态／结果工具时，才通过该工具获取执行中工作和返回摘要，避免把完整 transcript 输入父级上下文。只有当前 Session 直接提供审批请求或控制时才能处理审批；先核验请求来源和操作，再确认授权。宿主无法提供新的有效审批路径时，操作失败，父级必须记录 Slice 阻塞。`SubagentStop` Hook 只提供观察；状态标签不能取代最终证据，也不授权清理／替换。[OpenAI：子代理线程与审批](https://learn.chatgpt.com/docs/agent-configuration/subagents)、[OpenAI：Hooks](https://learn.chatgpt.com/docs/hooks)。

## Claude Code CLI / Claude Desktop 特别优化指令

可用时通过 `Agent` 结果和 `/tasks` 命令输出观察运行中的子代理；以有界运行时等待取得结果。`/tasks` 输出是短暂信息，不再包含子代理时仍须在父级记录保留返回的 Agent ID 和完成或错误状态。

### 事件辅助观察

实际暴露 Hooks 的 Claude Code Session 中，可选 `SubagentStart` Hook 用于记录事件提供的 `agent_id`/`agent_type`；可选 `SubagentStop` Hook 可读取 `agent_id`、`agent_transcript_path` 和 `last_assistant_message`，无需把完整 transcript 塞入父级上下文。必须与实际 `Agent` 结果和父级状态记录交叉核对；单个 Hook 事件既不证明成功完成，也不授予关闭、替换或创建子代理的权限。失败和部分输出应单独记录。`/tasks` 输出只是便捷信号而非持久事实源，不再包含子代理时仍要保留 ID 和证据。只有当前 Session 暴露 Hooks 时才能使用。

官方依据：[SubagentStart/SubagentStop 事件字段](https://code.claude.com/docs/en/hooks)、[子代理生命周期与恢复](https://code.claude.com/docs/en/sub-agents)。

达到 `maxTurns`、`Agent` 调用失败或返回未完成／后台部分结果时，父级核实实际输出与返回条件前均按部分完成或中断处理；`/tasks` 输出不再列出子代理不构成完成证据。[Anthropic：子代理执行限制](https://code.claude.com/docs/en/sub-agents)。
