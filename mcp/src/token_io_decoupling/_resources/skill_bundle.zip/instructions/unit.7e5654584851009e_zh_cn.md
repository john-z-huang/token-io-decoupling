# unit.7e5654584851009e_zh_cn

[English](unit.7e5654584851009e.md) | [简体中文](unit.7e5654584851009e_zh_cn.md)

下列直接给出当前动作、守卫、证据和失败边界。应用独立政策前，先按明确的指令继续入口取得对应单元；同一构建中已持有的单元直接复用，并保留受影响动作的准确恢复位置。不读取作者文件或推测缺失政策。执行副作用前核实当前事实与授权；指令内容可用不表示检查通过。

## 硬约束

- 采取行动前记录用户、运行环境、仓库、权限、安全和 Session 硬约束。
- “不要创建子代理”“不要使用浏览器”等任务级禁止条件在整个任务中持续有效。
- 绝对禁止 Computer Use：不得通过图形界面控制计算机、浏览器或桌面应用——包括以操纵控件为目的的截图、鼠标／键盘模拟、点击、辅助功能 API、窗口自动化、远程桌面控制或 GUI 脚本——也不得把此类交互包装为 API、CLI、MCP Server、辅助程序或其他 Agent 调用来绕过。本节是黑名单而非允许渠道清单：当前 Session 实际暴露且已获授权的其他工具、命令或能力仍然允许。若必需步骤需要借助被禁止的操作，应停止并报告阻塞，而不是尝试、委派或跳过。
- 路线选择或任何委派/Session 拓扑工作前，模式检查点必须组合并验证委派 references；这些 references 在各自的原子边界内规定会话级模式选择及默认多代理路线和单个子代理预算、子代理数量、条件创建、分配、复用、替换、例外和限制。预留预算本身不会初始化或授权创建子代理。
- 不得虚构授权、能力、证据、产品支持，或为未维护场景推导可执行路线。
- Core 规则不依赖具体产品；受支持的运行环境分支和模型绑定见运行环境与模型厂商支持 (instruction continuation: [unit.081374cfbaa37b57](../instructions/unit.081374cfbaa37b57_zh_cn.md))。
- 按需读取 reference。不要仅因为可能以后有用，就预加载整个 Skill、`references/` 或原始项目状态。

# Coding 子 Agent 复用与替换

## 通用规范

### 获准复用

模型和 reasoning-effort 设置仅在创建子代理时核验。对同一子代理的 follow-up、修复、compaction、中断、唤醒或恢复不得重复核验，也不得要求子代理检查/报告这些设置。本模块中的子代理身份、生命周期、授权、范围和返回路径规则仍须执行。

对已授权 follow-up、修复 epoch 和中断，在安全时复用同一个已创建子代理。优先通过该子代理尝试获准修复；无法安全继续时报告阻塞，并将依赖的 Multi-Agent 工作置为 `blocked`。复用不得创建递归层级或 peer 协调。已创建子代理的身份和证据遵循生命周期 owner 保留。

### 替换关系

创建该名额的子代理前，父级授权的计划修订可在当前批准数量内调整 `agent: unbound` allocation 的职责或待放行 Slice。数量尚未锁定时，awaiting-count 记录不存在可修订的 allocation。在现有数量内，可通过正常放行和创建门禁，使用未分配名额及尚未占用的职责创建额外子代理。子代理一旦创建，其身份、名额和职责在本 Session 中永久绑定，不得回收或替换。超过当前数量的任何子代理，都必须取得委派数量门禁 (instruction continuation: [unit.36a14d319d1b638c](../instructions/unit.36a14d319d1b638c_zh_cn.md))要求的实际用户批准，精确增加一个名额并使用不同且未占用的职责；该批准绝不允许替换或重复职责。不得重新打开数量问题、fork 或 handoff 到新子代理以绕过这些门禁。上下文交接由上下文交换交接 (instruction continuation: [unit.2d0f4872b823ef44](../instructions/unit.2d0f4872b823ef44_zh_cn.md))负责，不授予创建 Agent 的能力。

## Codex CLI / ChatGPT Desktop 特别优化指令

### 复用已分配的 Codex 线程

宿主提供父级可控的 steering 或能够向已记录 Codex 子线程 follow-up 时，必须对**同一身份**发起获准的修复或后续 epoch。当前 Session 暴露的 `/agent` 或直接子线程工具可定位已记录身份。通过暴露工具返回的不同 Session 或 worktree 不足以证明与已分配 Child 身份连续。请求新的 subagent 会产生不同身份，在数量锁定后不得伪装为复用。原线程无法通过暴露工具继续或 steering 失败时，保留证据并阻塞依赖 Multi-Agent Slice。[OpenAI：子代理编排与线程控制](https://learn.chatgpt.com/docs/agent-configuration/subagents)、[OpenAI：worktree 行为](https://learn.chatgpt.com/docs/environments/git-worktrees)。

## Claude Code CLI / Claude Desktop 特别优化指令

获准跟进或修复同一子代理时，使用返回的 Agent ID 调用 `SendMessage`。再次调用 `Agent` 会创建另一个子代理并消耗另一个名额；数量锁定后不得将其用于复用。

### 恢复同一身份，不重新创建

获准的持久 `general-purpose` 或自定义子代理，应通过 `SendMessage` 指定返回的 `agent_id`（或运行时支持的 Agent 名称），发送范围明确的修复/follow-up 指令。新的 `Agent` 调用即使类型与提示词相同，也会产生不同实例；数量锁定后不得暗中用它替换原子代理。内置 `Explore` 和 `Plan` 是一次性 Agent，不返回可恢复 ID，不得用于需要后续 follow-up 的名额。恢复失败时保留错误并阻塞依赖工作，不再尝试创建另一子代理。除非 Claude Desktop 连接器工具结果明确返回父级控制的该身份关系，否则连接器调用不能代替向已记录 Agent 身份发送 `SendMessage`。

官方依据：[恢复子代理](https://code.claude.com/docs/en/sub-agents)。

Agent team 消息或 `/branch` 都不能替代恢复已记录的 Agent 身份。原子代理 ID 不可继续时，保留其证据并阻塞依赖 Slice，不得消耗未经批准的替代名额。[Anthropic：子代理恢复](https://code.claude.com/docs/en/sub-agents)。
