# Coding 工作流 — Multi-Agent 模式

[English](workflows--coding-multi-agent.md) | [简体中文](workflows--coding-multi-agent_zh_cn.md)

下列直接给出当前动作、守卫、证据和失败边界。应用独立政策前，先按明确的指令继续入口取得对应单元；同一构建中已持有的单元直接复用，并保留受影响动作的准确恢复位置。不读取作者文件或推测缺失政策。执行副作用前核实当前事实与授权；指令内容可用不表示检查通过。

## 硬约束

- 采取行动前记录用户、运行环境、仓库、权限、安全和 Session 硬约束。
- “不要创建子代理”“不要使用浏览器”等任务级禁止条件在整个任务中持续有效。
- 绝对禁止 Computer Use：不得通过图形界面控制计算机、浏览器或桌面应用——包括以操纵控件为目的的截图、鼠标／键盘模拟、点击、辅助功能 API、窗口自动化、远程桌面控制或 GUI 脚本——也不得把此类交互包装为 API、CLI、MCP Server、辅助程序或其他 Agent 调用来绕过。本节是黑名单而非允许渠道清单：当前 Session 实际暴露且已获授权的其他工具、命令或能力仍然允许。若必需步骤需要借助被禁止的操作，应停止并报告阻塞，而不是尝试、委派或跳过。
- 路线选择或任何委派/Session 拓扑工作前，模式检查点必须组合并验证委派 references；这些 references 在各自的原子边界内规定会话级模式选择及默认多代理路线和单个子代理预算、子代理数量、条件创建、分配、复用、替换、例外和限制。预留预算本身不会初始化或授权创建子代理。
- 不得虚构授权、能力、证据、产品支持，或为未维护场景推导可执行路线。
- Core 规则不依赖具体产品；受支持的运行环境分支和模型绑定见[运行环境与模型厂商支持](../instructions/fundamental-concepts--session-runtime--runtime-provider-support_zh_cn.md)。
- 按需读取 reference。不要仅因为可能以后有用，就预加载整个 Skill、`references/` 或原始项目状态。

## 外层路线调度上下文

选择器声明入口前置条件：首次进入路线前补齐缺项，进入后核验已持有的当前通过证据，不重放门禁或提示。下列已选路线负责跨模块返回；生产者读回及 epoch/副作用检查后，仅恢复已记录调用方子步骤。当前模块正文不替代该调度。

# Coding 工作流 — Multi-Agent 模式


本路线为已释放 Multi-Agent Coding 且锁定正数 child count 的任务组合七个 Layer-04 模块。它安排模块入口，在前置缺失时保留调用方位置，并将状态变化返回受影响的模块。

## 工作流路线图


## 路线顺序检查清单

进入 MM01 前，检查 Coding 工作流已完成 Contract、Environment、能力清单、Mode 和 Route Entry 的证据。不得重复这些门禁。本路线要求正数锁定 child count；预留数量本身不授权创建子代理。每一步只调用所链接的模块；前置导致暂停时，保留准确模块检查点和已完成效果，并从返回位置恢复。不得重放先前效果，也不得因缺少前置而重启整条路线。

1. **MM01 — 入口就绪。** 使用当前 Contract、Environment、能力清单、已释放 Multi-Agent Mode、正数锁定数量及授权路线证据，调用[入口就绪模块](../instructions/workflows--modules--entry-readiness_zh_cn.md)。仅在入口证据当前且一致时继续。缺失前置交语义 owner 并保留 MM01；冲突或状态不安全时阻塞。
2. **MM02 — Session 就绪。** 调用[Session 就绪模块](../instructions/workflows--modules--session-readiness_zh_cn.md)，确认规范 authority/state、审计及适用的容量读回。恢复改变事实时，遵循模块要求的规范读回先于审计顺序；不得重开 Mode 或重复已完成提问。仅在 Session、审计和 allocation 证据当前时继续；`needs_prerequisite` 时保留暂停位置，authority 或读回失败未解决时阻塞。
3. **MM03 — 工作定义。** 调用[工作定义模块](../instructions/workflows--modules--work-definition_zh_cn.md)，解决来源明确的 Context、Decision、规划输出、适用 advice 和未释放边界。仅在来源事实以及符合 Contract 的 Decision/plan 当前有效时继续。缺失事实/决定交语义 owner 后恢复 MM03。该模块不授权实际委派任务、不预留角色、不释放 Slice、不创建或派发子代理。 执行前要求该模块返回默认共享计划身份、当前计划证据与持久化确认，或有记录的持久化限制例外；完成 owner 要求的任何内容核验。必需计划证据缺失时阻塞；无需额外规划请求。 验证所选仓库存储范围及对应活动/归档命名空间；共享存储时，同仓库各工作区指向同一规划，其他仓库保持隔离。映射未知或冲突时返回规划 owner，不得静默回退另一存储范围。
   - 在 WD02，[工作流路由建议](../instructions/fundamental-concepts--execution-planning--workflow-routing-advice_zh_cn.md)与 Decision 建议分开。仅在 WD01 事实当前有效、锁定的 mode/count 和所选路线已直接确认后考虑；根据该路线及其哈希审阅建议。只有分支确实未选择或不符合条件时，才记录有原因的 `not_applicable`。所选证据过期/不足或缺少必需能力时，返回解决前置条件或阻塞该依赖路径；建议不能改变路线、通过门禁、选择执行者/输出或释放工作。
4. **MM04 — 委派执行。** 带上 MM01–MM03 证据及 continuation/effect 状态，调用[委派执行模块](../instructions/workflows--modules--delegated-execution_zh_cn.md)。DE01–DE04 负责 Bootstrap 评估、实际任务授权、执行者/输出决策、条件角色预留以及创建/派发前共用的恢复/Slice 门禁。后续检查点负责条件子代理创建/派发、显式 Worker memo 处置、实施/结果及 Control。仅在当前实施/结果和初步证据齐备时继续。恢复既有 bundle 时保留已记录效果和 memo 值；新 bundle 在 DE04 明确 memo 值。保留等待子代理、Control 和下一 Slice 的位置；不得重放创建或派发。 携带共享计划身份和当前证据；模块确认所需职责的计划访问权限，按 owner 规定的边界记录更新，并在依赖工作/汇报前完成 owner 要求的内容核验；包括需求修订在内，影响依赖工作的变化须在该工作前记录。
   - 在 DE07，仅当当前执行者、Slice、输出 class、capability、单独授权、固定 root、准确路径和 baseline 均满足 owner 要求时，才使用[输出物料化](../instructions/fundamental-concepts--execution-planning--output-materialization_zh_cn.md)和[候选合规预检](../instructions/fundamental-concepts--execution-planning--candidate-compliance_zh_cn.md)。执行期间准备并检查同一有界候选，在同一 root/政策下进行新鲜 whole-batch 预检，重新核验授权/artifact/baseline，应用准确候选，并结合实际当前文件审阅收据和返回结果；准备候选前不必等待完整子代理结果。仅在确实未选择可选路径时记录有原因的 `not_applicable`，且仅在独立授权的直接路径下继续；所选路径缺少候选/基线/必需能力或检查失败、未知、过期、不确定时，返回解决前置条件或阻塞，不得静默回退。这些结果在 MM05 当前 Verification 前均为初步证据。
5. **MM05 — 验证与修复。** 针对准确当前指纹和验收条件调用[验证与修复模块](../instructions/workflows--modules--verification-repair_zh_cn.md)。只有 Contract 要求独立验证且当前独立性证据确认可用时，才完成独立验证；Worker 结果仅是实施证据。必需验证者证据待补时暂停依赖效果；若无法取得获授权的独立验证者，则阻塞这些效果。同 Session 逻辑检查不可替代。仅当必需检查在当前 epoch 通过且没有待修复项时继续。修复经交接返回当前 Verification；Contract/Decision 语义变化交调用方。实施、文档或 Git metadata 维度改变后不得使用过期证据。
   - 在 VR01，将任何输出收据与实际当前文件对账，并重新捕获当前状态和受影响 epoch；先根据当前证据解决部分或不确定效果。预检、收据或初步检查不能替代最终 Verification。
6. **MM06 — 文档。** 带上当前 Verification、Contract 和写前指纹，调用[文档模块](../instructions/workflows--modules--documentation_zh_cn.md)。该模块判断适用输出，输出适用时要求授权/来源/路径，处理请求 Memory 的 owner 要求内容核验、影响分类和检查。仅在当前文档结果齐备时继续。内容/Contract/验收变化需要重验时返回 MM05；受影响 epoch 通过后，恢复挂起的 MM06 子步骤，完成当前影响分类和文档检查后再进入 MM07。
   - 在 DOC02，可选[候选合规预检](../instructions/fundamental-concepts--execution-planning--candidate-compliance_zh_cn.md)仅适用于确实已选择且适用的写前分支：先准备有界候选并捕获可信基线，再运行检查；然后在应用前解决已选检查的失败、未知、遗漏或过期结果。已选分支缺少候选或基线时返回 `needs_prerequisite`，不得标为 `not_applicable`。只有分支确实未选择或不适用时才记录有原因的 `not_applicable`。DOC05 的写后检查仍必需，预检不能替代它。
7. **MM07 — 交付与验收。** 带上当前 Contract 标准、验证证据、epoch 和任何准确且获授权的 Git 意图，调用[交付与验收模块](../instructions/workflows--modules--delivery-acceptance_zh_cn.md)。仅当每项适用标准都有当前通过证据且请求交付已解决时继续。要求该模块在完成/归档前进行计划全文内容保留比对，并确认归档与已核验的最终活动内容完全相同；执行计划 owner 要求的内容读回。最终摘要不能替换累积历史。只有验收证据通过且内容保留已确认后，该模块才可归档匹配的已完成 active plan。缺少标准/证据时返回语义 owner 和记录位置；内容保留不一致、失败、冲突或效果未授权时阻塞。

## 前置返回映射

仅在其 producer/recheck 位置补齐缺失项。保留原挂起模块/子步骤、已完成效果和相关 epoch；若 producer 也暂停，则在现有调用方上下文保留嵌套 continuation。读回结果并重核 epoch/effect 后，只恢复原调用方位置。Contract/Environment/Mode 证据缺口仅需补齐缺失证据；只有路线事实实质变化时才重核 Route Entry，然后在保留锁定 Mode/count 的情况下返回原挂起位置。不得重放前序效果或重开已释放 Mode/count。owner/位置/效果未知、无进展或效果不可恢复时阻塞依赖工作。

| 缺失前置 | producer/recheck 位置 | 读回后恢复位置 |
| --- | --- | --- |
| Contract/验收标准 | Coding 工作流 Contract owner；仅补齐缺失证据。 | 原挂起 MM 模块/子步骤；只有路线事实实质变化时才重核 Route Entry。 |
| Environment/能力清单 | 对应 Environment/能力 owner；仅补齐缺失证据。 | 原挂起 MM 模块/子步骤；只有路线事实实质变化时才重核 Route Entry。 |
| Route Entry 证据或已变化的路线事实 | 仅对实质变化事实调用 Route Entry owner；保留已释放 Mode/count。 | 路线仍有效时恢复原挂起 MM 模块/子步骤；否则阻塞。 |
| 已释放 Multi-Agent Mode/count 证据 | 使用既有 Mode owner 和锁定记录读回；不得重复已释放选择。 | 仅在当前 Multi-Agent mode 和正数数量得到确认后恢复原挂起位置；冲突时阻塞。 |
| Session state、authority、审计或容量 | MM02 Session owners；复用审计/容量前先完成 canonical state 读回。 | 读回后恢复原挂起 MM 模块/子步骤；若调用方本身是 MM02，则恢复其记录的 producer 子步骤。 |
| Context、Decision、plan 或 advice | MM03 WD owners；只解决缺失子步骤。 | 原挂起 MM 模块/子步骤；例如 MM07 在 WD 证据读回后仍恢复 MM07。 |
| Bootstrap、任务授权、执行者/输出、角色、Slice 或 Control | MM04 DE01–DE08 owners；不得重放已完成的分配/派发效果。 | 结果读回并核对 effect/epoch 后恢复原挂起位置。 |
| Verification、修复诊断或 handoff | MM05 VR owners；保留当前维度和修复效果。 | 当前证据完成后恢复原挂起位置；MM06 在验证返回后恢复其挂起 DOC 子步骤。 |
| 文档影响、owner 要求的 Memory 内容核验或检查 | MM06 DOC owners；VR 返回后完成挂起的 DOC 子步骤。 | 读回、影响分类及检查完成后恢复原挂起位置。 |
| Git target/effect、Acceptance 标准或计划归档 | MM07 DA owners；仅在全部标准通过并完成所需读回后归档。 | producer 证据读回后恢复原挂起 MM 模块/子步骤。 |
## Mode 边界

只使用已释放的 Multi-Agent mode 和正数锁定数量。角色分配、创建、派发、复用、memo 和子代理生命周期由所调用模块组合的底层 owners 管理；本路线只负责模块顺序。
