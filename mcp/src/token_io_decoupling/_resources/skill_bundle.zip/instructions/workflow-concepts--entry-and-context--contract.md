# Contract Checkpoint

[English](workflow-concepts--entry-and-context--contract.md) | [简体中文](workflow-concepts--entry-and-context--contract_zh_cn.md)

Apply the current instruction and its included policy sections below. The current actions, guards, evidence and failure boundary are given directly. Before applying a named independent policy, obtain its exact instruction continuation; reuse any already held unit from this build and retain the affected action's return position. Do not retrieve author files or infer omitted policy. Check current facts and authorization before effects; an instruction is not a pass.

## Hard constraints

- Record hard user, runtime environment, repository, permission, safety, and Session constraints before acting.
- A task-level prohibition, such as “do not create subagents” or “do not use a browser,” remains active for the whole task.
- Computer Use is categorically forbidden: never control a computer, browser, or desktop app through its graphical interface — no screenshots to locate controls, mouse or keyboard simulation, clicking, accessibility APIs, window automation, remote-desktop control, or GUI scripting — and do not route such interaction through an API, CLI, MCP server, helper, or another Agent. Treat this as a blacklist rather than a list of allowed channels: every other tool, command, or capability actually exposed to and authorized for the current Session remains permitted. If a required step needs a forbidden operation, stop and report the blocker instead of attempting, delegating, or skipping it.
- Before route selection or any delegation/Session-topology work, the Mode checkpoint must compose and validate the delegation references; those references own conversation-level mode selection with a default Multi-Agent route and one-child budget, child counts, conditional creation, allocation, reuse, replacement, exceptions, and limits at their respective atomic boundaries. A reserved budget never initializes or authorizes a child by itself.
- Never invent authorization, capability, evidence, product support, or an executable route for an unmaintained scenario.
- Keep Core rules independent of product details; read [Runtime and Model Provider Support](../instructions/fundamental-concepts--session-runtime--runtime-provider-support.md) for supported runtime branches and model bindings.
- Read references on demand. Do not preload the entire Skill, `references/`, or raw project state merely because it may become useful.

# Contract Checkpoint


## Actions

1. State the requested outcome in one sentence.
2. Record hard limits: user prohibitions, allowed runtime environments, repository and worktree scope, permitted tools and paths, safety limits, and explicitly authorized external effects.
3. Record material decisions already made, unresolved questions, and acceptance conditions.
4. Separate facts observed from assumptions. Keep unresolved material questions out of the implementation release.

5. Establish task intent and eligible output classification from direct authoritative sources. Keep any advisory output separate from the Contract; it cannot authorize scope. Apply [Decisions Advisory](../instructions/fundamental-concepts--execution-planning--decisions-advisory.md) for advisory policy.

## Pass condition

The goal, constraints, decisions, and acceptance conditions are explicit. If required information is missing, stop the dependent slice and ask for or report the exact missing input.

## Boundary

This checkpoint does not choose an execution mode, inspect the whole repository, implement changes, verify results, write documentation, or perform Git operations.
