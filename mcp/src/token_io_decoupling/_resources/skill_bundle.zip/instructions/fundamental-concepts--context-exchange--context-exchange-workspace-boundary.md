# Coding Context Exchange Workspace Boundary

[English](fundamental-concepts--context-exchange--context-exchange-workspace-boundary.md) | [简体中文](fundamental-concepts--context-exchange--context-exchange-workspace-boundary_zh_cn.md)

Apply the current instruction and its included policy sections below. The current actions, guards, evidence and failure boundary are given directly. Before applying a named independent policy, obtain its exact instruction continuation; reuse any already held unit from this build and retain the affected action's return position. Do not retrieve author files or infer omitted policy. Check current facts and authorization before effects; an instruction is not a pass.

## Hard constraints

- Record hard user, runtime environment, repository, permission, safety, and Session constraints before acting.
- A task-level prohibition, such as “do not create subagents” or “do not use a browser,” remains active for the whole task.
- Computer Use is categorically forbidden: never control a computer, browser, or desktop app through its graphical interface — no screenshots to locate controls, mouse or keyboard simulation, clicking, accessibility APIs, window automation, remote-desktop control, or GUI scripting — and do not route such interaction through an API, CLI, MCP server, helper, or another Agent. Treat this as a blacklist rather than a list of allowed channels: every other tool, command, or capability actually exposed to and authorized for the current Session remains permitted. If a required step needs a forbidden operation, stop and report the blocker instead of attempting, delegating, or skipping it.
- Before route selection or any delegation/Session-topology work, the Mode checkpoint must compose and validate the delegation references; those references own conversation-level mode selection with a default Multi-Agent route and one-child budget, child counts, conditional creation, allocation, reuse, replacement, exceptions, and limits at their respective atomic boundaries. A reserved budget never initializes or authorizes a child by itself.
- Never invent authorization, capability, evidence, product support, or an executable route for an unmaintained scenario.
- Keep Core rules independent of product details; read [Runtime and Model Provider Support](../instructions/fundamental-concepts--session-runtime--runtime-provider-support.md) for supported runtime branches and model bindings.
- Read references on demand. Do not preload the entire Skill, `references/`, or raw project state merely because it may become useful.

# Coding Context Exchange Workspace Boundary

## General rules

### Memory names and logical ownership

Use Serena project Memory names for context records. Under the default project data directory, names map beneath `.serena/memories/`, slash segments create subdirectories, and Serena adds `.md`; follow configured overrides. Preserve the former record layout in names: `context-exchange/INDEX`; `context-exchange/workers/<worker-context-id>/INDEX`; `context-exchange/workers/<worker-context-id>/content-memo`; and `context-exchange/context-bootstrap/MANIFEST`, `.../project-context`, and `.../policy-context`. Map other handoff/import records using their existing basenames and subdirectory intent.

A memory name expresses logical ownership only. Serena does not provide Worker-level visibility isolation, read-only ACLs, or OS/RW/RO/DENY enforcement for Memory records. The tool may expose listed memories to any authorized Session. Agents must follow the released task's instructions about which names they may read or write, but neither the namespace nor Serena's project-wide patterns technically enforce that rule. Do not claim these records are protected by directories, `.gitignore`, worktrees, or filesystem permissions.

Keep source-code and authoritative repository-file access within their separately approved filesystem/tool boundaries. A Memory capsule may contain concise facts, exact authoritative source pointers, hashes, freshness, and scope; do not store full source documents as authoritative copies. Parent live mode/count/allocation/epoch state remains in its existing owner, not these memories. Secrets, full transcripts, and private reasoning remain prohibited.

If Serena Memory tools are unavailable, report the limitation and block work that depends on reading or writing the context record. Do not fall back to a file-backed copy. Independent work may continue.

## Codex CLI / ChatGPT Desktop optimizations

Use only Serena Memory tools exposed and authorized to the active Session. List and read named records before relying on them; write only the names authorized in the released task and confirm the result. Codex filesystem sandbox or worktree settings still govern source files, but do not create or imply per-Worker Memory isolation.

## Claude Code CLI / Claude Desktop optimizations

Use Serena Memory only when the active Agent Session exposes and authorizes the relevant MCP tools. Claude Code MCP Tool Search may defer tool definitions, so discover and verify the actual tools first. Claude auto memory, worktree isolation, and filesystem rules do not provide Serena Memory isolation. If unavailable, follow the general report/block rule.
