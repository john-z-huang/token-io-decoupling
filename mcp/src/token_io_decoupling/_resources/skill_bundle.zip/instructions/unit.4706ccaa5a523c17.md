# unit.4706ccaa5a523c17

[English](unit.4706ccaa5a523c17.md) | [简体中文](unit.4706ccaa5a523c17_zh_cn.md)

Apply the current instruction and its included policy sections below. The current actions, guards, evidence and failure boundary are given directly. Before applying a named independent policy, obtain its exact instruction continuation; reuse any already held unit from this build and retain the affected action's return position. Do not retrieve author files or infer omitted policy. Check current facts and authorization before effects; an instruction is not a pass.

## Hard constraints

- Record hard user, runtime environment, repository, permission, safety, and Session constraints before acting.
- A task-level prohibition, such as “do not create subagents” or “do not use a browser,” remains active for the whole task.
- Computer Use is categorically forbidden: never control a computer, browser, or desktop app through its graphical interface — no screenshots to locate controls, mouse or keyboard simulation, clicking, accessibility APIs, window automation, remote-desktop control, or GUI scripting — and do not route such interaction through an API, CLI, MCP server, helper, or another Agent. Treat this as a blacklist rather than a list of allowed channels: every other tool, command, or capability actually exposed to and authorized for the current Session remains permitted. If a required step needs a forbidden operation, stop and report the blocker instead of attempting, delegating, or skipping it.
- Before route selection or any delegation/Session-topology work, the Mode checkpoint must compose and validate the delegation references; those references own conversation-level mode selection with a default Multi-Agent route and one-child budget, child counts, conditional creation, allocation, reuse, replacement, exceptions, and limits at their respective atomic boundaries. A reserved budget never initializes or authorizes a child by itself.
- Never invent authorization, capability, evidence, product support, or an executable route for an unmaintained scenario.
- Keep Core rules independent of product details; read Runtime and Model Provider Support (instruction continuation: [unit.081374cfbaa37b57](../instructions/unit.081374cfbaa37b57.md)) for supported runtime branches and model bindings.
- Read references on demand. Do not preload the entire Skill, `references/`, or raw project state merely because it may become useful.

# Coding Child Role Allocation

## General rules

### Allocation

Reserve the locked count as unbound, unassigned slots before task context and Decision are complete. That reservation stage does not select or assign Primary Output merely because only one slot exists; the slots remain `role: unassigned`, `slice_status: pending`, and `agent: unbound`. After Root has reviewed current task context and Decision, use Child Role Selection (instruction continuation: [unit.19cd1c8e16500b17](../instructions/unit.19cd1c8e16500b17.md)) to identify one role for the proposed child; an explicit user instruction skips role-selection advice but not Root's role and policy checks. If context generation or advice is unavailable, Root may decide directly from the current owner and verified facts. Then reserve the selected role in one unassigned slot and release its role and concrete slice before child creation. Ordinary non-Skill documentation remains parent-authored and does not consume a reserved slot, including when code work is also present. Each independent role consumes a separate slot. A role on an unbound, not-yet-created slot may be revised only as a parent-authorized plan update within the current count, and the new role must not be assigned to any other reserved or created child. Once a child is created, its role and identity remain bound and cannot be recycled or replaced. If no independent verifier or auxiliary role was allocated, use the current or already allocated Agent when safe, or report it unavailable; never simulate independence by relabeling same-Session work.

### Context Bootstrap/Refresh allocation

Assign Context Bootstrap/Refresh only when reuse is likely to outweigh setup: at least two independent downstream Workers, broad discovery plus three or more routed policy modules, or a source set roughly above 20k characters / 5k token-equivalents. Skip it for one small Worker or documentation-only fast paths. These are routing heuristics, not measured runtime or quality claims.

## Codex CLI / ChatGPT Desktop optimizations

Codex `.codex/agents/*.toml` profiles can name a planned role, but registering one never creates an Agent or changes a reserved slot's child identity. Select the role and its effective `model`/`model_reasoning_effort`/`sandbox_mode` within the locked budget; a configurable global concurrent-agent limit is separate from this Skill's total child-count gate. [OpenAI: custom subagents](https://learn.chatgpt.com/docs/agent-configuration/subagents).

When matching a released slot to a Codex role, distinguish the built-in `explorer` (read-heavy), `worker` (execution), and `default` (fallback) from a reviewed project/user custom profile. A profile choice sets an intended tool/model policy but does not bind an Agent ID, create a Session, or authorize a new slot. Resolve the effective parent-turn overrides before treating `sandbox_mode: read-only` as the verifier's or context-reader's actual restriction. If a child needs an approval the non-interactive host cannot surface, mark the dependent slice blocked instead of assigning a new profile/child to evade it. [OpenAI: native roles and approvals](https://learn.chatgpt.com/docs/agent-configuration/subagents).

## Claude Code CLI / Claude Desktop optimizations

Claude Code custom subagent definitions in `.claude/agents/` or `~/.claude/agents/` may specialize a *planned* role through `description`, `tools`, `model`, and `effort`; defining or discovering such a file does not create an Agent instance or consume another locked slot. Assign any reusable role to a slot before the creation owner invokes `Agent`. The built-in Explore/Plan agents are one-shot, so do not allocate them as durable Primary Output, verifier, or follow-up roles. Preserve the locked count even if the host exposes additional built-in agents. [Anthropic: subagent scopes and one-shot agents](https://code.claude.com/docs/en/sub-agents).
