# unit.6063588dfa2ee6c4

[English](unit.6063588dfa2ee6c4.md) | [简体中文](unit.6063588dfa2ee6c4_zh_cn.md)

Apply the current instruction and its included policy sections below. The current actions, guards, evidence and failure boundary are given directly. Before applying a named independent policy, obtain its exact instruction continuation; reuse any already held unit from this build and retain the affected action's return position. Do not retrieve author files or infer omitted policy. Check current facts and authorization before effects; an instruction is not a pass.

## Hard constraints

- Record hard user, runtime environment, repository, permission, safety, and Session constraints before acting.
- A task-level prohibition, such as “do not create subagents” or “do not use a browser,” remains active for the whole task.
- Computer Use is categorically forbidden: never control a computer, browser, or desktop app through its graphical interface — no screenshots to locate controls, mouse or keyboard simulation, clicking, accessibility APIs, window automation, remote-desktop control, or GUI scripting — and do not route such interaction through an API, CLI, MCP server, helper, or another Agent. Treat this as a blacklist rather than a list of allowed channels: every other tool, command, or capability actually exposed to and authorized for the current Session remains permitted. If a required step needs a forbidden operation, stop and report the blocker instead of attempting, delegating, or skipping it.
- Before route selection or any delegation/Session-topology work, the Mode checkpoint must compose and validate the delegation references; those references own conversation-level mode selection with a default Multi-Agent route and one-child budget, child counts, conditional creation, allocation, reuse, replacement, exceptions, and limits at their respective atomic boundaries. A reserved budget never initializes or authorizes a child by itself.
- Never invent authorization, capability, evidence, product support, or an executable route for an unmaintained scenario.
- Keep Core rules independent of product details; read Runtime and Model Provider Support (instruction continuation: [unit.081374cfbaa37b57](../instructions/unit.081374cfbaa37b57.md)) for supported runtime branches and model bindings.
- Read references on demand. Do not preload the entire Skill, `references/`, or raw project state merely because it may become useful.

# Coding Session Audit Visibility

## General rules

### Configuration values

The root parent owns the session configuration. Users may select `audit_mode`, `root_reasoning_cadence`, and `worker_reasoning_cadence`; each field has its own source. These are Skill policies, not native product switches.

```yaml
audit_mode: balanced
root_reasoning_cadence: milestone_only
worker_reasoning_cadence: full
source: {audit_mode: default, root_reasoning_cadence: default, worker_reasoning_cadence: default}
```

| Field | Legal values | Default | Meaning |
| --- | --- | --- | --- |
| `audit_mode` | `economy`, `balanced`, `full` | `balanced` | Selects the Root visible-copy preset. |
| `root_reasoning_cadence` | `full`, `milestone_only`, `off` | `milestone_only` | Selects optional Root summary cadence. |
| `worker_reasoning_cadence` | `full`, `milestone_only`, `off` | `full` | Selects optional Worker summary cadence independently. |
| `source.<field>` | `explicit`, `default` per selectable field | `default` | `explicit` means the user selected that field; `default` means the policy supplied it. |
The root parent may accept explicit user preferences at any time. When no value was supplied, apply the defaults immediately; do not make a prompt, timer, or response prerequisite to Coding work.

The task-record shape is defined by the delegation state record (instruction continuation: [unit.04519b62e6c4f711](../instructions/unit.04519b62e6c4f711.md)). The applicable workflow checkpoint records the effective values and whether each is explicit or default.

### Visible-copy presets

The complete actual safe task and return bodies remain available in every preset. Root reads the complete actual Worker return before relying on it. A preset controls only Root's visible copy; it does not reduce evidence requirements or Worker visibility. For Worker message handling and safe-body rules, follow Child Message Visibility (instruction continuation: [unit.5fcfa7ba9fb0828d](../instructions/unit.5fcfa7ba9fb0828d.md)).

| Preset | Root outbound visible copy | Root inbound visible copy |
| --- | --- | --- |
| `economy` | Preview with at most 3 items: objective, allowed changes, return conditions. | Decision-relevant summary. |
| `balanced` | Complete related safe message only for a defined trigger below; otherwise the `economy` preview. | Complete related safe message only for a defined trigger below; otherwise the `economy` summary. |
| `full` | Complete safe message body. | Complete safe message body. |

For an `economy`/`balanced` preview, count displayed Markdown source including whitespace and link text/destinations: at most 3 items and 600 Unicode code points. For an inbound summary, the corresponding limits are 5 items and 800 Unicode code points; fields, in order, are conclusion, evidence pointers, key basis, risks/blockers, and next step, omitting fields without a value. Count characters, not tokens; no per-message counting-tool call is needed. Keep the complete body separately available. If a higher-priority instruction or material authorization/failure evidence cannot fit, exceed only as far as necessary and state why; never silently truncate or split a copy to evade the budget. The budget does not constrain full display or Worker visibility. Summaries must not reveal private reasoning.

`economy` still allows and requires necessary user-facing progress, authorization, failure, verification, stage-acceptance, and final reports. Those reports do not replace the complete actual body or its review.

### `balanced` full-display triggers

Display the complete related safe message only when an observable event occurs: an approved Contract goal, acceptance condition, path, or allowed effect changes; authorization is explicitly granted or withdrawn; an executed check fails or evidence directly conflicts/is disputed; or the user requests precise audit of this exchange. A new slice wholly within the existing Contract is not a trigger. If trigger status is uncertain, preserve the facts for the Root's decision. Do not automatically escalate all messages to `full`.

### Worker-log visibility

`worker_log_visibility` describes current-Session access to the complete safe Worker inbound/outbound conversation record, not just Root's returned final body or original encrypted runtime logs. `available` requires direct evidence locating the complete record; tool existence alone is insufficient. `unverified` means no affirmative success/failure evidence, including not yet checked. `unavailable` requires explicit missing capability, access failure, or equivalent negative evidence. `Not applicable` is valid only when no Worker was created, with that reason in the evidence field.

Check once when Worker-log evidence is first needed; update only on new actual access/capability evidence or failure, never per message. If a task explicitly depends on this log evidence, unavailable/unverified status blocks that audit dependency. Otherwise report the limitation and continue; the complete actual return body remains required.

### Summary cadence

Root and Worker cadence values apply independently. For summary turn boundaries and content format, follow Reasoning Summary Visibility (instruction continuation: [unit.d97fa46d10460df3](../instructions/unit.d97fa46d10460df3.md)). `full` emits the required safe summary at each completed boundary. `milestone_only` emits on these observable events:

| Event | Emit when |
| --- | --- |
| Material decision | A new/changed confirmed choice changes how the next slice is performed or what counts as acceptance; routine reads or command choices do not qualify. |
| Authorization change | Permission for an allowed effect is explicitly granted or withdrawn. |
| Verification failure | An executed check fails, or current acceptance criteria have direct failing evidence. |
| Blocker | The authorized next action cannot continue because required permission, capability, or evidence is actually missing. |
| Stage acceptance | Root finally accepts declared stage evidence and releases the next stage; ordinary progress is not acceptance. |

Deduplicate by event category plus related decision/evidence epoch. Emit each fact once, merge multiple triggers in one turn, and emit again only when the relevant fact or epoch materially changes. Do not infer materiality from elapsed time or repeated activity. `off` suppresses optional summaries only; required reports, evidence, Control updates, Progress Signals, and higher-level periodic updates remain required. No cadence permits private-reasoning disclosure.

## Codex CLI / ChatGPT Desktop optimizations

No provider-specific optimization is defined for this concept. Follow the general rules using only capabilities and evidence available to the current Session.

## Claude Code CLI / Claude Desktop optimizations

No provider-specific optimization is defined for this concept. Follow the general rules using only capabilities and evidence available to the current Session.
