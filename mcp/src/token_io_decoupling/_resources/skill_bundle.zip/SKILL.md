---
name: token-io-decoupling
description: "Execute Coding tasks with bounded, compiled instructions | 使用有界编译指令执行 Coding 任务"
---

# Token I/O Decoupling

[English](SKILL.md) | [简体中文](SKILL_zh_cn.md)

This generated Skill delivers executable Coding instructions. Record the task goal, authorized effects, constraints and acceptance criteria; verify available capabilities; then confirm the conversation's released execution mode. Missing facts or permission block only dependent actions. Computer Use is forbidden. Never treat a compiled instruction or hash as authorization or completion evidence.

After these entry gates pass, consume Route Entry and open only the route identified by its authorized result below. Follow its seven steps in order; the next step is explicit, so do not search the author policy tree. Each step directly provides its current actions, guards, evidence and failure/return boundaries. Obtain and apply the same-build shared constraints before any action, and each exact independent instruction continuation when its condition applies; these units are not all inlined into the step. Persist the shared task plan before implementation; preserve plan history. A failed prerequisite resumes at the exact suspended action after current evidence is obtained. Verification checks actual current state; changed epochs return to verification. Optional operations require an explicit Not applicable reason when omitted.

## Hard constraints

- Record hard user, runtime environment, repository, permission, safety, and Session constraints before acting.
- A task-level prohibition, such as “do not create subagents” or “do not use a browser,” remains active for the whole task.
- Computer Use is categorically forbidden: never control a computer, browser, or desktop app through its graphical interface — no screenshots to locate controls, mouse or keyboard simulation, clicking, accessibility APIs, window automation, remote-desktop control, or GUI scripting — and do not route such interaction through an API, CLI, MCP server, helper, or another Agent. Treat this as a blacklist rather than a list of allowed channels: every other tool, command, or capability actually exposed to and authorized for the current Session remains permitted. If a required step needs a forbidden operation, stop and report the blocker instead of attempting, delegating, or skipping it.
- Before route selection or any delegation/Session-topology work, the Mode checkpoint must compose and validate the delegation references; those references own conversation-level mode selection with a default Multi-Agent route and one-child budget, child counts, conditional creation, allocation, reuse, replacement, exceptions, and limits at their respective atomic boundaries. A reserved budget never initializes or authorizes a child by itself.
- Never invent authorization, capability, evidence, product support, or an executable route for an unmaintained scenario.
- Keep Core rules independent of product details; read [Runtime and Model Provider Support](instructions/fundamental-concepts--session-runtime--runtime-provider-support.md) for supported runtime branches and model bindings.
- Read references on demand. Do not preload the entire Skill, `references/`, or raw project state merely because it may become useful.

Build: `75487fb6498e0b28bdb4c50fcf90d338ca03ac0525694c63875b3125bf211a80`

Document-only integrity: use the [Skill manifest](manifest.json). Its `manifest.build_id` must match the entry's Build and any held batch identity. Verify `manifest.files["SKILL.md"]` against SHA-256 of each complete file's bytes, including its heading, language links and final newline. For other followed cards, use their exact paths relative to the Skill root in `manifest.files`. MCP `fragment.text_sha256` hashes the returned instruction body; it is not a document file hash. Never interchange these hashes. Missing batch evidence, manifest entries or matching content blocks dependent work and held-unit reuse.

The [instruction index](instruction-index.json) maps stable IDs to readable documents and records each checkpoint's distinct facts, evidence, branches and returns. Sharing a document does not merge checkpoint contracts.

Entry: [Contract](instructions/workflow-concepts--entry-and-context--contract.md) → [Environment](instructions/workflow-concepts--entry-and-context--environment.md) → [Capability inventory](instructions/workflow-concepts--entry-and-context--environment-capability-inventory.md) → [Mode](instructions/workflow-concepts--entry-and-context--mode.md) → [Route Entry](instructions/workflow-checkpoints--route-entry.md). Only Route Entry's current result selects the authorized route; the menu and default remain owned by Mode.

MCP: local Codex CLI only. When this server is available and authorized, prefer its public tools: start with `workflow_capabilities`, then `rules_get_context` with `node_id=contract` and `context_version=2`. Use `decide_decoupling_workflow` with an explicit `stage` and its required locked-mode and current-fact inputs for bounded stage instructions. Consume returned shared requirements and exact continuations before dependent actions. Other Agents use this document-only Skill without the server; follow the generated links and manifest checks below. Neither path requires author sources.

## Single-Agent

Read the [complete route scheduling and return map](routes/coding-single-agent.md) before following its steps.

1. [SM01: entry_readiness](steps/SM01.md)
2. [SM02: session_readiness](steps/SM02.md)
3. [SM03: work_definition](steps/SM03.md)
4. [SM04: execution](steps/SM04.md)
5. [SM05: verification_repair](steps/SM05.md)
6. [SM06: documentation](steps/SM06.md)
7. [SM07: delivery_acceptance](steps/SM07.md)

## Multi-Agent

Read the [complete route scheduling and return map](routes/coding-multi-agent.md) before following its steps.

1. [MM01: entry_readiness](steps/MM01.md)
2. [MM02: session_readiness](steps/MM02.md)
3. [MM03: work_definition](steps/MM03.md)
4. [MM04: execution](steps/MM04.md)
5. [MM05: verification_repair](steps/MM05.md)
6. [MM06: documentation](steps/MM06.md)
7. [MM07: delivery_acceptance](steps/MM07.md)
