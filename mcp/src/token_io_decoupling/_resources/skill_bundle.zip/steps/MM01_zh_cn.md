# MM01_zh_cn

[English](MM01.md) | [简体中文](MM01_zh_cn.md)

执行任何工作流动作前，先取得并应用完整共享约束：[common.hard_constraints](../instructions/common.hard_constraints_zh_cn.md)。只有实际已持有当前构建的准确单元且哈希匹配时才能复用；不得仅凭调用方声明假定内容可用。本响应不授权副作用，也不通过门禁。必需指令缺失、不兼容或不可用时阻塞依赖工作，不推断政策、不读取作者源。

缺少前置时，先停止依赖动作并取得生产者映射：[route.multi_agent.return_map](../instructions/route.multi_agent.return_map_zh_cn.md)。保留原调用方子步骤、已完成副作用与嵌套继续位置；只有生产者读回及当前 epoch/副作用检查完成后才能原位恢复，不重放门禁或副作用。下一阶段标签只在当前检查完成且无待返回时适用。

纯文档完整性：使用 [Skill 清单](../manifest.json)。`manifest.build_id` 必须与入口 Build 及已持有的构建批次身份一致。按 `manifest.files["steps/MM01_zh_cn.md"]`, `manifest.files["instructions/common.hard_constraints_zh_cn.md"]`, `manifest.files["instructions/route.multi_agent.return_map_zh_cn.md"]` 核对各完整文件字节的 SHA-256，包括标题、语言链接和末尾换行。其它沿链接取得的卡片，使用其相对 Skill 根目录的准确路径查找 `manifest.files`。MCP `fragment.text_sha256` 是返回指令正文的哈希，不是文档文件哈希，两者不得混用。批次证据、清单条目或匹配内容缺失时，阻塞依赖工作及已持有单元的复用。

- 绝对禁止 Computer Use：不得通过图形界面控制计算机、浏览器或桌面应用——包括以操纵控件为目的的截图、鼠标／键盘模拟、点击、辅助功能 API、窗口自动化、远程桌面控制或 GUI 脚本——也不得把此类交互包装为 API、CLI、MCP Server、辅助程序或其他 Agent 调用来绕过。本节是黑名单而非允许渠道清单：当前 Session 实际暴露且已获授权的其他工具、命令或能力仍然允许。若必需步骤需要借助被禁止的操作，应停止并报告阻塞，而不是尝试、委派或跳过。

进入 MM01 前，检查 Coding 工作流已完成 Contract、Environment、能力清单、Mode 和 Route Entry 的证据。不得重复这些门禁。本路线要求正数锁定 child count；预留数量本身不授权创建子代理。每一步只调用所链接的模块；前置导致暂停时，保留准确模块检查点和已完成效果，并从返回位置恢复。不得重放先前效果，也不得因缺少前置而重启整条路线。

1. **MM01 — 入口就绪。** 使用当前 Contract、Environment、能力清单、已释放 Multi-Agent Mode、正数锁定数量及授权路线证据，调用入口就绪模块 (本响应下方已完整提供的模块)。仅在入口证据当前且一致时继续。缺失前置交语义 owner 并保留 MM01；冲突或状态不安全时阻塞。

仅在其 producer/recheck 位置补齐缺失项。保留原挂起模块/子步骤、已完成效果和相关 epoch；若 producer 也暂停，则在现有调用方上下文保留嵌套 continuation。读回结果并重核 epoch/effect 后，只恢复原调用方位置。Contract/Environment/Mode 证据缺口仅需补齐缺失证据；只有路线事实实质变化时才重核 Route Entry，然后在保留锁定 Mode/count 的情况下返回原挂起位置。不得重放前序效果或重开已释放 Mode/count。owner/位置/效果未知、无进展或效果不可恢复时阻塞依赖工作。

## Mode 边界

只使用已释放的 Multi-Agent mode 和正数锁定数量。角色分配、创建、派发、复用、memo 和子代理生命周期由所调用模块组合的底层 owners 管理；本路线只负责模块顺序。

下列直接给出当前动作、守卫、证据和失败边界。应用独立政策前，先按明确的指令继续入口取得对应单元；同一构建中已持有的单元直接复用，并保留受影响动作的准确恢复位置。不读取作者文件或推测缺失政策。执行副作用前核实当前事实与授权；指令内容可用不表示检查通过。

# 入口就绪模块


本 Layer-04 模块组合建立路线就绪所需的当前任务 Contract、Environment/能力及已释放 Mode 证据。它消费现有 Layer-01 至 Layer-03 owners；不选择路线、不重新解释 Mode，也不授权实施或子代理效果。

## 入口声明

| 字段 | 要求 |
| --- | --- |
| 必需输入 | Coding selector 当前已通过的 `Contract`、`Environment`、能力清单和 `Mode` 证据；指出已选路线的路线入口 (instruction continuation: [unit.8e91c00a9ae84af0](../instructions/unit.8e91c00a9ae84af0_zh_cn.md))结果；当前任务范围和已知效果状态。 |
| 允许效果 | 读取并核验声明的证据；选择有界导航或可用的生成指令入口。不得修改工作流状态、重开 Mode，也不得创建/派发 Agent。 |
| 结果 | 以当前 Contract、Environment/能力、已释放的 Mode/count、已选路线证据，以及导航结果或有依据的 `not_applicable` 返回 `complete`；否则以暂停位置返回 `needs_prerequisite` 或 `blocked`。 |
| 新鲜度 | 根据当前任务/Session 及其来源/revision 确认证据。范围、Environment、能力或 Mode 有实质变化时，返回 `complete` 前须重核相关 owner。 |

## 工作流路线图


## 有序模块清单

1. **ER00 — 解析入口。** 提供本声明以及调用方当前任务、授权、Session、证据和效果状态，调用模块入口解析 (instruction continuation: [unit.f56021d97f9b69f7](../instructions/unit.f56021d97f9b69f7_zh_cn.md))。消费 Coding selector 已通过的 Contract/Environment/能力/Mode 证据以及指出已选路线的路线入口 (instruction continuation: [unit.8e91c00a9ae84af0](../instructions/unit.8e91c00a9ae84af0_zh_cn.md))结果；此处不得选择或重新选择路线。`ready` 只允许执行本模块的核验；将证据缺失映射为带暂停位置的 `needs_prerequisite`，将冲突或不安全状态映射为 `blocked`。直接调用方可以建立 continuation 记录；不要求存在顶层路线。
2. **ER01 — 核验 Contract 和共享协议。** 应用Contract (instruction continuation: [unit.e452c36c913b5771](../instructions/unit.e452c36c913b5771_zh_cn.md))，确认目标、用户/运行环境/仓库/权限/安全硬约束、已授权效果、已解决的决策、开放问题和验收条件。应用共享协议 (instruction continuation: [unit.70bd191baaed0076](../instructions/unit.70bd191baaed0076_zh_cn.md))，保持一个当前 Semantic Contract，区分事实与假设，以有界增量传递后续变化，并在必需上下文或返回路径不可用时停止依赖工作。未解决的问题不构成实施授权。按 Contract 动作 5，核验已释放 Contract 是否从直接权威来源记录了 task intent 和 eligible output classification；此处仅核验这些 Contract 记录。
3. **ER02 — 核验 Environment 和指令交付。** 应用Environment (instruction continuation: [unit.b92847af78d7f2a7](../instructions/unit.b92847af78d7f2a7_zh_cn.md))与Environment 能力清单 (instruction continuation: [unit.552ba8ac1f0543db](../instructions/unit.552ba8ac1f0543db_zh_cn.md))，确认当前能力。调用工作流导航选择 (instruction continuation: [unit.62ad0aab8f161260](../instructions/unit.62ad0aab8f161260_zh_cn.md))。可选导航不需要时，记录 `Not applicable` 并直接消费当前交付指令；否则审阅当前完整指令正文及明确继续入口，这些不建立身份、权限、状态或检查点完成。可选导航不可用时，可由实际可用且获授权的同构建生成纯文档入口提供单元。必需指令资源缺失、不完整或不兼容时阻塞依赖工作，不得回退作者源。
4. **ER03 — 对照已选路线核验已释放 Mode。** 应用Mode (instruction continuation: [unit.bba9c45137f16455](../instructions/unit.bba9c45137f16455_zh_cn.md))、模式确认 (instruction continuation: [unit.afaf028a769ea19e](../instructions/unit.afaf028a769ea19e_zh_cn.md))、委派数量门禁 (instruction continuation: [unit.36a14d319d1b638c](../instructions/unit.36a14d319d1b638c_zh_cn.md))、委派状态记录 (instruction continuation: [unit.04519b62e6c4f711](../instructions/unit.04519b62e6c4f711_zh_cn.md))和模式重入 (instruction continuation: [unit.5b0e93701a6ef118](../instructions/unit.5b0e93701a6ef118_zh_cn.md))。核验准确的已释放模式及锁定数量/状态；Single-Agent 要求 `child_count: 0` 且无 allocations。Multi-Agent 要求正数锁定数量及有效且与记录一致的当前 allocation；已占用/已创建和未分配的名额都可能是有效状态，不得要求每个名额都保持未绑定。已释放证据缺失或过期时返回 `needs_prerequisite`；模式/count 与已选路线冲突时返回 `blocked`。后续指令复用已锁定拓扑。这只确认路线资格，不释放具体 Slice 或授权创建子代理。以当前门禁证据返回 `complete`。

本步骤检查通过后，继续 [MM02](MM02_zh_cn.md)。
