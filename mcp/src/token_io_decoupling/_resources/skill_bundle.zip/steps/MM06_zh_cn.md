# 文档模块

[English](MM06.md) | [简体中文](MM06_zh_cn.md)

执行任何工作流动作前，先取得并应用完整共享约束：[硬约束](../instructions/common.hard_constraints_zh_cn.md)。只有实际已持有当前构建的准确单元且哈希匹配时才能复用；不得仅凭调用方声明假定内容可用。本响应不授权副作用，也不通过门禁。必需指令缺失、不兼容或不可用时阻塞依赖工作，不推断政策、不读取作者源。

缺少前置时，先停止依赖动作并取得生产者映射：[前置返回映射](../instructions/route.multi_agent.return_map_zh_cn.md)。保留原调用方子步骤、已完成副作用与嵌套继续位置；只有生产者读回及当前 epoch/副作用检查完成后才能原位恢复，不重放门禁或副作用。下一阶段标签只在当前检查完成且无待返回时适用。

纯文档完整性：使用 [Skill 清单](../manifest.json)。`manifest.build_id` 必须与入口 Build 及已持有的构建批次身份一致。按 `manifest.files["steps/MM06_zh_cn.md"]`, `manifest.files["instructions/common.hard_constraints_zh_cn.md"]`, `manifest.files["instructions/route.multi_agent.return_map_zh_cn.md"]` 核对各完整文件字节的 SHA-256，包括标题、语言链接和末尾换行。其它沿链接取得的卡片，使用其相对 Skill 根目录的准确路径查找 `manifest.files`。MCP `fragment.text_sha256` 是返回指令正文的哈希，不是文档文件哈希，两者不得混用。批次证据、清单条目或匹配内容缺失时，阻塞依赖工作及已持有单元的复用。

- 绝对禁止 Computer Use：不得通过图形界面控制计算机、浏览器或桌面应用——包括以操纵控件为目的的截图、鼠标／键盘模拟、点击、辅助功能 API、窗口自动化、远程桌面控制或 GUI 脚本——也不得把此类交互包装为 API、CLI、MCP Server、辅助程序或其他 Agent 调用来绕过。本节是黑名单而非允许渠道清单：当前 Session 实际暴露且已获授权的其他工具、命令或能力仍然允许。若必需步骤需要借助被禁止的操作，应停止并报告阻塞，而不是尝试、委派或跳过。

进入 MM01 前，检查 Coding 工作流已完成 Contract、Environment、能力清单、Mode 和 Route Entry 的证据。不得重复这些门禁。本路线要求正数锁定 child count；预留数量本身不授权创建子代理。每一步只调用所链接的模块；前置导致暂停时，保留准确模块检查点和已完成效果，并从返回位置恢复。不得重放先前效果，也不得因缺少前置而重启整条路线。

6. **MM06 — 文档。** 带上当前 Verification、Contract 和写前指纹，调用文档模块 (本响应下方已完整提供的模块)。该模块判断适用输出，输出适用时要求授权/来源/路径，处理请求 Memory 的 owner 要求内容核验、影响分类和检查。仅在当前文档结果齐备时继续。内容/Contract/验收变化需要重验时返回 MM05；受影响 epoch 通过后，恢复挂起的 MM06 子步骤，完成当前影响分类和文档检查后再进入 MM07。
   - 在 DOC02，可选[候选合规预检](../instructions/fundamental-concepts--execution-planning--candidate-compliance_zh_cn.md)仅适用于确实已选择且适用的写前分支：先准备有界候选并捕获可信基线，再运行检查；然后在应用前解决已选检查的失败、未知、遗漏或过期结果。已选分支缺少候选或基线时返回 `needs_prerequisite`，不得标为 `not_applicable`。只有分支确实未选择或不适用时才记录有原因的 `not_applicable`。DOC05 的写后检查仍必需，预检不能替代它。

仅在其 producer/recheck 位置补齐缺失项。保留原挂起模块/子步骤、已完成效果和相关 epoch；若 producer 也暂停，则在现有调用方上下文保留嵌套 continuation。读回结果并重核 epoch/effect 后，只恢复原调用方位置。Contract/Environment/Mode 证据缺口仅需补齐缺失证据；只有路线事实实质变化时才重核 Route Entry，然后在保留锁定 Mode/count 的情况下返回原挂起位置。不得重放前序效果或重开已释放 Mode/count。owner/位置/效果未知、无进展或效果不可恢复时阻塞依赖工作。

## Mode 边界

只使用已释放的 Multi-Agent mode 和正数锁定数量。角色分配、创建、派发、复用、memo 和子代理生命周期由所调用模块组合的底层 owners 管理；本路线只负责模块顺序。

下列直接给出当前动作、守卫、证据和失败边界。应用独立政策前，先按明确的指令继续入口取得对应单元；同一构建中已持有的单元直接复用，并保留受影响动作的准确恢复位置。不读取作者文件或推测缺失政策。执行副作用前核实当前事实与授权；指令内容可用不表示检查通过。

# 文档模块


本 Layer-04 模块基于当前已验证状态，仅编写获准的文档/注释或用户要求的可复用项目知识，然后按受影响维度分类写入后的影响。不执行最终 Verification、不决策语义变化，也不授权 Git 影响。

## 入口声明

| 字段 | 要求 |
| --- | --- |
| 入口前置条件 | 适用的 Single-Agent 或 Multi-Agent Mode 门禁已有当前释放证据；当前 Session 身份与 authority 已确认；调用方 continuation 和已完成效果均已知，且无未解决的效果歧义。 |
| 必需输入 | 当前 Contract 和范围、待记录状态的当前 implementation/content Verification，以及写前指纹。适用文档、注释或 Memory 输出时，须提供批准路径、读者、目的、来源证据和作者/职责授权。 |
| 允许效果 | 编辑已放行的文档/注释路径；有条件地持久化明确请求或触发的可复用项目 Memory；运行适用的文档检查并分类影响。普通非 Skill 文档由 parent 编写。 |
| 结果 | 以当前 documentation epoch、检查、前后指纹、受影响/未受影响维度，以及可复用 Memory 写入/读回结果返回 `complete`；否则连同所需 owner 和 continuation 返回 `needs_prerequisite` 或 `blocked`。 |
| 新鲜度 | 将来源 Verification 和文档结果绑定到当前指纹及适用 epoch。写后变化只使受影响维度失效；可执行内容、Contract 或验收变化也会使 implementation/content 证据失效。 |

## 工作流路线图


## 有序模块清单

1. **DOC00 — 解析入口。** 调用[模块入口解析](../instructions/workflow-checkpoints--module-entry-resolution_zh_cn.md)，提供当前 Contract/范围、适用的 implementation/content Verification、当前 epoch、已知效果、写前指纹和 continuation。仅在适用输出时提供批准路径、读者、目的、来源证据和作者授权。缺少必需证据时返回 `needs_prerequisite`；范围矛盾、状态不安全或效果未授权时返回 `blocked`。
2. **DOC01 — 核验状态并判断适用输出。** 应用[Documentation](../instructions/workflow-concepts--completion-and-effects--documentation_zh_cn.md)和[Session 职责归属](../instructions/fundamental-concepts--session-runtime--session-role-ownership_zh_cn.md)。确认当前 Contract/范围、适用的 implementation/content Verification 和写前指纹。首先依据当前 Contract/用户意图及 owner triggers 判断是否适用文档、注释或可复用项目 Memory 输出。输出适用时，必须具备准确批准路径、读者、目的、来源及作者/职责授权；缺少必需授权/路径/来源时返回 `needs_prerequisite` 或 `blocked`，不得标为 `not_applicable`。普通非 Skill 文档/注释由 parent 编写。只有通过全部 release gates 后，才可将 Skill 指令/参考文档分配给 child；parent 在 Documentation 和 Acceptance 阶段审查。必需 Verification 缺失或过期时返回 Verification。
3. **DOC02 — 编写获准输出或记录有证据的无变化。** 对已授权文档候选，先确认可选候选预检分支确实已选择且适用。已选择时，先准备准确的有界候选并捕获当前可信基线，再对该候选/基线运行[候选合规预检](../instructions/fundamental-concepts--execution-planning--candidate-compliance_zh_cn.md)，然后才能应用候选。所选分支缺少候选或基线时，在 DOC02 返回 `needs_prerequisite`，直至准备完成；不得将已选分支标为 `not_applicable`。仅消费所选能力声明的通用路径与基线检查结果。项目专属文档、语言或作者规则检查须通过目标仓库自身获授权的验证路线满足；通用预检不会执行这些检查。应用候选前，解决每项已选检查返回的失败、未知、遗漏、截断或过期结果。只有分支确实未选择，或其触发条件不存在/不适用时，才记录有原因的 `not_applicable` 并在授权的直接文档路径下继续。预检通过只是有限候选证据，不能替代 DOC05 写后检查、镜像语义审阅或当前 Verification。仅根据已验证来源编辑授权 Markdown/注释路径，保持目标仓库要求的语言版本一致。不得以文档名义引入行为、政策、Contract、验收、范围或 Git 变化。实质语义选择返回调用方 Contract/Decision 路径。无适用输出或获准输出实际无差异时，只有前后指纹匹配才可记录 `not_applicable`。保留已完成效果，恢复时不得重放。
4. **DOC03 — 仅持久化已授权项目 Memory。** 用户要求可复用 Agent 项目知识，或 owner 定义的触发条件适用时，按适用情况应用[LSP MCP Tools](../instructions/fundamental-concepts--session-runtime--lsp-mcp-tools_zh_cn.md)、[Content Memo](../instructions/fundamental-concepts--context-exchange--content-memo_zh_cn.md)及[Content Memo Lifecycle](../instructions/fundamental-concepts--context-exchange--content-memo-lifecycle_zh_cn.md)：保留获准名称/路径，通过暴露的 Memory 能力写入并确认操作成功。仅当适用 owner 要求时核验存储内容；有匹配核验凭据时使用该凭据，否则进行必要的内容比较。普通成功写入不会触发立即全文读回。派发字段 `write_content_memo: false` 不代表项目 Memory 不适用。未请求且未触发项目 Memory 输出时记录带原因的 `not_applicable`。必需能力、写入或 owner 要求的核验不可用/失败时，保持请求输出未完成；不得以文件替代。
5. **DOC04 — 分类写后影响。** 在任何请求的 Memory 写入和 owner 要求的内容核验之后，结合前后指纹应用[Documentation Impact](../instructions/workflow-checkpoints--documentation-impact_zh_cn.md)及[Verification Epoch](../instructions/workflow-concepts--verification-and-repair--verification-epoch_zh_cn.md)。实际维护文档/注释/Memory 变化推进 documentation epoch。若无输出变化且指纹匹配，不推进 epoch，并以证据记录 `not_applicable`。仅推进受影响维度，保留未受影响证据理由。可执行内容、Contract 或验收变化还须分类为 implementation/content 影响，并返回当前 Verification。影响未知时阻塞。
6. **DOC05 — 运行文档检查并评估证据复用。** 所有文档和 Memory 写入后，运行适用的 Markdown、链接、空白、多语言和范围检查。仅文档影响时，凭指纹理由保留未受影响的当前证据，并重跑变更的文档检查。没有变更输出时，以匹配指纹将检查标为 `not_applicable`。行为/Contract/验收影响返回 implementation/content Verification；必需重验未解决时不得完成。
7. **DOC06 — 返回文档证据。** 返回变更路径、来源依据、当前 documentation fingerprint/epoch、检查及结果、前后维度分类、复用未变证据的理由，以及 Memory 结果或有原因的 `not_applicable`。所有适用检查通过或有依据地 `not_applicable`、Memory 持久化已确认且 owner 要求的存储内容核验通过或有依据地 `not_applicable`，并且内容影响重新验证均已解决后，才返回 `complete`。这不授权 Git 或整体验收。

本步骤检查通过后，继续 [MM07](MM07_zh_cn.md)。
