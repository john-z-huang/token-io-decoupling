# MM02_zh_cn

[English](MM02.md) | [简体中文](MM02_zh_cn.md)

执行任何工作流动作前，先取得并应用完整共享约束：[common.hard_constraints](../instructions/common.hard_constraints_zh_cn.md)。只有实际已持有当前构建的准确单元且哈希匹配时才能复用；不得仅凭调用方声明假定内容可用。本响应不授权副作用，也不通过门禁。必需指令缺失、不兼容或不可用时阻塞依赖工作，不推断政策、不读取作者源。

缺少前置时，先停止依赖动作并取得生产者映射：[route.multi_agent.return_map](../instructions/route.multi_agent.return_map_zh_cn.md)。保留原调用方子步骤、已完成副作用与嵌套继续位置；只有生产者读回及当前 epoch/副作用检查完成后才能原位恢复，不重放门禁或副作用。下一阶段标签只在当前检查完成且无待返回时适用。

纯文档完整性：使用 [Skill 清单](../manifest.json)。`manifest.build_id` 必须与入口 Build 及已持有的构建批次身份一致。按 `manifest.files["steps/MM02_zh_cn.md"]`, `manifest.files["instructions/common.hard_constraints_zh_cn.md"]`, `manifest.files["instructions/route.multi_agent.return_map_zh_cn.md"]` 核对各完整文件字节的 SHA-256，包括标题、语言链接和末尾换行。其它沿链接取得的卡片，使用其相对 Skill 根目录的准确路径查找 `manifest.files`。MCP `fragment.text_sha256` 是返回指令正文的哈希，不是文档文件哈希，两者不得混用。批次证据、清单条目或匹配内容缺失时，阻塞依赖工作及已持有单元的复用。

- 绝对禁止 Computer Use：不得通过图形界面控制计算机、浏览器或桌面应用——包括以操纵控件为目的的截图、鼠标／键盘模拟、点击、辅助功能 API、窗口自动化、远程桌面控制或 GUI 脚本——也不得把此类交互包装为 API、CLI、MCP Server、辅助程序或其他 Agent 调用来绕过。本节是黑名单而非允许渠道清单：当前 Session 实际暴露且已获授权的其他工具、命令或能力仍然允许。若必需步骤需要借助被禁止的操作，应停止并报告阻塞，而不是尝试、委派或跳过。

进入 MM01 前，检查 Coding 工作流已完成 Contract、Environment、能力清单、Mode 和 Route Entry 的证据。不得重复这些门禁。本路线要求正数锁定 child count；预留数量本身不授权创建子代理。每一步只调用所链接的模块；前置导致暂停时，保留准确模块检查点和已完成效果，并从返回位置恢复。不得重放先前效果，也不得因缺少前置而重启整条路线。

2. **MM02 — Session 就绪。** 调用Session 就绪模块 (本响应下方已完整提供的模块)，确认规范 authority/state、审计及适用的容量读回。恢复改变事实时，遵循模块要求的规范读回先于审计顺序；不得重开 Mode 或重复已完成提问。仅在 Session、审计和 allocation 证据当前时继续；`needs_prerequisite` 时保留暂停位置，authority 或读回失败未解决时阻塞。

仅在其 producer/recheck 位置补齐缺失项。保留原挂起模块/子步骤、已完成效果和相关 epoch；若 producer 也暂停，则在现有调用方上下文保留嵌套 continuation。读回结果并重核 epoch/effect 后，只恢复原调用方位置。Contract/Environment/Mode 证据缺口仅需补齐缺失证据；只有路线事实实质变化时才重核 Route Entry，然后在保留锁定 Mode/count 的情况下返回原挂起位置。不得重放前序效果或重开已释放 Mode/count。owner/位置/效果未知、无进展或效果不可恢复时阻塞依赖工作。

## Mode 边界

只使用已释放的 Multi-Agent mode 和正数锁定数量。角色分配、创建、派发、复用、memo 和子代理生命周期由所调用模块组合的底层 owners 管理；本路线只负责模块顺序。

下列直接给出当前动作、守卫、证据和失败边界。应用独立政策前，先按明确的指令继续入口取得对应单元；同一构建中已持有的单元直接复用，并保留受影响动作的准确恢复位置。不读取作者文件或推测缺失政策。执行副作用前核实当前事实与授权；指令内容可用不表示检查通过。

# Session 就绪模块


本 Layer-04 模块为有界下游工作建立当前且已核验的 Session 记录与审计结果。它组合 Session owners 并向调用方返回证据；不重开 Mode、不产生计划/决策输出，也不调度其他模块。

## 入口声明

| 字段 | 要求 |
| --- | --- |
| 必需输入 | 当前任务范围和 Contract、已释放入口/路线/模式证据、当前 Session 身份/角色事实及父级控制记录来源。此处核验该记录，但它不是入口前置条件。 |
| 允许效果 | 读取并核实当前 Session 事实和父级控制记录；在其 owner 授权下将审计偏好应用于该记录。 |
| 结果 | 适用时，模块返回含当前 Session 事实、规范 parent-context 记录回读、生效审计偏好和 Multi-Agent 容量证据的 `complete`；否则返回带暂停位置的 `needs_prerequisite` 或 `blocked`。条件子步骤可记录有原因的 `not_applicable`；Session 模块本身不可跳过。 |
| 新鲜度 | 将证据绑定至当前 Session 身份/角色、最新 parent-context 回读、显式/缺省审计值、分配状态、来源及相关 epoch。实质变化会使受影响事实失效；消费依赖结果前重新读取父级控制记录。 |

## 工作流路线图


## 有序模块清单

1. **SR00 — 解析入口。** 提供本声明、当前任务范围、已释放的入口/路线/模式证据、Session 身份/角色事实、所选路径、epoch 和 continuation/效果状态，调用模块入口解析 (instruction continuation: [unit.f56021d97f9b69f7](../instructions/unit.f56021d97f9b69f7_zh_cn.md))。规范记录由本模块建立，不是入口前置条件。从记录的子步骤恢复。缺少前置条件时，以 owner 和暂停位置返回 `needs_prerequisite`；状态不安全或无法恢复时返回 `blocked`。
2. **SR01 — 复核实质变化。** 若当前 Contract、Context 或 Decision 发生实质变化，在依赖它们前审阅当前直接证据。不得重做规划、请求建议、重开 Mode 或启动下游效果。无实质变化时，记录有原因的 `not_applicable`。事实缺失时返回 `needs_prerequisite`；冲突或不安全事实返回 `blocked`。
3. **SR02 — 核验规范 parent-context 记录。** 应用Session 状态解决 (instruction continuation: [unit.690f2bdc7f95134d](../instructions/unit.690f2bdc7f95134d_zh_cn.md))及其直接链接的 Session、角色和 Context Firewall owner。核实已释放的 mode/count、当前身份和角色、逐操作所需权限以及记录一致性。回读规范记录和适用的 allocation 状态。结构工具结果或应用请求范围不能证明身份或授权。证据缺失时返回 `needs_prerequisite`；未解决冲突或必需 owner 不可用时返回 `blocked`。
4. **SR03 — 应用审计偏好。** 应用Session 审计解决 (instruction continuation: [unit.d8fab56bd46fe7b7](../instructions/unit.d8fab56bd46fe7b7_zh_cn.md))、Session Audit Visibility (instruction continuation: [unit.6063588dfa2ee6c4](../instructions/unit.6063588dfa2ee6c4_zh_cn.md))、Reasoning Summary Visibility (instruction continuation: [unit.d97fa46d10460df3](../instructions/unit.d97fa46d10460df3_zh_cn.md))和委派状态记录 (instruction continuation: [unit.04519b62e6c4f711](../instructions/unit.04519b62e6c4f711_zh_cn.md))。保留必需进度/报告义务和保密规则。立即应用显式偏好或缺省值；不得将提示、计时器、迁移或审计偏好设为前置条件。Worker 日志可见性只依据实际访问证据记录；仅当必需日志证据不可用或未验证时，才阻塞依赖它的判断。
5. **SR04 — 仅在 Multi-Agent 适用时核验容量。** 在已放行 Multi-Agent 模式下，读取当前父级控制分配。应用委派数量门禁 (instruction continuation: [unit.36a14d319d1b638c](../instructions/unit.36a14d319d1b638c_zh_cn.md))、委派状态记录 (instruction continuation: [unit.04519b62e6c4f711](../instructions/unit.04519b62e6c4f711_zh_cn.md))，并按条件应用子代理职责分配 (instruction continuation: [unit.4706ccaa5a523c17](../instructions/unit.4706ccaa5a523c17_zh_cn.md))，核实锁定容量、已占用角色和未分配名额。这只是只读核验：不得选择/预留角色、释放 Slice、创建子代理或回收名额。Single-Agent 模式记录附有理由的 `not_applicable`。返回 `complete`，并附上当前父级记录读回、生效的审计偏好和适用的容量证据；这些证据均不授权子代理任务。

本步骤检查通过后，继续 [MM03](MM03_zh_cn.md)。
