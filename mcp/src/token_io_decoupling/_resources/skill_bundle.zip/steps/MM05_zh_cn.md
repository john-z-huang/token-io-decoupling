# MM05_zh_cn

[English](MM05.md) | [简体中文](MM05_zh_cn.md)

执行任何工作流动作前，先取得并应用完整共享约束：[common.hard_constraints](../instructions/common.hard_constraints_zh_cn.md)。只有实际已持有当前构建的准确单元且哈希匹配时才能复用；不得仅凭调用方声明假定内容可用。本响应不授权副作用，也不通过门禁。必需指令缺失、不兼容或不可用时阻塞依赖工作，不推断政策、不读取作者源。

缺少前置时，先停止依赖动作并取得生产者映射：[route.multi_agent.return_map](../instructions/route.multi_agent.return_map_zh_cn.md)。保留原调用方子步骤、已完成副作用与嵌套继续位置；只有生产者读回及当前 epoch/副作用检查完成后才能原位恢复，不重放门禁或副作用。下一阶段标签只在当前检查完成且无待返回时适用。

纯文档完整性：使用 [Skill 清单](../manifest.json)。`manifest.build_id` 必须与入口 Build 及已持有的构建批次身份一致。按 `manifest.files["steps/MM05_zh_cn.md"]`, `manifest.files["instructions/common.hard_constraints_zh_cn.md"]`, `manifest.files["instructions/route.multi_agent.return_map_zh_cn.md"]` 核对各完整文件字节的 SHA-256，包括标题、语言链接和末尾换行。其它沿链接取得的卡片，使用其相对 Skill 根目录的准确路径查找 `manifest.files`。MCP `fragment.text_sha256` 是返回指令正文的哈希，不是文档文件哈希，两者不得混用。批次证据、清单条目或匹配内容缺失时，阻塞依赖工作及已持有单元的复用。

- 绝对禁止 Computer Use：不得通过图形界面控制计算机、浏览器或桌面应用——包括以操纵控件为目的的截图、鼠标／键盘模拟、点击、辅助功能 API、窗口自动化、远程桌面控制或 GUI 脚本——也不得把此类交互包装为 API、CLI、MCP Server、辅助程序或其他 Agent 调用来绕过。本节是黑名单而非允许渠道清单：当前 Session 实际暴露且已获授权的其他工具、命令或能力仍然允许。若必需步骤需要借助被禁止的操作，应停止并报告阻塞，而不是尝试、委派或跳过。

进入 MM01 前，检查 Coding 工作流已完成 Contract、Environment、能力清单、Mode 和 Route Entry 的证据。不得重复这些门禁。本路线要求正数锁定 child count；预留数量本身不授权创建子代理。每一步只调用所链接的模块；前置导致暂停时，保留准确模块检查点和已完成效果，并从返回位置恢复。不得重放先前效果，也不得因缺少前置而重启整条路线。

5. **MM05 — 验证与修复。** 针对准确当前指纹和验收条件调用验证与修复模块 (本响应下方已完整提供的模块)。只有 Contract 要求独立验证且当前独立性证据确认可用时，才完成独立验证；Worker 结果仅是实施证据。必需验证者证据待补时暂停依赖效果；若无法取得获授权的独立验证者，则阻塞这些效果。同 Session 逻辑检查不可替代。仅当必需检查在当前 epoch 通过且没有待修复项时继续。修复经交接返回当前 Verification；Contract/Decision 语义变化交调用方。实施、文档或 Git metadata 维度改变后不得使用过期证据。
   - 在 VR01，将任何输出收据与实际当前文件对账，并重新捕获当前状态和受影响 epoch；先根据当前证据解决部分或不确定效果。预检、收据或初步检查不能替代最终 Verification。

仅在其 producer/recheck 位置补齐缺失项。保留原挂起模块/子步骤、已完成效果和相关 epoch；若 producer 也暂停，则在现有调用方上下文保留嵌套 continuation。读回结果并重核 epoch/effect 后，只恢复原调用方位置。Contract/Environment/Mode 证据缺口仅需补齐缺失证据；只有路线事实实质变化时才重核 Route Entry，然后在保留锁定 Mode/count 的情况下返回原挂起位置。不得重放前序效果或重开已释放 Mode/count。owner/位置/效果未知、无进展或效果不可恢复时阻塞依赖工作。

## Mode 边界

只使用已释放的 Multi-Agent mode 和正数锁定数量。角色分配、创建、派发、复用、memo 和子代理生命周期由所调用模块组合的底层 owners 管理；本路线只负责模块顺序。

下列直接给出当前动作、守卫、证据和失败边界。应用独立政策前，先按明确的指令继续入口取得对应单元；同一构建中已持有的单元直接复用，并保留受影响动作的准确恢复位置。不读取作者文件或推测缺失政策。执行副作用前核实当前事实与授权；指令内容可用不表示检查通过。

# 验证与修复模块


本 Layer-04 模块捕获并验证当前最终状态、分类和报告结果，并将具体失败路由到获授权的窄范围修复，再返回当前 Verification。入口不要求已有最终 Verification 结果；本模块针对当前状态产出最终 Verification。

## 入口声明

| 字段 | 要求 |
| --- | --- |
| 入口前置条件 | 适用的 Single-Agent 或 Multi-Agent Mode 门禁已有当前释放证据；当前 Session 身份与 authority 已确认；调用方 continuation 和已完成效果均已知，且无未解决的效果歧义。本入口不授权独立 verifier；所需独立性须已由其 owner 授权并提供证据。 |
| 必需输入 | 当前 Contract 和验收条件、已完成的实施或子代理实际结果、当前任务范围与来源/效果证据，以及可供捕获最终 Verification 的当前状态。 |
| 允许效果 | 读取状态、运行已授权检查、分类/报告证据，并按直接 owners 路由已诊断的修复。修复写入仅限于另行授权的窄范围。 |
| 结果 | 以当前最终指纹/epoch、必需检查、独立性状态、结果类别、未解决项目/阻塞报告，且无未解决必需失败返回 `complete`；否则连同 owner 和 continuation 返回 `needs_prerequisite` 或 `blocked`。 |
| 新鲜度 | 将各结果绑定到准确的当前指纹及适用的 implementation/content、documentation 和 Git metadata epoch。任何修复或其他相关变化仅使覆盖范围内的维度失效，并返回当前 Verification。 |

## 工作流路线图


## 有序模块清单

1. **VR00 — 解析入口。** 提供本声明、当前 Contract/标准、实施或子代理实际结果、任务范围、来源/效果证据和 continuation，调用模块入口解析 (instruction continuation: [unit.f56021d97f9b69f7](../instructions/unit.f56021d97f9b69f7_zh_cn.md))。不要求预先存在最终 Verification 结果。证据缺失时返回 `needs_prerequisite`；冲突、状态不安全或效果无法恢复时返回 `blocked`。
2. **VR01 — 捕获实际当前最终状态。** 应用Verification (instruction continuation: [unit.5a1ed70ebf0cc2b4](../instructions/unit.5a1ed70ebf0cc2b4_zh_cn.md))检查实际当前状态、捕获准确指纹/epoch，并将每项 Contract 验收条件映射到覆盖维度。若先前输出使用了输出物料化 (instruction continuation: [unit.f6dfdbe9ab2522eb](../instructions/unit.f6dfdbe9ab2522eb_zh_cn.md))，捕获前须根据实际当前文件核对其收据。先根据当前证据解决任何部分、冲突或不确定的应用；应用收据、候选预检或初步检查均不能替代实际状态指纹或最终 Verification。代码/配置/测试变化影响 implementation/content 维度；维护文档/注释变化影响 documentation 维度；改变可执行内容、Contract 或验收条件的文档还影响 implementation/content 维度。应用Verification Epoch (instruction continuation: [unit.a831ed90e8918688](../instructions/unit.a831ed90e8918688_zh_cn.md))，分别跟踪 implementation/content、documentation 和 Git metadata。只有指纹和 epoch 未变化的维度才能复用先前证据。当前状态或标准缺失/不确定时，返回 `needs_prerequisite` 或阻塞依赖验证。应用任务计划 Memory 生命周期 (instruction continuation: [unit.c3c732f022fc8a5e](../instructions/unit.c3c732f022fc8a5e_zh_cn.md))：确认准确共享计划与当前读取访问，或其已记录的限制例外。独立验证者仅接收获授权计划/来源范围，可更新具名验证贡献，不得编辑被审实现。
3. **VR02 — 解析独立性要求。** 应用Verification Independence (instruction continuation: [unit.6f75bb495d0d3222](../instructions/unit.6f75bb495d0d3222_zh_cn.md))和Session 职责归属 (instruction continuation: [unit.d89ebcb45ebe2dea](../instructions/unit.d89ebcb45ebe2dea_zh_cn.md))。Contract 要求独立 Change Verification Session 时，使用该职责并仅提供给定范围证据和验收条件；否则将同 Session 检查分类为逻辑验证。在 Multi-Agent 执行中，Worker/子代理实际正文或结果是实施证据，不是独立验证；复用或完整可见也不满足必需的独立验证。必需的独立性不可用时返回 `needs_prerequisite`；不得声称满足 Contract。
4. **VR03 — 运行当前检查。** 针对 VR01 捕获的准确实际状态指纹运行适用的最强整体和定向检查。涵盖所有必需标准及变化维度所需检查。候选预检、应用收据和实施阶段检查仍是初步证据，不能替代这些当前检查。不得对受影响维度复用较早 epoch 的证据。必需检查不可运行时，保留不可用原因及阻塞影响。
5. **VR04 — 分类并报告证据。** 应用Verification Reporting (instruction continuation: [unit.5ca865327d2f752b](../instructions/unit.5ca865327d2f752b_zh_cn.md))和Verification Epoch (instruction continuation: [unit.a831ed90e8918688](../instructions/unit.a831ed90e8918688_zh_cn.md))。报告通过、失败、不可用和假设的检查、剩余风险、未解决项目及阻塞影响。只有在启用、符合条件、相关、已授权且绑定到当前指纹/epoch 时，才可通过建议选择 (instruction continuation: [unit.a60497211dd34eb4](../instructions/unit.a60497211dd34eb4_zh_cn.md))和Decisions Advisory (instruction continuation: [unit.4d827a8a683055da](../instructions/unit.4d827a8a683055da_zh_cn.md))评估可选的 verification-impact 建议。它只能建议维度，不能免除检查或宣告成功。否则记录带原因的建议 `not_applicable`，并使用直接证据。 按计划 owner 规定的边界记录新验证事实；影响依赖动作的变化须在该动作前记录。确认持久化操作成功，并在依赖动作前完成 owner 要求的内容核验；必需访问、持久化或核验失败时阻塞该边界。遵守已记录的限制例外并保留验证独立性。
6. **VR05 — 路由失败或确立 Repair N/A。** 应用Repair Disposition (instruction continuation: [unit.006f9eef4b46c673](../instructions/unit.006f9eef4b46c673_zh_cn.md))。具体失败必须有诊断、受影响路径和最小候选；之后依次应用Repair Scope Gate (instruction continuation: [unit.74f6aa64994e9f30](../instructions/unit.74f6aa64994e9f30_zh_cn.md))、Repair Execution (instruction continuation: [unit.42e9ccbf8fdaa24a](../instructions/unit.42e9ccbf8fdaa24a_zh_cn.md))及Repair Verification Handoff (instruction continuation: [unit.5ca52cb1934d946b](../instructions/unit.5ca52cb1934d946b_zh_cn.md))。仅执行已授权的窄范围修复，保留实际变更路径/证据，并将新指纹/受影响 epoch 返回 VR01 进行当前重验。Contract 或 Decision 实质变化时，返回 `needs_prerequisite` 给调用方进行语义审查和调度；不得把它当作修复。无具体失败时，以证据依据记录 Repair `not_applicable` 并返回 VR01，确认当前 Verification 结果。诊断、授权、有界范围、修复证据或交接缺失时，阻塞依赖工作。
7. **VR06 — 返回当前最终 Verification。** 返回当前指纹、每个适用 epoch 及状态、标准与证据的映射、独立性分类、检查/结果类别、剩余风险、未解决项目和阻塞影响。仅当所有必需的当前 Verification 项目通过、必需的独立验证已满足、且没有未解决的必需修复/证据时返回 `complete`。此结果本身不宣告整体验收。

本步骤检查通过后，继续 [MM06](MM06_zh_cn.md)。
