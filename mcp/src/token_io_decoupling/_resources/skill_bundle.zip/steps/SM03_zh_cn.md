# SM03_zh_cn

[English](SM03.md) | [简体中文](SM03_zh_cn.md)

执行任何工作流动作前，先取得并应用完整共享约束：[common.hard_constraints](../instructions/common.hard_constraints_zh_cn.md)。只有实际已持有当前构建的准确单元且哈希匹配时才能复用；不得仅凭调用方声明假定内容可用。本响应不授权副作用，也不通过门禁。必需指令缺失、不兼容或不可用时阻塞依赖工作，不推断政策、不读取作者源。

缺少前置时，先停止依赖动作并取得生产者映射：[route.single_agent.return_map](../instructions/route.single_agent.return_map_zh_cn.md)。保留原调用方子步骤、已完成副作用与嵌套继续位置；只有生产者读回及当前 epoch/副作用检查完成后才能原位恢复，不重放门禁或副作用。下一阶段标签只在当前检查完成且无待返回时适用。

纯文档完整性：使用 [Skill 清单](../manifest.json)。`manifest.build_id` 必须与入口 Build 及已持有的构建批次身份一致。按 `manifest.files["steps/SM03_zh_cn.md"]`, `manifest.files["instructions/common.hard_constraints_zh_cn.md"]`, `manifest.files["instructions/route.single_agent.return_map_zh_cn.md"]` 核对各完整文件字节的 SHA-256，包括标题、语言链接和末尾换行。其它沿链接取得的卡片，使用其相对 Skill 根目录的准确路径查找 `manifest.files`。MCP `fragment.text_sha256` 是返回指令正文的哈希，不是文档文件哈希，两者不得混用。批次证据、清单条目或匹配内容缺失时，阻塞依赖工作及已持有单元的复用。

- 绝对禁止 Computer Use：不得通过图形界面控制计算机、浏览器或桌面应用——包括以操纵控件为目的的截图、鼠标／键盘模拟、点击、辅助功能 API、窗口自动化、远程桌面控制或 GUI 脚本——也不得把此类交互包装为 API、CLI、MCP Server、辅助程序或其他 Agent 调用来绕过。本节是黑名单而非允许渠道清单：当前 Session 实际暴露且已获授权的其他工具、命令或能力仍然允许。若必需步骤需要借助被禁止的操作，应停止并报告阻塞，而不是尝试、委派或跳过。

进入 SM01 前，检查 Coding 工作流已完成 Contract、Environment、能力清单、Mode 和 Route Entry 的证据。不得重复这些门禁。本路线仅适用于已释放的 Single-Agent Coding，且始终留在当前 Session。每一步只调用所链接的模块；前置导致暂停时，保留准确模块检查点和已完成效果，并从返回位置恢复。不得重放先前效果，也不得因缺少前置而重启整条路线。

3. **SM03 — 工作定义。** 调用工作定义模块 (本响应下方已完整提供的模块)，解决当前 Context、Decision、规划输出及有界授权工作。在 WD02，独立于 Decision 建议考虑可选工作流路由建议 (instruction continuation: [unit.c8db0a91e134c7a6](../instructions/unit.c8db0a91e134c7a6_zh_cn.md))：仅在事实当前且已直接确认锁定路线时使用，并根据该路线审阅建议；未选择或不符合条件时，记录有原因的 `not_applicable`。该建议不授权工作，也不改变路线。所选路径缺少必需能力或证据过期时，返回以取得当前证据或阻塞该依赖路径。仅在来源事实、已接受决定和未释放边界当前时继续。缺失事实/决定交其 owner 处理并恢复 SM03；授权或 Contract 实质变化时交调用方审查路线。执行前要求该模块返回默认共享计划身份、当前计划证据与持久化确认，或有记录的持久化限制例外；完成 owner 要求的任何内容核验。必需计划证据缺失时阻塞；无需额外规划请求。验证所选仓库存储范围及对应活动/归档命名空间；共享存储时，同仓库各工作区指向同一规划，其他仓库保持隔离。映射未知或冲突时返回规划 owner，不得静默回退另一存储范围。

仅在其 producer/recheck 位置补齐缺失项。把原调用方模块/子步骤及其已完成效果保留为 continuation 栈项；若补前置本身又暂停，也保留 producer continuation。producer 完成后读回证据并重核相关 epoch/效果，然后仅恢复原调用方位置，不得恢复到 producer 位置或顺跑下一模块。不得重放效果、重开已释放 Mode 或重复已完成提问。Contract/Environment/Mode 证据缺口只在现有 owner 读取/补齐；仅路线事实实质变化时重进 Route Entry，然后保留锁定 Mode 返回原调用方。producer/位置/效果未知或循环未产生新证据时，阻塞依赖工作。

## Mode 边界

所有阶段均留在当前 Session；绝不创建其他 Session。将 Input-side Reasoning、Primary Output 和验证视为同一 Session 内的逻辑阶段。只有适用 Verification owner 通过当前证据确认要求已满足时，才可声称独立验证；必需的独立性不可用时，阻塞依赖效果。

下列直接给出当前动作、守卫、证据和失败边界。应用独立政策前，先按明确的指令继续入口取得对应单元；同一构建中已持有的单元直接复用，并保留受影响动作的准确恢复位置。不读取作者文件或推测缺失政策。执行副作用前核实当前事实与授权；指令内容可用不表示检查通过。

# 工作定义模块


本 Layer-04 模块用当前事实建立任务上下文，并产出符合 Contract 的决策及默认共享任务计划。它不选择执行者、不评估输出路由、不预留角色、不释放 Slice，也不执行 Bootstrap。

## 入口声明

| 字段 | 要求 |
| --- | --- |
| 必需输入 | 当前已授权 Contract 和任务范围、已释放路线/模式证据、当前规范 Session state 和已完成的审计读回、已知任务事实/来源指针、取得所需 Context 的已授权可用方式，以及调用方 continuation/效果状态。WD01 建立当前 Context；它不是入口前置条件。 |
| 允许效果 | 有界且已授权的只读 Context 检索；仅在已有授权的当前 Root Session 下请求符合条件的语义建议；在既有授权内默认持久化任务计划，并遵守明确持久化限制。不得执行 executor/output 路由、角色预留、Slice 释放、Bootstrap、实施或子代理派发。 |
| 结果 | 本模块以当前有来源的 Context、符合 Contract 的 Decision/未释放边界，以及计划证据或有依据的子步骤 `not_applicable` 返回 `complete`；否则返回带暂停位置的 `needs_prerequisite` 或 `blocked`。Context/建议/计划子步骤可根据触发证据标为 `not_applicable`，但不得整体跳过必需的工作定义模块。建议是待审证据，不是授权。 |
| 新鲜度 | 保留来源/出处/新鲜度及相关 input/policy hash 和 epoch。建议或依赖决策前重新确认；实质变化会使受影响证据失效，并要求调用方从受影响子步骤重新进入。 |

## 工作流路线图


## 有序模块清单

1. **WD00 — 解析入口。** 提供本声明、当前已授权 Contract 和任务范围、已释放路线/模式证据、当前规范 Session state 和已完成的审计读回、已知任务事实/来源指针、取得所需 Context 的已授权可用方式，以及 continuation/效果状态，调用模块入口解析 (instruction continuation: [unit.f56021d97f9b69f7](../instructions/unit.f56021d97f9b69f7_zh_cn.md))。规范 state 和已完成审计读回是必需输入；当前任务 Context 在 WD01 建立。从记录的子步骤恢复。缺少前置条件时，连同语义 owner 一起返回；冲突或无法恢复的状态则阻塞。没有已授权的当前 Session 时，不请求建议。
2. **WD01 — 建立有界当前 Context。** 应用Context (instruction continuation: [unit.d2e88709b902fca6](../instructions/unit.d2e88709b902fca6_zh_cn.md))、上下文来源选择 (instruction continuation: [unit.84732faf33a5ac47](../instructions/unit.84732faf33a5ac47_zh_cn.md))和Session Context Firewall (instruction continuation: [unit.95aba471482062c9](../instructions/unit.95aba471482062c9_zh_cn.md))。定义下一项任务所需的最小问题，只检查必需来源。计划内容在当前上下文中有效时直接复用；否则按需获取匹配的 active plan Memory。当前指令优先，plan 不授予授权。仅在所需内容缺失或过期时读取相关可复用 Memory，并核验来源指针/新鲜度；如果没有或不可用，返回经批准的权威项目来源，只有必需事实仍无法核实时才阻塞。仅在触发有界规则查询时使用Workflow Rule Context (instruction continuation: [unit.b2c56bb76a6f6521](../instructions/unit.b2c56bb76a6f6521_zh_cn.md))，确认 owner/语言/来源/hash，并读取被摘录省略的直接 owner。仅在需要项目/代码结构证据时应用LSP MCP Tools (instruction continuation: [unit.eb35e270023c9aac](../instructions/unit.eb35e270023c9aac_zh_cn.md))；否则记录 `not_applicable` 及原因。返回有来源的当前事实、来源链、新鲜度/epoch 和限制；过期、冲突或缺失的关键事实会阻塞依赖决策。
   - 若下游 Decision 建议需要审阅背景，应用决策上下文选择 (instruction continuation: [unit.caa7baa69e1cbe03](../instructions/unit.caa7baa69e1cbe03_zh_cn.md))和Decision Context Generation (instruction continuation: [unit.4d8491f91935afe9](../instructions/unit.4d8491f91935afe9_zh_cn.md))：只提供有界事实和具体目标，审查忠实度/相关性/来源，并核验准确的输入/政策绑定。拒绝过期或不匹配背景；若建议不需要生成背景，记录 `not_applicable` 及原因。
   - 仅在 Multi-Agent 模式下，若上下文来源选择 owner 确认触发了持久化交换或 memo 前置条件，则只按该触发检查相应的Context Exchange (instruction continuation: [unit.439bedbb36334cd3](../instructions/unit.439bedbb36334cd3_zh_cn.md))、工作区边界 (instruction continuation: [unit.0a54c601ab09a7e6](../instructions/unit.0a54c601ab09a7e6_zh_cn.md))、交接 (instruction continuation: [unit.2d0f4872b823ef44](../instructions/unit.2d0f4872b823ef44_zh_cn.md))或Content Memo Dispatch (instruction continuation: [unit.90ad9fe16c44d13f](../instructions/unit.90ad9fe16c44d13f_zh_cn.md)) owner。确认必需的当前记录和 Memory 证据；不得仅为收集 Context 创建交换记录，也不得在此派发 memo。未触发时记录 `not_applicable` 及原因。Single-Agent 模式下，这些子代理专属交换和 memo owners 均为 `not_applicable`；不得加载这些 owner。
3. **WD02 — 在 Contract 范围内决策。** 应用Decision (instruction continuation: [unit.41b987be9e704d9b](../instructions/unit.41b987be9e704d9b_zh_cn.md))、执行决策门禁 (instruction continuation: [unit.de2827a57b366838](../instructions/unit.de2827a57b366838_zh_cn.md))和执行规划 (instruction continuation: [unit.bfe4630ffe78e154](../instructions/unit.bfe4630ffe78e154_zh_cn.md))。说明实质问题、已核实事实、未知项、选项、所选方向、拒绝的替代方案、授权范围/效果、返回条件和未释放边界。对于仍开放的实质选择，准备必需的 Decision Brief，且只释放侦察；确认 Contract 允许所选方向后再进入后续释放。Session 实质恢复后，仅在调用方要求时于此重评当前 Decision/Contract 证据；不得重开 Mode 或重复已完成的审计提问。
   - 建议是可选的。仅当已有授权的当前 Root Session 存在，且 Decision 阶段符合资格、已启用并且相关时，应用建议选择 (instruction continuation: [unit.a60497211dd34eb4](../instructions/unit.a60497211dd34eb4_zh_cn.md))和Decisions Advisory (instruction continuation: [unit.4d827a8a683055da](../instructions/unit.4d827a8a683055da_zh_cn.md))。否则依赖直接 owner 并将建议记录为带原因的 `not_applicable`。根据当前直接 owner 证据和 hash 审查任何建议；建议不会选择或授权工作。
   - 任务阶段建议是独立的可选输入。仅当 WD01 事实当前有效、锁定的 mode/count 与所选路线已直接确认，且建议路径符合条件、已启用并获授权时，才应用工作流路由建议 (instruction continuation: [unit.c8db0a91e134c7a6](../instructions/unit.c8db0a91e134c7a6_zh_cn.md))。它可以建议恢复时的当前阶段/模块；任何可用建议都须根据当前所选路线及来源/政策哈希审阅。它不会改变路线或 mode/count、通过门禁、选择执行者/输出或释放工作。未选择或不符合条件时，记录有原因的 `not_applicable` 并按当前路线继续。如果所选路径必需能力不可用或证据过期/不足，返回以取得当前证据或阻塞该依赖路径；不得静默回退。此项与上方现有 Decision 建议保持分离。
   - 执行者选择和输出路由不属于本模块范围，仍由之后另行授权的执行路径处理。
4. **WD03 — 解决默认共享任务计划。** 调用规划输出选择 (instruction continuation: [unit.4212a614b3f2a7f0](../instructions/unit.4212a614b3f2a7f0_zh_cn.md))，应用任务计划 Memory 生命周期 (instruction continuation: [unit.c3c732f022fc8a5e](../instructions/unit.c3c732f022fc8a5e_zh_cn.md))。无论有无 Issue 或明确规划请求，均综合当前事实与拟议方案，持久化具体计划，并在实施或依赖派发前确认操作成功；owner 要求时才核验内容。确认所选存储范围、仓库身份和对应活动/归档命名空间；共享存储中，同仓库各工作区复用规划，其他仓库保持隔离。按生命周期 owner 解析映射；映射未知或冲突时阻塞，不静默回退。返回准确项目/计划身份、存储映射、允许贡献、持久化确认及 owner 要求的核验证据。仅已记录的明确持久化限制允许使用 owner 的例外；与明确持久化要求冲突、必需访问缺失、写入失败或必需核验失败时阻塞。需求变化先记录，再分析并持久化修订提议，然后才处理受影响工作。只有当前事实、符合 Contract 的 Decision/未释放边界，以及当前计划证据或有依据的限制例外齐备时，才返回 `complete`。这不释放 Slice、不选择执行者，也不授权实施；必需模块不能整体跳过为 `not_applicable`。

本步骤检查通过后，继续 [SM04](SM04_zh_cn.md)。
