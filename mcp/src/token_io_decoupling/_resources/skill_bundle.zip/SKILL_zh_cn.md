---
name: token-io-decoupling
description: "Execute Coding tasks with bounded, compiled instructions | 使用有界编译指令执行 Coding 任务"
---

# Token I/O Decoupling

[English](SKILL.md) | [简体中文](SKILL_zh_cn.md)

本生成 Skill 交付可执行的 Coding 指令。先记录任务目标、授权副作用、约束与验收标准，核实可用能力，再确认当前会话已释放的执行模式。缺事实或权限时停止依赖动作。禁止 Computer Use。编译指令或 hash 不代表授权或完成证据。

入口条件通过后，先消费 Route Entry，只打开其授权结果所指明的下列路线，按七步依次执行。下一步明确给出，不查找作者政策树。每步直接提供当前动作、守卫、证据和失败返回边界；执行任何动作前先取得并应用同一构建的共享约束，独立政策条件触发时先消费其准确指令继续入口，这些单元并未全部内联到步骤正文。实施前持久化共享任务计划并保留历史；前置失败时取得当前证据后只恢复准确暂停动作。验证实际当前状态，状态代际变化后返回重验；未采用条件操作时记录明确 Not applicable 理由。

## 硬约束

- 采取行动前记录用户、运行环境、仓库、权限、安全和 Session 硬约束。
- “不要创建子代理”“不要使用浏览器”等任务级禁止条件在整个任务中持续有效。
- 绝对禁止 Computer Use：不得通过图形界面控制计算机、浏览器或桌面应用——包括以操纵控件为目的的截图、鼠标／键盘模拟、点击、辅助功能 API、窗口自动化、远程桌面控制或 GUI 脚本——也不得把此类交互包装为 API、CLI、MCP Server、辅助程序或其他 Agent 调用来绕过。本节是黑名单而非允许渠道清单：当前 Session 实际暴露且已获授权的其他工具、命令或能力仍然允许。若必需步骤需要借助被禁止的操作，应停止并报告阻塞，而不是尝试、委派或跳过。
- 路线选择或任何委派/Session 拓扑工作前，模式检查点必须组合并验证委派 references；这些 references 在各自的原子边界内规定会话级模式选择及默认多代理路线和单个子代理预算、子代理数量、条件创建、分配、复用、替换、例外和限制。预留预算本身不会初始化或授权创建子代理。
- 不得虚构授权、能力、证据、产品支持，或为未维护场景推导可执行路线。
- Core 规则不依赖具体产品；受支持的运行环境分支和模型绑定见运行环境与模型厂商支持 (instruction continuation: [unit.081374cfbaa37b57](instructions/unit.081374cfbaa37b57_zh_cn.md))。
- 按需读取 reference。不要仅因为可能以后有用，就预加载整个 Skill、`references/` 或原始项目状态。

Build: `ee2022aa989e44b0dd51df440e047279b332e879567ace09dba7a4eaef98afe0`

纯文档完整性：使用 [Skill 清单](manifest.json)。`manifest.build_id` 必须与入口 Build 及已持有的构建批次身份一致。按 `manifest.files["SKILL_zh_cn.md"]` 核对各完整文件字节的 SHA-256，包括标题、语言链接和末尾换行。其它沿链接取得的卡片，使用其相对 Skill 根目录的准确路径查找 `manifest.files`。MCP `fragment.text_sha256` 是返回指令正文的哈希，不是文档文件哈希，两者不得混用。批次证据、清单条目或匹配内容缺失时，阻塞依赖工作及已持有单元的复用。

入口：[Contract](instructions/checkpoint.contract_zh_cn.md) → [Environment](instructions/unit.b92847af78d7f2a7_zh_cn.md) → [能力清单](instructions/unit.552ba8ac1f0543db_zh_cn.md) → [Mode](instructions/checkpoint.mode_zh_cn.md) → [Route Entry](instructions/unit.8e91c00a9ae84af0_zh_cn.md)。仅按 Route Entry 的当前结果选择授权路线；菜单和默认值仍由 Mode 负责。

MCP 仅支持本地 Codex CLI。此 Server 可用且已获授权时，优先使用其公开工具：先调用 `workflow_capabilities`，再以 `node_id=contract`、`context_version=2` 调用 `rules_get_context`；取得有界阶段指令时，使用明确 `stage` 以及其必需的已锁定模式和当前事实输入，调用 `decide_decoupling_workflow`。依赖动作前先消费返回的共享要求及准确指令继续入口。其它 Agent 不使用此 Server，而按下列生成链接与清单核对使用纯文档 Skill；两种路径均不需要作者源。

## Single-Agent

按步骤执行前，先消费[完整路线调度与返回映射](routes/coding-single-agent_zh_cn.md)。

1. [SM01: entry_readiness](steps/SM01_zh_cn.md)
2. [SM02: session_readiness](steps/SM02_zh_cn.md)
3. [SM03: work_definition](steps/SM03_zh_cn.md)
4. [SM04: execution](steps/SM04_zh_cn.md)
5. [SM05: verification_repair](steps/SM05_zh_cn.md)
6. [SM06: documentation](steps/SM06_zh_cn.md)
7. [SM07: delivery_acceptance](steps/SM07_zh_cn.md)

## Multi-Agent

按步骤执行前，先消费[完整路线调度与返回映射](routes/coding-multi-agent_zh_cn.md)。

1. [MM01: entry_readiness](steps/MM01_zh_cn.md)
2. [MM02: session_readiness](steps/MM02_zh_cn.md)
3. [MM03: work_definition](steps/MM03_zh_cn.md)
4. [MM04: execution](steps/MM04_zh_cn.md)
5. [MM05: verification_repair](steps/MM05_zh_cn.md)
6. [MM06: documentation](steps/MM06_zh_cn.md)
7. [MM07: delivery_acceptance](steps/MM07_zh_cn.md)
